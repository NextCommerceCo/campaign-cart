import { L as Logger, E as EventBus, r as reconcileValue } from "./analytics-DdhZlX6_.js";
import { a as useCampaignStore, c as configStore, e as cartOperations, d as useCartStore, f as useOrderStore, u as useCheckoutStore } from "./state-pM9xfsfc.js";
import { H as HighlightJS, j as json, f as faXmark, a as faPause, b as faTriangleExclamation, c as faClock, d as faCircleXmark, e as faBan, g as faCircleMinus, h as faCircleCheck, i as faCheck, k as faBolt, l as faInbox, m as faMagnifyingGlassMinus, n as faMagnifyingGlass, o as faFilter, p as faDatabase, q as faChartColumn, r as faCreditCard, s as faBullhorn, t as faGear, u as faBox, v as faTag, w as faCartShopping } from "./vendor-DZMxNnSk.js";
class CountryService {
  constructor() {
    this.cachePrefix = "next_country_";
    this.cacheExpiry = 36e5;
    this.baseUrl = "https://cdn-countries.muddy-wind-c7ca.workers.dev";
    this.config = {};
    this.campaignShippingCountries = null;
    this.logger = new Logger("CountryService");
  }
  static getInstance() {
    if (!CountryService.instance) {
      CountryService.instance = new CountryService();
    }
    return CountryService.instance;
  }
  /**
   * Set address configuration
   */
  setConfig(config) {
    this.config = { ...config };
    this.logger.debug("Address configuration updated:", this.config);
  }
  /**
   * Get current configuration
   */
  getConfig() {
    return { ...this.config };
  }
  /**
   * Set campaign shipping countries from the campaign API
   *
   * IMPORTANT: This takes PRIORITY over all addressConfig country settings.
   * This ensures the country dropdown only shows countries that the campaign actually ships to.
   *
   * Priority order for country filtering:
   * 1. Campaign shipping countries (this method) - Highest priority ⭐
   * 2. config.countries (custom list with names)
   * 3. config.showCountries (legacy, deprecated) - Lowest priority
   *
   * @param countries Array of shipping countries from campaign API
   */
  setCampaignShippingCountries(countries) {
    this.campaignShippingCountries = countries ? countries.map((c) => c.code) : null;
    this.logger.debug(
      "Campaign shipping countries updated:",
      this.campaignShippingCountries
    );
  }
  /**
   * Get campaign shipping countries
   */
  getCampaignShippingCountries() {
    return this.campaignShippingCountries;
  }
  /**
   * Get location data with user's detected country and list of all countries
   */
  async getLocationData() {
    const cached = this.getFromCache("location_data", true);
    if (cached) {
      return await this.applyCountryFiltering(cached);
    }
    try {
      const response = await fetch(`${this.baseUrl}/location`);
      if (!response.ok) {
        throw new Error(
          `Failed to fetch location data: ${response.statusText}`
        );
      }
      const data = await response.json();
      this.setCache("location_data", data, true);
      this.logger.debug("Location data fetched", {
        detectedCountry: data.detectedCountryCode,
        countriesCount: data.countries?.length
      });
      return await this.applyCountryFiltering(data);
    } catch (error) {
      this.logger.error("Failed to fetch location data:", error);
      return await this.applyCountryFiltering(this.getFallbackLocationData());
    }
  }
  /**
   * Get states for a specific country
   */
  async getCountryStates(countryCode) {
    const cacheKey = `states_${countryCode}`;
    const cached = this.getFromCache(cacheKey, true);
    if (cached) {
      return {
        ...cached,
        states: this.applyStateFiltering(cached.states || [])
      };
    }
    try {
      const response = await fetch(
        `${this.baseUrl}/countries/${countryCode}/states`
      );
      if (!response.ok) {
        throw new Error(
          `Failed to fetch states for ${countryCode}: ${response.statusText}`
        );
      }
      const data = await response.json();
      this.setCache(cacheKey, data, true);
      this.logger.debug(`States data fetched for ${countryCode}`, {
        statesCount: data.states?.length,
        stateLabel: data.countryConfig?.stateLabel
      });
      return {
        ...data,
        states: this.applyStateFiltering(data.states || [])
      };
    } catch (error) {
      this.logger.error(`Failed to fetch states for ${countryCode}:`, error);
      return {
        countryConfig: this.getDefaultCountryConfig(countryCode),
        states: []
      };
    }
  }
  /**
   * Get country configuration by country code
   */
  async getCountryConfig(countryCode) {
    const locationData = await this.getLocationData();
    if (locationData.detectedCountryCode === countryCode) {
      return locationData.detectedCountryConfig;
    }
    const statesData = await this.getCountryStates(countryCode);
    return statesData.countryConfig;
  }
  /**
   * Validate postal code based on country configuration
   */
  validatePostalCode(postalCode, _countryCode, countryConfig) {
    if (!postalCode) return false;
    if (postalCode.length < countryConfig.postcodeMinLength || postalCode.length > countryConfig.postcodeMaxLength) {
      return false;
    }
    if (countryConfig.postcodeRegex) {
      try {
        const regex = new RegExp(countryConfig.postcodeRegex);
        return regex.test(postalCode);
      } catch (error) {
        this.logger.error("Invalid postal code regex:", error);
        return true;
      }
    }
    return true;
  }
  /**
   * Format postal code based on country configuration
   * Applies formatting pattern from CDN (e.g., "XXX XXX" for Canadian postal codes)
   */
  formatPostalCode(postalCode, countryConfig) {
    if (!postalCode) {
      return postalCode;
    }
    const hasLetters = /[a-zA-Z]/.test(postalCode);
    if (!countryConfig.postcodeFormat) {
      if (hasLetters) {
        return postalCode.toUpperCase();
      }
      return postalCode;
    }
    const cleanCode = postalCode.replace(/[^a-zA-Z0-9]/g, "").toUpperCase();
    if (!cleanCode) {
      return postalCode;
    }
    const format = countryConfig.postcodeFormat;
    let formatted = "";
    let charIndex = 0;
    for (let i = 0; i < format.length && charIndex < cleanCode.length; i++) {
      const formatChar = format[i];
      if (formatChar === "N" || formatChar === "X" || formatChar === "#" || formatChar === "9" || formatChar === "A") {
        formatted += cleanCode[charIndex];
        charIndex++;
      } else {
        formatted += formatChar;
      }
    }
    if (charIndex < cleanCode.length) {
      formatted += cleanCode.substring(charIndex);
    }
    return formatted;
  }
  /**
   * Clear all cached data
   */
  clearCache() {
    try {
      const keysToRemove = [];
      for (let i = 0; i < sessionStorage.length; i++) {
        const key = sessionStorage.key(i);
        if (key && key.startsWith(this.cachePrefix)) {
          keysToRemove.push(key);
        }
      }
      keysToRemove.forEach((key) => sessionStorage.removeItem(key));
      const localKeysToRemove = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith(this.cachePrefix)) {
          localKeysToRemove.push(key);
        }
      }
      localKeysToRemove.forEach((key) => localStorage.removeItem(key));
      this.logger.debug(
        `Country service cache cleared (${keysToRemove.length} session + ${localKeysToRemove.length} local entries)`
      );
    } catch (error) {
      this.logger.warn("Failed to clear cache:", error);
    }
  }
  /**
   * Clear cache for a specific country
   */
  clearCountryCache(countryCode) {
    try {
      const cacheKey = this.cachePrefix + `states_${countryCode}`;
      localStorage.removeItem(cacheKey);
      sessionStorage.removeItem(cacheKey);
      this.logger.debug(`Cache cleared for country: ${countryCode}`);
    } catch (error) {
      this.logger.warn(
        `Failed to clear cache for country ${countryCode}:`,
        error
      );
    }
  }
  getFromCache(key, useLocalStorage = false) {
    try {
      const cacheKey = this.cachePrefix + key;
      const storage = useLocalStorage ? localStorage : sessionStorage;
      const cached = storage.getItem(cacheKey);
      if (!cached) return null;
      const { data, timestamp } = JSON.parse(cached);
      const now = Date.now();
      if (now - timestamp > this.cacheExpiry) {
        storage.removeItem(cacheKey);
        return null;
      }
      return data;
    } catch (error) {
      this.logger.warn("Failed to read from cache:", error);
      return null;
    }
  }
  setCache(key, data, useLocalStorage = false) {
    try {
      const cacheKey = this.cachePrefix + key;
      const cacheData = {
        data,
        timestamp: Date.now()
      };
      const storage = useLocalStorage ? localStorage : sessionStorage;
      storage.setItem(cacheKey, JSON.stringify(cacheData));
    } catch (error) {
      this.logger.warn("Failed to write to cache:", error);
    }
  }
  getDefaultCountryConfig(countryCode) {
    const configs = {
      US: {
        stateLabel: "State",
        stateRequired: true,
        postcodeLabel: "ZIP Code",
        postcodeRegex: "^\\d{5}(-\\d{4})?$",
        postcodeMinLength: 5,
        postcodeMaxLength: 10,
        postcodeExample: "12345 or 12345-6789",
        postcodeFormat: null,
        currencyCode: "USD",
        currencySymbol: "$"
      },
      CA: {
        stateLabel: "Province",
        stateRequired: true,
        postcodeLabel: "Postal Code",
        postcodeRegex: "^[A-Z]\\d[A-Z] ?\\d[A-Z]\\d$",
        postcodeMinLength: 6,
        postcodeMaxLength: 7,
        postcodeExample: "K1A 0B1",
        postcodeFormat: null,
        currencyCode: "CAD",
        currencySymbol: "$"
      },
      GB: {
        stateLabel: "County",
        stateRequired: false,
        postcodeLabel: "Postcode",
        postcodeRegex: "^[A-Z]{1,2}\\d{1,2}[A-Z]?\\s?\\d[A-Z]{2}$",
        postcodeMinLength: 5,
        postcodeMaxLength: 8,
        postcodeExample: "SW1A 1AA",
        postcodeFormat: null,
        currencyCode: "GBP",
        currencySymbol: "£"
      }
    };
    return configs[countryCode] || {
      stateLabel: "State/Province",
      stateRequired: false,
      postcodeLabel: "Postal Code",
      postcodeRegex: null,
      postcodeMinLength: 2,
      postcodeMaxLength: 20,
      postcodeExample: null,
      postcodeFormat: null,
      currencyCode: "USD",
      currencySymbol: "$"
    };
  }
  getFallbackLocationData() {
    return {
      detectedCountryCode: "US",
      detectedCountryConfig: this.getDefaultCountryConfig("US"),
      detectedStates: [],
      countries: [
        {
          code: "US",
          name: "United States",
          phonecode: "+1",
          currencyCode: "USD",
          currencySymbol: "$"
        },
        {
          code: "CA",
          name: "Canada",
          phonecode: "+1",
          currencyCode: "CAD",
          currencySymbol: "$"
        },
        {
          code: "GB",
          name: "United Kingdom",
          phonecode: "+44",
          currencyCode: "GBP",
          currencySymbol: "£"
        },
        {
          code: "AU",
          name: "Australia",
          phonecode: "+61",
          currencyCode: "AUD",
          currencySymbol: "$"
        },
        {
          code: "DE",
          name: "Germany",
          phonecode: "+49",
          currencyCode: "EUR",
          currencySymbol: "€"
        }
      ]
    };
  }
  /**
   * Apply country filtering based on configuration and campaign settings
   *
   * COUNTRY FILTERING PRIORITY:
   * 1. Campaign API (available_shipping_countries) - Highest priority ⭐
   *    - Set via setCampaignShippingCountries() in SDKInitializer and CheckoutFormEnhancer
   *    - Ensures dropdown matches actual campaign shipping capabilities
   *    - Example: ["US", "CA", "GB", "AU", "BR"]
   *
   * 2. Custom countries list (config.countries)
   *    - Full control over country code and displayed name
   *    - Example: [{ code: "US", name: "United States" }]
   *
   * 3. showCountries filter (config.showCountries) - Deprecated, legacy fallback
   *    - Simple country code whitelist
   *    - Example: ["US", "CA", "GB"]
   *    - Only used if campaign API doesn't provide countries
   *
   * FALLBACK COUNTRY PRIORITY (when detected country not available):
   * 1. United States (US) - if available in filtered list
   * 2. First country in filtered list - if US not available
   * 3. config.defaultCountry - only if filtered list is empty (edge case)
   *
   * IMPORTANT NOTES:
   * - dontShowStates: Always applied to filter out unwanted states/provinces
   * - Currency: Preserved from user's detected location (not affected by country filtering)
   * - Example: Canadian user with US-only shipping will see USD prices but CAD currency symbol
   */
  async applyCountryFiltering(data) {
    let filteredCountries = [...data.countries];
    if (this.campaignShippingCountries && this.campaignShippingCountries.length > 0) {
      this.logger.info(
        "✅ Filtering countries based on campaign API (available_shipping_countries):",
        this.campaignShippingCountries
      );
      filteredCountries = filteredCountries.filter(
        (country) => this.campaignShippingCountries.includes(country.code)
      );
    } else if (this.config.countries && this.config.countries.length > 0) {
      this.logger.info(
        "Using custom countries list from addressConfig.countries"
      );
      filteredCountries = this.config.countries.map((customCountry) => ({
        code: customCountry.code,
        name: customCountry.name,
        phonecode: "",
        currencyCode: "USD",
        currencySymbol: "$"
      }));
    } else if (this.config.showCountries && this.config.showCountries.length > 0) {
      this.logger.warn(
        "⚠️ Using deprecated showCountries config. Please use campaign API instead."
      );
      this.logger.info(
        "Filtering countries based on addressConfig.showCountries (legacy):",
        this.config.showCountries
      );
      filteredCountries = filteredCountries.filter(
        (country) => this.config.showCountries.includes(country.code)
      );
    }
    const originalDetectedCountryConfig = data.detectedCountryConfig;
    let detectedCountryCode = data.detectedCountryCode;
    let detectedCountryConfig = data.detectedCountryConfig;
    const detectedCountryAllowed = filteredCountries.some(
      (country) => country.code === detectedCountryCode
    );
    if (!detectedCountryCode || !detectedCountryAllowed) {
      let fallbackCountryCode;
      const usExists = filteredCountries.some((country) => country.code === "US");
      if (usExists) {
        fallbackCountryCode = "US";
        this.logger.info(
          `✅ Detected country (${detectedCountryCode}) not available for shipping. Using fallback: United States (US)`
        );
      } else if (filteredCountries.length > 0) {
        fallbackCountryCode = filteredCountries[0].code;
        this.logger.info(
          `✅ Detected country (${detectedCountryCode}) not available and US not in list. Using first available country: ${fallbackCountryCode}`
        );
      } else if (this.config.defaultCountry) {
        fallbackCountryCode = this.config.defaultCountry;
        this.logger.warn(
          `⚠️ No countries available in filtered list. Using config defaultCountry: ${this.config.defaultCountry}`
        );
      }
      if (fallbackCountryCode) {
        this.logger.info(
          `Preserving detected currency: ${originalDetectedCountryConfig.currencyCode} from detected location: ${data.detectedCountryCode}`
        );
        detectedCountryCode = fallbackCountryCode;
        detectedCountryConfig = originalDetectedCountryConfig;
      }
    } else if (detectedCountryCode && detectedCountryAllowed) {
      this.logger.info(
        `✅ Using detected country: ${detectedCountryCode} (available for shipping)`
      );
    }
    return {
      ...data,
      countries: filteredCountries,
      detectedCountryCode,
      detectedCountryConfig
      // This will be the original detected config for currency
    };
  }
  applyStateFiltering(states) {
    const US_TERRITORIES_TO_HIDE = [
      "AS",
      "UM-81",
      "GU",
      "UM-84",
      "UM-86",
      "UM-67",
      "UM-89",
      "UM-71",
      "UM-76",
      "MP",
      "UM-95",
      "PR",
      "UM",
      "VI",
      "UM-79"
    ];
    let filteredStates = states.filter(
      (state) => !US_TERRITORIES_TO_HIDE.includes(state.code)
    );
    if (this.config.dontShowStates && this.config.dontShowStates.length > 0) {
      filteredStates = filteredStates.filter(
        (state) => !this.config.dontShowStates.includes(state.code)
      );
    }
    return filteredStates;
  }
}
const MAX_RECORDS = 250;
let recordCounter = 0;
class AnalyticsDebugTracker {
  constructor() {
    this.providers = /* @__PURE__ */ new Set();
    this.deliveries = [];
    this.listeners = /* @__PURE__ */ new Set();
  }
  static getInstance() {
    if (!AnalyticsDebugTracker.instance) {
      AnalyticsDebugTracker.instance = new AnalyticsDebugTracker();
    }
    return AnalyticsDebugTracker.instance;
  }
  /**
   * Subscribe to changes (new/updated/cleared deliveries, provider
   * registration). Lets the debug panels re-render only when something actually
   * changed instead of polling on a timer. Returns an unsubscribe function.
   */
  subscribe(listener) {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }
  /** Notify subscribers that the tracked data changed. */
  notify() {
    this.listeners.forEach((listener) => {
      try {
        listener();
      } catch {
      }
    });
  }
  /** Register a live adapter so the Provider Status panel can enumerate it. */
  registerProvider(provider) {
    this.providers.add(provider);
    this.notify();
  }
  /** Remove an adapter (e.g. on teardown). */
  unregisterProvider(provider) {
    this.providers.delete(provider);
    this.notify();
  }
  /** Current status of every registered provider. */
  getProviders() {
    return Array.from(this.providers).map((provider) => provider.getDebugInfo());
  }
  /**
   * Record a delivery attempt. Returns the record id so an async provider can
   * later resolve it via {@link update}.
   */
  record(provider, eventName, status, opts = {}) {
    const id = `dlv_${++recordCounter}`;
    this.deliveries.push({
      id,
      provider,
      eventName,
      status,
      timestamp: Date.now(),
      eventId: opts.eventId,
      detail: opts.detail,
      error: opts.error,
      payload: opts.payload
    });
    if (this.deliveries.length > MAX_RECORDS) {
      this.deliveries.splice(0, this.deliveries.length - MAX_RECORDS);
    }
    this.notify();
    return id;
  }
  /** Resolve a previously recorded `pending` delivery. */
  update(id, status, opts = {}) {
    const record = this.deliveries.find((delivery) => delivery.id === id);
    if (!record) return;
    record.status = status;
    record.durationMs = Date.now() - record.timestamp;
    if (opts.detail !== void 0) record.detail = opts.detail;
    if (opts.error !== void 0) record.error = opts.error;
    if (opts.sentPayload !== void 0) record.sentPayload = opts.sentPayload;
    this.notify();
  }
  /** All delivery records, oldest first. */
  getDeliveries() {
    return this.deliveries;
  }
  /** Clear the delivery log (provider registrations are kept). */
  clear() {
    this.deliveries = [];
    this.notify();
  }
}
const analyticsDebug = AnalyticsDebugTracker.getInstance();
const _CurrencyFormatter = class _CurrencyFormatter {
  /**
   * Get the current currency from stores
   */
  static getCurrentCurrency() {
    return useCampaignStore.getState()?.currency ?? configStore.getState().getCurrency();
  }
  /**
   * Get the user's locale (checking for override first)
   */
  static getUserLocale() {
    const selectedLocale = sessionStorage.getItem("next_selected_locale");
    if (selectedLocale) {
      return selectedLocale;
    }
    return navigator.language || "en-US";
  }
  /**
   * Clear all cached formatters (call when locale or currency changes)
   */
  static clearCache() {
    this.formatters.clear();
    this.formattersNoZeroCents.clear();
    this.numberFormatter = null;
  }
  /**
   * Get or create a currency formatter
   */
  static getCurrencyFormatter(currency, hideZeroCents = false) {
    const locale = this.getUserLocale();
    const key = `${locale}-${currency}-${hideZeroCents}`;
    const cache = hideZeroCents ? this.formattersNoZeroCents : this.formatters;
    if (!cache.has(key)) {
      const options = {
        style: "currency",
        currency,
        currencyDisplay: "narrowSymbol"
        // Use narrowSymbol to avoid A$, CA$, etc.
      };
      if (hideZeroCents) {
        options.minimumFractionDigits = 0;
        options.maximumFractionDigits = 2;
      }
      cache.set(key, new Intl.NumberFormat(locale, options));
    }
    return cache.get(key);
  }
  /**
   * Get or create a number formatter
   */
  static getNumberFormatter() {
    const locale = this.getUserLocale();
    if (!this.numberFormatter) {
      this.numberFormatter = new Intl.NumberFormat(locale, {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
      });
    }
    return this.numberFormatter;
  }
  /**
   * Format a value as currency
   */
  static formatCurrency(value, currency, options) {
    const numValue = typeof value === "string" ? parseFloat(value) : value;
    if (isNaN(numValue)) {
      return "";
    }
    const currencyCode = currency || this.getCurrentCurrency();
    const formatter = this.getCurrencyFormatter(
      currencyCode,
      options?.hideZeroCents
    );
    return formatter.format(numValue);
  }
  /**
   * Format a number (non-currency)
   */
  static formatNumber(value) {
    const numValue = typeof value === "string" ? parseFloat(value) : value;
    if (isNaN(numValue)) {
      return "";
    }
    return this.getNumberFormatter().format(numValue);
  }
  /**
   * Format a percentage
   */
  static formatPercentage(value, decimals = 0) {
    return `${Math.round(value * Math.pow(10, decimals)) / Math.pow(10, decimals)}%`;
  }
  /**
   * Extract currency symbol from current currency
   */
  static getCurrencySymbol(currency) {
    const currencyCode = currency || this.getCurrentCurrency();
    const formatter = this.getCurrencyFormatter(currencyCode);
    const formatted = formatter.format(0);
    return formatted.replace(/[0-9.,\s]/g, "").trim();
  }
  /**
   * Check if a string is already formatted with the current currency
   */
  static isAlreadyFormatted(value, currency) {
    if (typeof value !== "string") return false;
    const symbol = this.getCurrencySymbol(currency);
    return value.includes(symbol);
  }
};
_CurrencyFormatter.formatters = /* @__PURE__ */ new Map();
_CurrencyFormatter.formattersNoZeroCents = /* @__PURE__ */ new Map();
_CurrencyFormatter.numberFormatter = null;
let CurrencyFormatter = _CurrencyFormatter;
const formatCurrency = CurrencyFormatter.formatCurrency.bind(CurrencyFormatter);
const formatNumber = CurrencyFormatter.formatNumber.bind(CurrencyFormatter);
const formatPercentage = CurrencyFormatter.formatPercentage.bind(CurrencyFormatter);
CurrencyFormatter.getCurrencySymbol.bind(CurrencyFormatter);
function formatDiscountPercentage(value) {
  if (value == null || value === "") return "";
  const n = parseFloat(value);
  if (!Number.isFinite(n)) return "";
  return formatPercentage(n, Number.isInteger(n) ? 0 : 2);
}
const currencyFormatter = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  CurrencyFormatter,
  formatCurrency,
  formatDiscountPercentage,
  formatNumber,
  formatPercentage
});
class DebugEventManager {
  constructor() {
    this.eventLog = [];
    this.maxEvents = 100;
    this.initializeEventCapture();
  }
  initializeEventCapture() {
    const events = [
      "next:cart-updated",
      "next:checkout-step",
      "next:item-added",
      "next:item-removed",
      "next:timer-expired",
      "next:validation-error",
      "next:payment-success",
      "next:payment-error"
    ];
    events.forEach((eventType) => {
      document.addEventListener(eventType, (e) => {
        this.logEvent(eventType.replace("next:", ""), e.detail, "CustomEvent");
      });
    });
    this.interceptFetch();
  }
  interceptFetch() {
    const originalFetch = window.fetch;
    window.fetch = async (...args) => {
      const url = args[0].toString();
      if (url.includes("29next.com") || url.includes("campaigns.")) {
        this.logEvent("api-request", {
          url,
          method: args[1]?.method || "GET"
        }, "API");
      }
      return originalFetch.apply(window, args);
    };
  }
  logEvent(type, data, source) {
    this.eventLog.push({
      timestamp: /* @__PURE__ */ new Date(),
      type,
      data,
      source
    });
    if (this.eventLog.length > this.maxEvents) {
      this.eventLog.shift();
    }
  }
  getEvents(limit) {
    const events = limit ? this.eventLog.slice(-limit) : this.eventLog;
    return events.reverse();
  }
  clearEvents() {
    this.eventLog = [];
  }
  exportEvents() {
    return JSON.stringify(this.eventLog, null, 2);
  }
}
class EnhancedDebugUI {
  static createOverlayHTML(panels, activePanel, isExpanded, activePanelTab) {
    const activePanelData = panels.find((p) => p.id === activePanel);
    return `
      <div class="enhanced-debug-overlay ${isExpanded ? "expanded" : "collapsed"}">
        ${this.createBottomBar(isExpanded)}
        ${isExpanded ? this.createExpandedContent(panels, activePanelData, activePanel, activePanelTab) : ""}
      </div>
    `;
  }
  static createBottomBar(isExpanded) {
    return `
      <div class="debug-bottom-bar">
        <div class="debug-logo-section">
          ${this.getNextCommerceLogo()}
          <span class="debug-title">Debug Tools</span>
          <div class="debug-status">
            <div class="status-indicator active"></div>
            <span class="status-text">Active</span>
          </div>
        </div>
        
        <div class="debug-quick-stats">
          <div class="stat-item">
            <span class="stat-value" data-debug-stat="cart-items">0</span>
            <span class="stat-label">Items</span>
          </div>
          <div class="stat-item">
            <span class="stat-value" data-debug-stat="cart-total">$0.00</span>
            <span class="stat-label">Total</span>
          </div>
          <div class="stat-item">
            <span class="stat-value" data-debug-stat="enhanced-elements">0</span>
            <span class="stat-label">Enhanced</span>
          </div>
        </div>

        <div class="debug-controls">
          <button class="debug-control-btn" data-action="toggle-mini-cart" title="Toggle Mini Cart">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17,18C15.89,18 15,18.89 15,20A2,2 0 0,0 17,22A2,2 0 0,0 19,20C19,18.89 18.1,18 17,18M1,2V4H3L6.6,11.59L5.24,14.04C5.09,14.32 5,14.65 5,15A2,2 0 0,0 7,17H19V15H7.42A0.25,0.25 0 0,1 7.17,14.75C7.17,14.7 7.18,14.66 7.2,14.63L8.1,13H15.55C16.3,13 16.96,12.58 17.3,11.97L20.88,5.5C20.95,5.34 21,5.17 21,5A1,1 0 0,0 20,4H5.21L4.27,2M7,18C5.89,18 5,18.89 5,20A2,2 0 0,0 7,22A2,2 0 0,0 9,20C9,18.89 8.1,18 7,18Z"/>
            </svg>
          </button>
          <button class="debug-control-btn" data-action="clear-cart" title="Clear Cart">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
            </svg>
          </button>
          <button class="debug-control-btn" data-action="toggle-xray" title="Toggle X-Ray View">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M5 3C3.89 3 3 3.9 3 5V19C3 20.11 3.89 21 5 21H19C20.11 21 21 20.11 21 19V5C21 3.9 20.11 3 19 3H5M5 5H19V19H5V5M7 7V9H9V7H7M11 7V9H13V7H11M15 7V9H17V7H15M7 11V13H9V11H7M11 11V13H13V11H11M15 11V13H17V11H15M7 15V17H9V15H7M11 15V17H13V15H11M15 15V17H17V15H15Z"/>
            </svg>
          </button>
          <button class="debug-control-btn" data-action="export-data" title="Export Debug Data">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M5,20H19V18H5M19,9H15V3H9V9H5L12,16L19,9Z"/>
            </svg>
          </button>
          <button class="debug-expand-btn" data-action="toggle-expand" title="${isExpanded ? "Collapse" : "Expand"}">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" class="expand-icon ${isExpanded ? "rotated" : ""}">
              <path d="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z"/>
            </svg>
          </button>
          <button class="debug-control-btn close-btn" data-action="close" title="Close Debug Tools">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"/>
            </svg>
          </button>
        </div>
      </div>
    `;
  }
  static createExpandedContent(panels, activePanel, activePanelId, activePanelTab) {
    return `
      <div class="debug-expanded-content">
        <div class="debug-sidebar">
          ${this.createPanelTabs(panels, activePanelId)}
        </div>
        
        <div class="debug-main-content">
          ${this.createPanelContent(activePanel, activePanelTab)}
        </div>
      </div>
    `;
  }
  static createPanelTabs(panels, activePanel) {
    return `
      <div class="debug-panel-tabs">
        ${panels.map((panel) => `
          <button class="debug-panel-tab ${panel.id === activePanel ? "active" : ""}" 
                  data-panel="${panel.id}">
            <span class="tab-icon">${panel.icon}</span>
            <span class="tab-label">${panel.title}</span>
            ${panel.id === "events" ? '<div class="tab-badge" data-debug-badge="events">0</div>' : ""}
          </button>
        `).join("")}
      </div>
    `;
  }
  static createPanelContent(activePanel, activePanelTab) {
    if (!activePanel) return "";
    const tabs = activePanel.getTabs?.() || [];
    const hasHorizontalTabs = tabs.length > 0;
    if (hasHorizontalTabs) {
      const activeTabId = activePanelTab || tabs[0]?.id;
      const activeTab = tabs.find((tab) => tab.id === activeTabId) || tabs[0];
      return `
        <div class="debug-panel-container">
          <div class="panel-header">
            <div class="panel-title">
              <span class="panel-icon">${activePanel.icon}</span>
              <h2>${activePanel.title}</h2>
            </div>
            ${activePanel.getActions ? `
              <div class="panel-actions">
                ${activePanel.getActions().map((action) => `
                  <button class="panel-action-btn ${action.variant || "primary"}" 
                          data-panel-action="${action.label}">
                    ${action.label}
                  </button>
                `).join("")}
              </div>
            ` : ""}
          </div>
          
          <div class="panel-horizontal-tabs">
            ${tabs.map((tab) => `
              <button class="horizontal-tab ${tab.id === activeTabId ? "active" : ""}" 
                      data-panel-tab="${tab.id}">
                ${tab.icon ? `<span class="tab-icon">${tab.icon}</span>` : ""}
                <span class="tab-label">${tab.label}</span>
              </button>
            `).join("")}
          </div>
          
          <div class="panel-content ${activePanel.id === "events" || activePanel.id === "event-timeline" || activePanel.id === "order" && activeTabId === "lines" || activeTabId === "raw" ? "no-padding" : ""}">
            ${activeTab ? activeTab.getContent() : ""}
          </div>
        </div>
      `;
    }
    return `
      <div class="debug-panel-container">
        <div class="panel-header">
          <div class="panel-title">
            <span class="panel-icon">${activePanel.icon}</span>
            <h2>${activePanel.title}</h2>
          </div>
          ${activePanel.getActions ? `
            <div class="panel-actions">
              ${activePanel.getActions().map((action) => `
                <button class="panel-action-btn ${action.variant || "primary"}" 
                        data-panel-action="${action.label}">
                  ${action.label}
                </button>
              `).join("")}
            </div>
          ` : ""}
        </div>
        <div class="panel-content ${activePanel.id === "events" || activePanel.id === "event-timeline" || activePanel.id === "order" ? "no-padding" : ""}">
          ${activePanel.getContent()}
        </div>
      </div>
    `;
  }
  static getNextCommerceLogo() {
    return `
      <svg class="debug-logo" width="32" height="32" viewBox="0 0 115.4 101.9" fill="none">
        <defs>
          <style>
            .st0 {
              fill: currentColor;
              stroke: currentColor;
              stroke-width: 2.5px;
            }
          </style>
        </defs>
        <path class="st0" d="M83.5,58.3l-1.9-1.3L27.2,21.2c-.7-.4-1.4-.6-2-.6-2,0-3.6,1.6-3.6,3.6v53.4c0,2,1.6,3.6,3.6,3.6h3.8v12.3h-3.8c-8.8,0-15.8-7.1-15.8-15.8V24.3c0-8.8,7.1-15.8,15.8-15.8,3.1,0,6.2.9,8.7,2.6h0l49,33.4.5.4v13.5ZM90.2,8.4c8.8,0,15.8,7.1,15.8,15.8v53.4c0,8.8-7.1,15.8-15.8,15.8s-6.2-.9-8.7-2.6h0l-49-33.4-.5-.4v-13.5l1.9,1.3,54.3,35.7c.7.4,1.4.7,2,.7,2,0,3.6-1.6,3.6-3.6V24.3c0-2-1.6-3.6-3.6-3.6h-3.8v-12.3h3.8Z"/>
      </svg>
    `;
  }
  static addStyles() {
    console.log("Debug styles loaded via CSS modules");
  }
  static removeStyles() {
    console.log("Debug styles will be cleaned up by DebugStyleLoader");
  }
}
function generateXrayStyles() {
  return `
    /* X-RAY WIREFRAME CSS - PURE CSS, NO JS */

    /* Subtle outlines for all data attributes */
    [data-next-display],
    [data-next-show],
    [data-next-checkout],
    [data-next-selector-id],
    [data-next-cart-selector],
    [data-next-selection-mode],
    [data-next-shipping-id],
    [data-next-selector-card],
    [data-next-package-id],
    [data-next-quantity],
    [data-next-selected],
    [data-next-await],
    [data-next-in-cart],
    [data-next-express-checkout],
    [data-next-payment-method],
    [data-next-checkout-field],
    [data-next-payment-form],
    [data-next-bundle-id],
    [data-next-bundle-card] {
      position: relative !important;
      outline: 1px dashed rgba(0, 0, 0, 0.3) !important;
      outline-offset: -1px !important;
    }

    /* Color coding for different attribute types */
    [data-next-display] {
      outline-color: #4ecdc4 !important;
    }

    [data-next-show] {
      outline-color: #ffe66d !important;
    }

    [data-next-checkout] {
      outline-color: #ff6b6b !important;
    }

    [data-next-selector-id] {
      outline-color: #a8e6cf !important;
    }

    [data-next-selector-card] {
      outline-color: #95e1d3 !important;
    }

    [data-next-in-cart] {
      outline-color: #c7ceea !important;
    }

    [data-next-selected] {
      outline-color: #ffa502 !important;
    }

    [data-next-package-id] {
      outline-color: #ff8b94 !important;
    }

    [data-next-bundle-id],
    [data-next-bundle-card] {
      outline-color: #8e44ad !important;
    }

    /* Small corner labels */
    [data-next-selector-id]::before {
      content: attr(data-next-selector-id) !important;
      position: absolute !important;
      top: 2px !important;
      right: 2px !important;
      background: rgba(168, 230, 207, 0.9) !important;
      color: #333 !important;
      padding: 2px 4px !important;
      font-size: 9px !important;
      font-family: monospace !important;
      line-height: 1 !important;
      border-radius: 2px !important;
      pointer-events: none !important;
      z-index: 10 !important;
    }

    [data-next-package-id]::before {
      content: "PKG " attr(data-next-package-id) !important;
      position: absolute !important;
      top: 2px !important;
      left: 2px !important;
      background: rgba(255, 139, 148, 0.9) !important;
      color: white !important;
      padding: 2px 4px !important;
      font-size: 9px !important;
      font-family: monospace !important;
      font-weight: bold !important;
      line-height: 1 !important;
      border-radius: 2px !important;
      pointer-events: none !important;
      z-index: 10 !important;
    }

    [data-next-bundle-id]::before {
      content: "BUNDLE " attr(data-next-bundle-id) !important;
      position: absolute !important;
      top: 2px !important;
      left: 2px !important;
      background: rgba(142, 68, 173, 0.9) !important;
      color: white !important;
      padding: 2px 4px !important;
      font-size: 9px !important;
      font-family: monospace !important;
      font-weight: bold !important;
      line-height: 1 !important;
      border-radius: 2px !important;
      pointer-events: none !important;
      z-index: 10 !important;
    }

    /* Special highlighting for active states */
    [data-next-selected="true"] {
      outline-width: 2px !important;
      outline-style: solid !important;
    }

    [data-next-in-cart="true"] {
      background-color: rgba(199, 206, 234, 0.1) !important;
    }

    /* Hover tooltips */
    [data-next-display]:hover::after,
    [data-next-show]:hover::after,
    [data-next-selector-card]:hover::after,
    [data-next-bundle-id]:hover::after {
      position: absolute !important;
      z-index: 99999 !important;
      pointer-events: none !important;
      font-family: monospace !important;
      font-size: 10px !important;
      padding: 4px 6px !important;
      border-radius: 3px !important;
      white-space: nowrap !important;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2) !important;
      bottom: 100% !important;
      left: 0 !important;
      margin-bottom: 4px !important;
    }

    [data-next-display]:hover::after {
      content: "display: " attr(data-next-display) !important;
      background: #4ecdc4 !important;
      color: white !important;
    }

    [data-next-show]:hover::after {
      content: "show: " attr(data-next-show) !important;
      background: #ffe66d !important;
      color: #333 !important;
    }

    [data-next-selector-card]:hover::after {
      content: "pkg:" attr(data-next-package-id) " | selected:" attr(data-next-selected) " | in-cart:" attr(data-next-in-cart) !important;
      background: #95e1d3 !important;
      color: #333 !important;
    }
  `;
}
const _XrayManager = class _XrayManager {
  static initialize() {
    const savedState = localStorage.getItem(this.STORAGE_KEY);
    if (savedState === "true") {
      this.activate();
    }
  }
  static toggle() {
    if (this.isActive) {
      this.deactivate();
    } else {
      this.activate();
    }
    return this.isActive;
  }
  static activate() {
    if (this.isActive) return;
    this.styleElement = document.createElement("style");
    this.styleElement.id = "debug-xray-styles";
    this.styleElement.textContent = generateXrayStyles();
    document.head.appendChild(this.styleElement);
    document.body.classList.add("debug-xray-active");
    this.isActive = true;
    localStorage.setItem(this.STORAGE_KEY, "true");
    console.log("🔍 X-Ray mode activated");
  }
  static deactivate() {
    if (!this.isActive) return;
    if (this.styleElement) {
      this.styleElement.remove();
      this.styleElement = null;
    }
    document.body.classList.remove("debug-xray-active");
    this.isActive = false;
    localStorage.setItem(this.STORAGE_KEY, "false");
    console.log("🔍 X-Ray mode deactivated");
  }
  static isXrayActive() {
    return this.isActive;
  }
};
_XrayManager.styleElement = null;
_XrayManager.isActive = false;
_XrayManager.STORAGE_KEY = "debug-xray-active";
let XrayManager = _XrayManager;
class CurrencySelector {
  constructor() {
    this.container = null;
    this.shadowRoot = null;
    this.logger = new Logger("CurrencySelector");
    this.isChanging = false;
    this.listenersAttached = false;
    this.renderDebounceTimer = null;
    this.hasInitiallyRendered = false;
  }
  static getInstance() {
    if (!CurrencySelector.instance) {
      CurrencySelector.instance = new CurrencySelector();
    }
    return CurrencySelector.instance;
  }
  initialize() {
    const configStore$1 = configStore.getState();
    if (!configStore$1.debug) {
      return;
    }
    this.createContainer();
    this.render();
    this.setupEventListeners();
    this.setupStoreSubscriptions();
    this.logger.info("Currency selector initialized");
  }
  setupStoreSubscriptions() {
    const unsubscribe = useCampaignStore.subscribe((state, prevState) => {
      if (this.isChanging) {
        return;
      }
      const currencyChanged = state.currency !== prevState?.currency;
      const dataLoaded = !prevState?.data && state.data;
      if (currencyChanged || dataLoaded) {
        this.logger.debug("Campaign currency changed or data loaded, re-rendering currency selector");
        this.render();
      }
    });
    this._unsubscribeCampaign = unsubscribe;
  }
  createContainer() {
    if (this.container) {
      this.container.remove();
    }
    this.container = document.createElement("div");
    this.container.id = "debug-currency-selector";
    this.container.style.cssText = `
      position: relative;
      pointer-events: auto;
    `;
    this.shadowRoot = this.container.attachShadow({ mode: "open" });
    document.body.appendChild(this.container);
  }
  getAvailableCurrencies() {
    const campaignStore = useCampaignStore.getState();
    if (campaignStore.data?.available_currencies && campaignStore.data.available_currencies.length > 0) {
      return campaignStore.data.available_currencies;
    }
    return [
      { code: "USD", label: "$ USD" },
      { code: "EUR", label: "€ EUR" },
      { code: "GBP", label: "£ GBP" }
    ];
  }
  render() {
    if (this.renderDebounceTimer) {
      clearTimeout(this.renderDebounceTimer);
    }
    this.renderDebounceTimer = setTimeout(() => {
      this.doRender();
    }, 50);
  }
  doRender() {
    if (!this.shadowRoot) return;
    const configStore$1 = configStore.getState();
    const campaignStore = useCampaignStore.getState();
    const currentCurrency = configStore$1.getCurrency();
    const availableCurrencies = this.getAvailableCurrencies();
    if (!campaignStore.data) {
      this.logger.debug("No campaign data available yet, skipping currency selector render");
      setTimeout(() => this.doRender(), 1e3);
      return;
    }
    if (availableCurrencies.length <= 1) {
      this.logger.debug("Only one currency available, hiding currency selector");
      if (this.container) {
        this.container.style.display = "none";
      }
      return;
    }
    if (this.container) {
      this.container.style.display = "block";
    }
    const detectedCurrency = configStore$1.detectedCurrency;
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        .currency-selector {
          background: linear-gradient(135deg, #222 0%, #1a1a1a 100%);
          backdrop-filter: blur(10px);
          border: 1px solid #333;
          border-radius: 4px;
          padding: 4px 8px;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
          transition: all 0.2s ease;
        }

        .currency-selector:hover {
          background: linear-gradient(135deg, #2a2a2a 0%, #222 100%);
          border-color: #444;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
        }

        .currency-label {
          color: rgba(255, 255, 255, 0.9);
          font-size: 11px;
          font-weight: 500;
          white-space: nowrap;
        }

        .currency-select {
          appearance: none;
          background: #2a2a2a;
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 3px;
          padding: 2px 20px 2px 6px;
          font-size: 11px;
          font-weight: 500;
          color: rgba(255, 255, 255, 0.9);
          cursor: pointer;
          min-width: 60px;
        }

        .currency-select option {
          background: #2a2a2a;
          color: rgba(255, 255, 255, 0.9);
          padding: 4px;
        }

        .currency-select:hover {
          background: #333;
          border-color: rgba(255, 255, 255, 0.3);
        }

        .currency-select:focus {
          outline: none;
          border-color: #4299e1;
          background: #333;
        }

        .currency-select:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .select-wrapper {
          position: relative;
          display: flex;
          align-items: center;
        }

        .select-arrow {
          position: absolute;
          right: 4px;
          top: 50%;
          transform: translateY(-50%);
          pointer-events: none;
          color: rgba(255, 255, 255, 0.6);
          width: 10px;
          height: 10px;
        }

        .loading-indicator {
          display: none;
          width: 10px;
          height: 10px;
          border: 1px solid #cbd5e0;
          border-top-color: #4299e1;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }

        .loading-indicator.active {
          display: inline-block;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        .detected-info {
          color: rgba(255, 255, 255, 0.5);
          font-size: 10px;
          font-weight: 400;
          white-space: nowrap;
          padding-left: 6px;
          border-left: 1px solid rgba(255, 255, 255, 0.2);
        }

        .detected-value {
          color: rgba(255, 255, 255, 0.8);
          font-weight: 500;
        }
      </style>

      <div class="currency-selector">
        <span class="currency-label">💱</span>
        
        <div class="select-wrapper">
          <select class="currency-select" id="currency-select">
            ${availableCurrencies.map((currency) => `
              <option value="${currency.code}" ${currency.code === currentCurrency ? "selected" : ""}>
                ${currency.code}
              </option>
            `).join("")}
          </select>
          <svg class="select-arrow" viewBox="0 0 24 24" fill="currentColor">
            <path d="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z"/>
          </svg>
        </div>

        <div class="loading-indicator" id="loading-indicator"></div>

        ${detectedCurrency ? `
          <div class="detected-info">
            Detected: <span class="detected-value">${detectedCurrency}</span>
          </div>
        ` : ""}
      </div>
    `;
    if (!this.hasInitiallyRendered) {
      this.hasInitiallyRendered = true;
    }
  }
  setupEventListeners() {
    if (!this.shadowRoot || this.listenersAttached) return;
    this.shadowRoot.addEventListener("change", async (e) => {
      const target = e.target;
      if (target && target.id === "currency-select") {
        const selectElement = target;
        const newCurrency = selectElement.value;
        if (this.isChanging) {
          this.logger.warn("Currency change already in progress");
          return;
        }
        this.logger.debug(`Currency select changed to: ${newCurrency}`);
        await this.handleCurrencyChange(newCurrency);
      }
    });
    document.addEventListener("next:currency-changed", (e) => {
      const customEvent = e;
      if (customEvent.detail?.source === "currency-selector") {
        return;
      }
      clearTimeout(this._rerenderTimeout);
      this._rerenderTimeout = setTimeout(() => {
        this.logger.debug("External currency change detected, re-rendering selector");
        this.render();
      }, 100);
    });
    this.listenersAttached = true;
    this.logger.debug("Event listeners attached to currency selector");
  }
  async handleCurrencyChange(newCurrency) {
    this.isChanging = true;
    const select = this.shadowRoot?.getElementById("currency-select");
    const loadingIndicator = this.shadowRoot?.getElementById("loading-indicator");
    if (select) select.disabled = true;
    if (loadingIndicator) loadingIndicator.classList.add("active");
    try {
      this.logger.info(`Changing currency to ${newCurrency}`);
      const configStore$1 = configStore.getState();
      const campaignStore = useCampaignStore.getState();
      const oldCurrency = configStore$1.getCurrency();
      configStore$1.updateConfig({
        selectedCurrency: newCurrency
      });
      sessionStorage.setItem("next_selected_currency", newCurrency);
      this.logger.info(`Saved currency preference to session: ${newCurrency}`);
      await campaignStore.loadCampaign(configStore$1.apiKey, { forceFresh: true });
      await cartOperations.refreshItemPrices();
      this.logger.info(`Currency changed successfully to ${newCurrency}`);
      document.dispatchEvent(new CustomEvent("next:currency-changed", {
        detail: {
          from: oldCurrency,
          to: newCurrency,
          source: "currency-selector"
        }
      }));
      document.dispatchEvent(new CustomEvent("debug:update-content"));
      this.showSuccessFeedback(newCurrency);
    } catch (error) {
      this.logger.error("Failed to change currency:", error);
      this.showErrorFeedback();
      const configStore$1 = configStore.getState();
      const currentCurrency = configStore$1.selectedCurrency || "USD";
      if (select) select.value = currentCurrency;
    } finally {
      this.isChanging = false;
      if (select) select.disabled = false;
      if (loadingIndicator) loadingIndicator.classList.remove("active");
    }
  }
  showSuccessFeedback(_currency) {
    const selector = this.shadowRoot?.querySelector(".currency-selector");
    if (!selector) return;
    selector.style.background = "linear-gradient(135deg, #10b981 0%, #059669 100%)";
    setTimeout(() => {
      selector.style.background = "linear-gradient(135deg, #222 0%, #1a1a1a 100%)";
    }, 1e3);
  }
  showErrorFeedback() {
    const selector = this.shadowRoot?.querySelector(".currency-selector");
    if (!selector) return;
    selector.style.background = "linear-gradient(135deg, #ef4444 0%, #dc2626 100%)";
    setTimeout(() => {
      selector.style.background = "linear-gradient(135deg, #222 0%, #1a1a1a 100%)";
    }, 1e3);
  }
  destroy() {
    if (this._unsubscribeCampaign) {
      this._unsubscribeCampaign();
      this._unsubscribeCampaign = null;
    }
    if (this.renderDebounceTimer) {
      clearTimeout(this.renderDebounceTimer);
    }
    if (this._rerenderTimeout) {
      clearTimeout(this._rerenderTimeout);
    }
    if (this.container) {
      this.container.remove();
      this.container = null;
      this.shadowRoot = null;
    }
  }
  hide() {
    if (this.container) {
      this.container.style.display = "none";
    }
  }
  show() {
    if (this.container) {
      this.container.style.display = "block";
    }
  }
}
const currencySelector = CurrencySelector.getInstance();
class CountrySelector {
  constructor() {
    this.container = null;
    this.shadowRoot = null;
    this.logger = new Logger("CountrySelector");
    this.isChanging = false;
    this.listenersAttached = false;
    this.renderDebounceTimer = null;
    this.hasInitiallyRendered = false;
    this.countries = [];
  }
  static getInstance() {
    if (!CountrySelector.instance) {
      CountrySelector.instance = new CountrySelector();
    }
    return CountrySelector.instance;
  }
  async initialize() {
    const configStore$1 = configStore.getState();
    if (!configStore$1.debug) {
      return;
    }
    await this.loadCountries();
    this.createContainer();
    this.render();
    this.setupEventListeners();
    this.logger.info("Country selector initialized");
  }
  async loadCountries() {
    try {
      const countryService = CountryService.getInstance();
      const locationData = await countryService.getLocationData();
      this.countries = locationData.countries || [];
      this.logger.debug(`Loaded ${this.countries.length} countries`);
    } catch (error) {
      this.logger.error("Failed to load countries:", error);
      this.countries = [];
    }
  }
  createContainer() {
    if (this.container) {
      this.container.remove();
    }
    this.container = document.createElement("div");
    this.container.id = "debug-country-selector";
    this.container.style.cssText = `
      position: relative;
      pointer-events: auto;
    `;
    this.shadowRoot = this.container.attachShadow({ mode: "open" });
    document.body.appendChild(this.container);
  }
  render() {
    if (this.renderDebounceTimer) {
      clearTimeout(this.renderDebounceTimer);
    }
    this.renderDebounceTimer = setTimeout(() => {
      this.doRender();
    }, 50);
  }
  doRender() {
    if (!this.shadowRoot) return;
    const configStore$1 = configStore.getState();
    const detectedCountry = configStore$1.detectedCountry || "US";
    const currentCountry = sessionStorage.getItem("next_selected_country") || detectedCountry;
    if (this.countries.length === 0) {
      this.logger.debug("No countries available, hiding country selector");
      if (this.container) {
        this.container.style.display = "none";
      }
      return;
    }
    if (this.container) {
      this.container.style.display = "block";
    }
    const rawDetectedCountry = configStore$1.detectedCountry;
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        .country-selector {
          background: linear-gradient(135deg, #222 0%, #1a1a1a 100%);
          backdrop-filter: blur(10px);
          border: 1px solid #333;
          border-radius: 4px;
          padding: 4px 8px;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
          transition: all 0.2s ease;
        }

        .country-selector:hover {
          background: linear-gradient(135deg, #2a2a2a 0%, #222 100%);
          border-color: #444;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
        }

        .country-label {
          color: rgba(255, 255, 255, 0.9);
          font-size: 11px;
          font-weight: 500;
          white-space: nowrap;
        }

        .country-select {
          appearance: none;
          background: #2a2a2a;
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 3px;
          padding: 2px 20px 2px 6px;
          font-size: 11px;
          font-weight: 500;
          color: rgba(255, 255, 255, 0.9);
          cursor: pointer;
          min-width: 80px;
          max-width: 120px;
        }

        .country-select option {
          background: #2a2a2a;
          color: rgba(255, 255, 255, 0.9);
          padding: 4px;
        }

        .country-select:hover {
          background: #333;
          border-color: rgba(255, 255, 255, 0.3);
        }

        .country-select:focus {
          outline: none;
          border-color: #4299e1;
          background: #333;
        }

        .country-select:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .select-wrapper {
          position: relative;
          display: flex;
          align-items: center;
        }

        .select-arrow {
          position: absolute;
          right: 4px;
          top: 50%;
          transform: translateY(-50%);
          pointer-events: none;
          color: rgba(255, 255, 255, 0.6);
          width: 10px;
          height: 10px;
        }

        .loading-indicator {
          display: none;
          width: 10px;
          height: 10px;
          border: 1px solid #cbd5e0;
          border-top-color: #4299e1;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }

        .loading-indicator.active {
          display: inline-block;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        .reset-button {
          background: rgba(239, 68, 68, 0.2);
          border: 1px solid rgba(239, 68, 68, 0.3);
          border-radius: 3px;
          color: #ff6b6b;
          padding: 2px 6px;
          font-size: 10px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .reset-button:hover {
          background: rgba(239, 68, 68, 0.3);
          border-color: rgba(239, 68, 68, 0.4);
          color: #ff8787;
        }

        .detected-info {
          color: rgba(255, 255, 255, 0.5);
          font-size: 10px;
          font-weight: 400;
          white-space: nowrap;
          padding-left: 6px;
          border-left: 1px solid rgba(255, 255, 255, 0.2);
        }

        .detected-value {
          color: rgba(255, 255, 255, 0.8);
          font-weight: 500;
        }
      </style>

      <div class="country-selector">
        <span class="country-label">🌍</span>
        
        <div class="select-wrapper">
          <select class="country-select" id="country-select">
            ${this.countries.map((country) => `
              <option value="${country.code}" ${country.code === currentCountry ? "selected" : ""}>
                ${country.name.length > 15 ? country.name.substring(0, 15) + "..." : country.name}
              </option>
            `).join("")}
          </select>
          <svg class="select-arrow" viewBox="0 0 24 24" fill="currentColor">
            <path d="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z"/>
          </svg>
        </div>

        <div class="loading-indicator" id="loading-indicator"></div>

        ${rawDetectedCountry !== currentCountry ? `
          <button class="reset-button" id="reset-button" title="Reset to detected country: ${rawDetectedCountry}">
            Reset
          </button>
        ` : ""}

        ${rawDetectedCountry ? `
          <div class="detected-info">
            Detected: <span class="detected-value">${rawDetectedCountry}</span>
          </div>
        ` : ""}
      </div>
    `;
    if (!this.hasInitiallyRendered) {
      this.hasInitiallyRendered = true;
    }
  }
  setupEventListeners() {
    if (!this.shadowRoot || this.listenersAttached) return;
    this.shadowRoot.addEventListener("change", async (e) => {
      const target = e.target;
      if (target && target.id === "country-select") {
        const selectElement = target;
        const newCountry = selectElement.value;
        if (this.isChanging) {
          this.logger.warn("Country change already in progress");
          return;
        }
        this.logger.debug(`Country select changed to: ${newCountry}`);
        await this.handleCountryChange(newCountry);
      }
    });
    this.shadowRoot.addEventListener("click", async (e) => {
      const target = e.target;
      if (target && target.id === "reset-button") {
        const configStore$1 = configStore.getState();
        const detectedCountry = configStore$1.detectedCountry || "US";
        this.logger.debug("Resetting to detected country:", detectedCountry);
        await this.handleCountryChange(detectedCountry, true);
      }
    });
    document.addEventListener("next:country-changed", () => {
      this.logger.debug("External country change detected, re-rendering selector");
      this.render();
    });
    this.listenersAttached = true;
    this.logger.debug("Event listeners attached to country selector");
  }
  async handleCountryChange(newCountry, isReset = false) {
    this.isChanging = true;
    const select = this.shadowRoot?.getElementById("country-select");
    const loadingIndicator = this.shadowRoot?.getElementById("loading-indicator");
    if (select) select.disabled = true;
    if (loadingIndicator) loadingIndicator.classList.add("active");
    try {
      this.logger.info(`Changing country to ${newCountry}`);
      const configStore$1 = configStore.getState();
      const campaignStore = useCampaignStore.getState();
      const countryService = CountryService.getInstance();
      const oldCountry = sessionStorage.getItem("next_selected_country") || configStore$1.detectedCountry || "US";
      if (isReset) {
        sessionStorage.removeItem("next_selected_country");
        this.logger.info("Cleared selected country override, using detected country");
      } else {
        sessionStorage.setItem("next_selected_country", newCountry);
        this.logger.info(`Saved selected country to session: ${newCountry}`);
      }
      const countryConfig = await countryService.getCountryConfig(newCountry);
      const countryStates = await countryService.getCountryStates(newCountry);
      configStore$1.updateConfig({
        locationData: {
          detectedCountryCode: newCountry,
          detectedCountryConfig: countryConfig,
          detectedStates: countryStates.states,
          detectedStateCode: "",
          detectedCity: "",
          countries: this.countries
        }
      });
      if (countryConfig.currencyCode && countryConfig.currencyCode !== configStore$1.selectedCurrency) {
        this.logger.info(`Country currency is ${countryConfig.currencyCode}, updating...`);
        configStore$1.updateConfig({
          selectedCurrency: countryConfig.currencyCode
        });
        sessionStorage.setItem("next_selected_currency", countryConfig.currencyCode);
        await campaignStore.loadCampaign(configStore$1.apiKey, { forceFresh: true });
        await cartOperations.refreshItemPrices();
        document.dispatchEvent(new CustomEvent("next:currency-changed", {
          detail: {
            from: configStore$1.selectedCurrency,
            to: countryConfig.currencyCode,
            source: "country-selector"
          }
        }));
      }
      this.logger.info(`Country changed successfully to ${newCountry}`);
      document.dispatchEvent(new CustomEvent("next:country-changed", {
        detail: {
          from: oldCountry,
          to: newCountry,
          currency: countryConfig.currencyCode
        }
      }));
      document.dispatchEvent(new CustomEvent("debug:update-content"));
      this.showSuccessFeedback(newCountry);
      this.render();
    } catch (error) {
      this.logger.error("Failed to change country:", error);
      this.showErrorFeedback();
      const currentCountry = sessionStorage.getItem("next_selected_country") || configStore.getState().detectedCountry || "US";
      if (select) select.value = currentCountry;
    } finally {
      this.isChanging = false;
      if (select) select.disabled = false;
      if (loadingIndicator) loadingIndicator.classList.remove("active");
    }
  }
  showSuccessFeedback(_country) {
    const selector = this.shadowRoot?.querySelector(".country-selector");
    if (!selector) return;
    selector.style.background = "linear-gradient(135deg, #10b981 0%, #059669 100%)";
    setTimeout(() => {
      selector.style.background = "linear-gradient(135deg, #222 0%, #1a1a1a 100%)";
    }, 1e3);
  }
  showErrorFeedback() {
    const selector = this.shadowRoot?.querySelector(".country-selector");
    if (!selector) return;
    selector.style.background = "linear-gradient(135deg, #ef4444 0%, #dc2626 100%)";
    setTimeout(() => {
      selector.style.background = "linear-gradient(135deg, #222 0%, #1a1a1a 100%)";
    }, 1e3);
  }
  destroy() {
    if (this.renderDebounceTimer) {
      clearTimeout(this.renderDebounceTimer);
    }
    if (this.container) {
      this.container.remove();
      this.container = null;
      this.shadowRoot = null;
    }
  }
  hide() {
    if (this.container) {
      this.container.style.display = "none";
    }
  }
  show() {
    if (this.container) {
      this.container.style.display = "block";
    }
  }
}
const countrySelector = CountrySelector.getInstance();
class LocaleSelector {
  constructor() {
    this.container = null;
    this.shadowRoot = null;
    this.logger = new Logger("LocaleSelector");
    this.isChanging = false;
    this.listenersAttached = false;
    this.renderDebounceTimer = null;
    this.hasInitiallyRendered = false;
    this.locales = [
      { code: "en-US", name: "English (US)", flag: "🇺🇸" },
      { code: "en-GB", name: "English (UK)", flag: "🇬🇧" },
      { code: "en-CA", name: "English (CA)", flag: "🇨🇦" },
      { code: "en-AU", name: "English (AU)", flag: "🇦🇺" },
      { code: "pt-BR", name: "Português (BR)", flag: "🇧🇷" },
      { code: "es-ES", name: "Español (ES)", flag: "🇪🇸" },
      { code: "es-MX", name: "Español (MX)", flag: "🇲🇽" },
      { code: "fr-FR", name: "Français", flag: "🇫🇷" },
      { code: "de-DE", name: "Deutsch", flag: "🇩🇪" },
      { code: "it-IT", name: "Italiano", flag: "🇮🇹" },
      { code: "ja-JP", name: "日本語", flag: "🇯🇵" },
      { code: "zh-CN", name: "中文", flag: "🇨🇳" },
      { code: "ko-KR", name: "한국어", flag: "🇰🇷" },
      { code: "ru-RU", name: "Русский", flag: "🇷🇺" },
      { code: "ar-SA", name: "العربية", flag: "🇸🇦" },
      { code: "hi-IN", name: "हिन्दी", flag: "🇮🇳" },
      { code: "nl-NL", name: "Nederlands", flag: "🇳🇱" },
      { code: "sv-SE", name: "Svenska", flag: "🇸🇪" },
      { code: "pl-PL", name: "Polski", flag: "🇵🇱" },
      { code: "tr-TR", name: "Türkçe", flag: "🇹🇷" }
    ];
  }
  static getInstance() {
    if (!LocaleSelector.instance) {
      LocaleSelector.instance = new LocaleSelector();
    }
    return LocaleSelector.instance;
  }
  initialize() {
    this.createContainer();
    this.render();
    this.setupEventListeners();
    this.logger.info("Locale selector initialized");
  }
  createContainer() {
    if (this.container) {
      this.container.remove();
    }
    this.container = document.createElement("div");
    this.container.id = "debug-locale-selector";
    this.container.style.cssText = `
      position: relative;
      pointer-events: auto;
    `;
    this.shadowRoot = this.container.attachShadow({ mode: "open" });
    document.body.appendChild(this.container);
  }
  getCurrentLocale() {
    const savedLocale = sessionStorage.getItem("next_selected_locale");
    if (savedLocale) {
      return savedLocale;
    }
    return navigator.language || "en-US";
  }
  render() {
    if (this.renderDebounceTimer) {
      clearTimeout(this.renderDebounceTimer);
    }
    this.renderDebounceTimer = setTimeout(() => {
      this.doRender();
    }, 50);
  }
  doRender() {
    if (!this.shadowRoot) return;
    const currentLocale = this.getCurrentLocale();
    const detectedLocale = navigator.language || "en-US";
    if (this.container) {
      this.container.style.display = "block";
    }
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        .locale-selector {
          background: linear-gradient(135deg, #222 0%, #1a1a1a 100%);
          backdrop-filter: blur(10px);
          border: 1px solid #333;
          border-radius: 4px;
          padding: 4px 8px;
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 11px;
          box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
          transition: all 0.2s ease;
        }

        .locale-selector:hover {
          background: linear-gradient(135deg, #2a2a2a 0%, #222 100%);
          border-color: #444;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
        }

        .locale-label {
          color: rgba(255, 255, 255, 0.9);
          font-size: 11px;
          font-weight: 500;
          white-space: nowrap;
        }

        .locale-select {
          appearance: none;
          background: #2a2a2a;
          border: 1px solid rgba(255, 255, 255, 0.2);
          border-radius: 3px;
          padding: 2px 20px 2px 6px;
          font-size: 11px;
          font-weight: 500;
          color: rgba(255, 255, 255, 0.9);
          cursor: pointer;
          min-width: 100px;
          max-width: 140px;
        }

        .locale-select option {
          background: #2a2a2a;
          color: rgba(255, 255, 255, 0.9);
          padding: 4px;
        }

        .locale-select:hover {
          background: #333;
          border-color: rgba(255, 255, 255, 0.3);
        }

        .locale-select:focus {
          outline: none;
          border-color: #4299e1;
          background: #333;
        }

        .locale-select:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .select-wrapper {
          position: relative;
          display: flex;
          align-items: center;
        }

        .select-arrow {
          position: absolute;
          right: 4px;
          top: 50%;
          transform: translateY(-50%);
          pointer-events: none;
          color: rgba(255, 255, 255, 0.6);
          width: 10px;
          height: 10px;
        }

        .loading-indicator {
          display: none;
          width: 10px;
          height: 10px;
          border: 1px solid #cbd5e0;
          border-top-color: #4299e1;
          border-radius: 50%;
          animation: spin 0.8s linear infinite;
        }

        .loading-indicator.active {
          display: inline-block;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        .reset-button {
          background: rgba(239, 68, 68, 0.2);
          border: 1px solid rgba(239, 68, 68, 0.3);
          border-radius: 3px;
          color: #ff6b6b;
          padding: 2px 6px;
          font-size: 10px;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .reset-button:hover {
          background: rgba(239, 68, 68, 0.3);
          border-color: rgba(239, 68, 68, 0.4);
          color: #ff8787;
        }

        .detected-info {
          color: rgba(255, 255, 255, 0.5);
          font-size: 10px;
          font-weight: 400;
          white-space: nowrap;
          padding-left: 6px;
          border-left: 1px solid rgba(255, 255, 255, 0.2);
        }

        .detected-value {
          color: rgba(255, 255, 255, 0.8);
          font-weight: 500;
        }
      </style>

      <div class="locale-selector">
        <span class="locale-label">🌐</span>
        
        <div class="select-wrapper">
          <select class="locale-select" id="locale-select">
            ${this.locales.map((locale) => `
              <option value="${locale.code}" ${locale.code === currentLocale ? "selected" : ""}>
                ${locale.flag} ${locale.code}
              </option>
            `).join("")}
          </select>
          <svg class="select-arrow" viewBox="0 0 24 24" fill="currentColor">
            <path d="M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z"/>
          </svg>
        </div>

        <div class="loading-indicator" id="loading-indicator"></div>

        ${detectedLocale !== currentLocale ? `
          <button class="reset-button" id="reset-button" title="Reset to browser locale: ${detectedLocale}">
            Reset
          </button>
        ` : ""}

        <div class="detected-info">
          Browser: <span class="detected-value">${detectedLocale}</span>
        </div>
      </div>
    `;
    if (!this.hasInitiallyRendered) {
      this.hasInitiallyRendered = true;
    }
  }
  setupEventListeners() {
    if (!this.shadowRoot || this.listenersAttached) return;
    this.shadowRoot.addEventListener("change", async (e) => {
      const target = e.target;
      if (target && target.id === "locale-select") {
        const selectElement = target;
        const newLocale = selectElement.value;
        if (this.isChanging) {
          this.logger.warn("Locale change already in progress");
          return;
        }
        this.logger.debug(`Locale select changed to: ${newLocale}`);
        await this.handleLocaleChange(newLocale);
      }
    });
    this.shadowRoot.addEventListener("click", async (e) => {
      const target = e.target;
      if (target && target.id === "reset-button") {
        const detectedLocale = navigator.language || "en-US";
        this.logger.debug("Resetting to browser locale:", detectedLocale);
        await this.handleLocaleChange(detectedLocale, true);
      }
    });
    document.addEventListener("next:locale-changed", () => {
      this.logger.debug("External locale change detected, re-rendering selector");
      this.render();
    });
    this.listenersAttached = true;
    this.logger.debug("Event listeners attached to locale selector");
  }
  async handleLocaleChange(newLocale, isReset = false) {
    this.isChanging = true;
    const select = this.shadowRoot?.getElementById("locale-select");
    const loadingIndicator = this.shadowRoot?.getElementById("loading-indicator");
    if (select) select.disabled = true;
    if (loadingIndicator) loadingIndicator.classList.add("active");
    try {
      this.logger.info(`Changing locale to ${newLocale}`);
      const oldLocale = this.getCurrentLocale();
      if (isReset) {
        sessionStorage.removeItem("next_selected_locale");
        this.logger.info("Cleared selected locale override, using browser locale");
      } else {
        sessionStorage.setItem("next_selected_locale", newLocale);
        this.logger.info(`Saved selected locale to session: ${newLocale}`);
      }
      const { CurrencyFormatter: CurrencyFormatter2 } = await Promise.resolve().then(() => currencyFormatter);
      CurrencyFormatter2.clearCache();
      const { cartOperations: cartOperations2 } = await import("./state-pM9xfsfc.js").then((n) => n.i);
      cartOperations2.calculateTotals();
      document.dispatchEvent(new CustomEvent("next:locale-changed", {
        detail: {
          from: oldLocale,
          to: newLocale,
          source: "locale-selector"
        }
      }));
      document.dispatchEvent(new CustomEvent("debug:update-content"));
      document.dispatchEvent(new CustomEvent("next:display-refresh"));
      this.refreshAllCurrencyDisplays();
      this.showSuccessFeedback(newLocale);
      this.render();
      this.logFormatExamples(newLocale);
    } catch (error) {
      this.logger.error("Failed to change locale:", error);
      this.showErrorFeedback();
      const currentLocale = this.getCurrentLocale();
      if (select) select.value = currentLocale;
    } finally {
      this.isChanging = false;
      if (select) select.disabled = false;
      if (loadingIndicator) loadingIndicator.classList.remove("active");
    }
  }
  refreshAllCurrencyDisplays() {
    const displayElements = document.querySelectorAll("[data-next-display]");
    displayElements.forEach((element) => {
      const displayType = element.getAttribute("data-next-display");
      if (displayType?.includes("price") || displayType?.includes("total") || displayType?.includes("subtotal") || displayType?.includes("cost") || displayType?.includes("amount")) {
        element.dispatchEvent(new CustomEvent("next:refresh-display", { bubbles: true }));
      }
    });
    const priceElements = document.querySelectorAll(
      '.next-price, .next-total, .next-subtotal, .next-amount, [class*="price"], [class*="total"], [class*="amount"]'
    );
    priceElements.forEach((element) => {
      const text = element.textContent || "";
      if (/[$£€¥₹₽¢]/u.test(text) || /\d+[.,]\d{2}/.test(text)) {
        element.dispatchEvent(new CustomEvent("next:refresh-display", { bubbles: true }));
      }
    });
    this.logger.debug(`Refreshed ${displayElements.length + priceElements.length} potential currency displays`);
  }
  logFormatExamples(locale) {
    const formatter = new Intl.NumberFormat(locale, {
      style: "currency",
      currency: "USD",
      currencyDisplay: "narrowSymbol"
    });
    const dateFormatter = new Intl.DateTimeFormat(locale, {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
    const numberFormatter = new Intl.NumberFormat(locale);
    console.log(`%c[LocaleSelector] Format examples for ${locale}:`, "color: #4299e1; font-weight: bold");
    console.log("Currency:", formatter.format(1234.56));
    console.log("Date:", dateFormatter.format(/* @__PURE__ */ new Date()));
    console.log("Number:", numberFormatter.format(123456789e-2));
  }
  showSuccessFeedback(_locale) {
    const selector = this.shadowRoot?.querySelector(".locale-selector");
    if (!selector) return;
    selector.style.background = "linear-gradient(135deg, #10b981 0%, #059669 100%)";
    setTimeout(() => {
      selector.style.background = "linear-gradient(135deg, #222 0%, #1a1a1a 100%)";
    }, 1e3);
  }
  showErrorFeedback() {
    const selector = this.shadowRoot?.querySelector(".locale-selector");
    if (!selector) return;
    selector.style.background = "linear-gradient(135deg, #ef4444 0%, #dc2626 100%)";
    setTimeout(() => {
      selector.style.background = "linear-gradient(135deg, #222 0%, #1a1a1a 100%)";
    }, 1e3);
  }
  destroy() {
    if (this.renderDebounceTimer) {
      clearTimeout(this.renderDebounceTimer);
    }
    if (this.container) {
      this.container.remove();
      this.container = null;
      this.shadowRoot = null;
    }
  }
  hide() {
    if (this.container) {
      this.container.style.display = "none";
    }
  }
  show() {
    if (this.container) {
      this.container.style.display = "block";
    }
  }
}
const localeSelector = LocaleSelector.getInstance();
class SelectorContainer {
  constructor() {
    this.container = null;
    this.setupPanelListener();
  }
  static getInstance() {
    if (!SelectorContainer.instance) {
      SelectorContainer.instance = new SelectorContainer();
    }
    return SelectorContainer.instance;
  }
  initialize() {
    this.createContainer();
    currencySelector.initialize();
    countrySelector.initialize();
    localeSelector.initialize();
    this.moveSelectorsToContainer();
  }
  createContainer() {
    if (this.container) {
      this.container.remove();
    }
    this.container = document.createElement("div");
    this.container.id = "debug-selectors-container";
    this.container.style.cssText = `
      position: fixed;
      bottom: 70px;
      right: 20px;
      display: flex;
      gap: 10px;
      align-items: center;
      z-index: 999998;
      pointer-events: auto;
      transition: bottom 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    `;
    document.body.appendChild(this.container);
  }
  moveSelectorsToContainer() {
    if (!this.container) return;
    setTimeout(() => {
      const currencySel = document.getElementById("debug-currency-selector");
      const countrySel = document.getElementById("debug-country-selector");
      const localeSel = document.getElementById("debug-locale-selector");
      if (currencySel) {
        currencySel.style.position = "relative";
        currencySel.style.bottom = "auto";
        currencySel.style.left = "auto";
        currencySel.style.transform = "none";
        this.container.appendChild(currencySel);
      }
      if (countrySel) {
        countrySel.style.position = "relative";
        countrySel.style.bottom = "auto";
        countrySel.style.left = "auto";
        countrySel.style.transform = "none";
        this.container.appendChild(countrySel);
      }
      if (localeSel) {
        localeSel.style.position = "relative";
        localeSel.style.bottom = "auto";
        localeSel.style.left = "auto";
        localeSel.style.transform = "none";
        this.container.appendChild(localeSel);
      }
    }, 100);
  }
  setupPanelListener() {
    const checkForOverlay = () => {
      const shadowHost = document.getElementById("next-debug-overlay-host");
      if (shadowHost && shadowHost.shadowRoot) {
        const debugOverlay2 = shadowHost.shadowRoot.querySelector(".enhanced-debug-overlay");
        if (debugOverlay2) {
          const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
              if (mutation.type === "attributes" && mutation.attributeName === "class") {
                const target = mutation.target;
                if (target.classList.contains("enhanced-debug-overlay")) {
                  const isExpanded2 = target.classList.contains("expanded");
                  this.updatePosition(isExpanded2);
                }
              }
            });
          });
          observer.observe(debugOverlay2, {
            attributes: true,
            attributeFilter: ["class"]
          });
          const isExpanded = debugOverlay2.classList.contains("expanded");
          this.updatePosition(isExpanded);
        }
      }
    };
    setTimeout(checkForOverlay, 500);
    document.addEventListener("debug:panel-toggled", ((e) => {
      this.updatePosition(e.detail?.isExpanded || false);
    }));
  }
  updatePosition(isExpanded) {
    if (!this.container) return;
    if (isExpanded) {
      this.container.style.bottom = "calc(max(40vh, 450px) + 10px)";
    } else {
      this.container.style.bottom = "70px";
    }
  }
  destroy() {
    if (this.container) {
      this.container.remove();
      this.container = null;
    }
  }
}
const selectorContainer = SelectorContainer.getInstance();
class UpsellSelector {
  constructor() {
    this.container = null;
    this.shadowRoot = null;
    this.logger = new Logger("UpsellSelector");
    this.eventBus = EventBus.getInstance();
    this.state = { mode: "none", quantity: 1 };
    this.isUpsellPage = false;
    this.renderDebounceTimer = null;
  }
  static getInstance() {
    if (!UpsellSelector.instance) {
      UpsellSelector.instance = new UpsellSelector();
    }
    return UpsellSelector.instance;
  }
  initialize() {
    this.checkIfUpsellPage();
    if (!this.isUpsellPage) {
      this.logger.debug("Not an upsell page, skipping initialization");
      return;
    }
    this.createContainer();
    this.setupEventListeners();
    this.scanExistingUpsells();
    this.logger.info("UpsellSelector initialized");
  }
  createContainer() {
    if (this.container) {
      this.container.remove();
    }
    this.container = document.createElement("div");
    this.container.id = "debug-upsell-display";
    this.container.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 999998;
      pointer-events: auto;
    `;
    this.shadowRoot = this.container.attachShadow({ mode: "open" });
    document.body.appendChild(this.container);
  }
  scanExistingUpsells() {
    const upsellElements = document.querySelectorAll("[data-next-upsell], [data-next-upsell-selector]");
    this.logger.debug("Scanning for existing upsell elements:", upsellElements.length);
    if (upsellElements.length === 0) {
      this.logger.debug("No upsell elements found");
      return;
    }
    const firstElement = upsellElements[0];
    const childBundleSelector = firstElement.querySelector("[data-next-bundle-selector]");
    const bundleSelectorId = firstElement.getAttribute("data-next-bundle-selector-id") ?? childBundleSelector?.getAttribute("data-next-selector-id");
    if (bundleSelectorId) {
      this.state = { bundleSelectorId, quantity: 1, mode: "bundle" };
      setTimeout(() => this.readBundleSelection(), 200);
      this.render();
      this.logger.debug("Initialized state from bundle selector:", { bundleSelectorId });
      return;
    }
    let selectorId = firstElement.getAttribute("data-next-selector-id");
    let packageIdAttr = firstElement.getAttribute("data-next-package-id");
    let packageId = packageIdAttr ? parseInt(packageIdAttr, 10) : void 0;
    if (!packageId) {
      const selectedOption = firstElement.querySelector('[data-next-upsell-option][data-next-selected="true"]');
      if (selectedOption) {
        const selectedPackageIdAttr = selectedOption.getAttribute("data-next-package-id");
        packageId = selectedPackageIdAttr ? parseInt(selectedPackageIdAttr, 10) : void 0;
        this.logger.debug("Found selected option:", { packageId });
      }
      if (!packageId) {
        const anyOption = firstElement.querySelector("[data-next-upsell-option][data-next-package-id]");
        if (anyOption) {
          const optionPackageIdAttr = anyOption.getAttribute("data-next-package-id");
          packageId = optionPackageIdAttr ? parseInt(optionPackageIdAttr, 10) : void 0;
          this.logger.debug("Found first available option:", { packageId });
        }
      }
    }
    if (!selectorId) {
      const nestedSelector = firstElement.querySelector("[data-next-selector-id]");
      if (nestedSelector) {
        selectorId = nestedSelector.getAttribute("data-next-selector-id") || null;
        this.logger.debug("Found nested selector:", { selectorId });
      }
    }
    this.state = {
      packageId: packageId || void 0,
      selectorId: selectorId || void 0,
      quantity: 1,
      mode: selectorId ? "selector" : packageId ? "direct" : "none"
    };
    this.render();
    this.logger.debug("Initialized state from existing upsell element:", {
      mode: this.state.mode,
      packageId: this.state.packageId,
      selectorId: this.state.selectorId
    });
  }
  checkIfUpsellPage() {
    const pageTypeMeta = document.querySelector('meta[name="next-page-type"]');
    this.isUpsellPage = pageTypeMeta?.getAttribute("content") === "upsell";
  }
  setupEventListeners() {
    this.eventBus.on("upsell:initialized", (data) => {
      const { packageId, element } = data;
      this.logger.debug("Upsell initialized:", data);
      if (!element) return;
      const selectorId = element.getAttribute("data-next-selector-id");
      const childBundle = element.querySelector("[data-next-bundle-selector]");
      const bundleSelectorId = element.getAttribute("data-next-bundle-selector-id") ?? childBundle?.getAttribute("data-next-selector-id");
      if (bundleSelectorId) {
        this.state = {
          bundleSelectorId,
          quantity: 1,
          mode: "bundle"
        };
      } else {
        this.state = {
          packageId: packageId || void 0,
          selectorId: selectorId || void 0,
          quantity: 1,
          mode: selectorId ? "selector" : "direct"
        };
      }
      this.render();
    });
    this.eventBus.on("bundle:selection-changed", (data) => {
      if (this.state.mode !== "bundle") return;
      this.logger.debug("Bundle selection changed:", data);
      this.state.bundleItems = data.items;
      this.render();
    });
    this.eventBus.on("upsell:option-selected", (data) => {
      const { packageId, selectorId } = data;
      this.logger.debug("Upsell option selected:", data);
      this.state.packageId = packageId;
      if (selectorId) {
        this.state.selectorId = selectorId;
      }
      this.render();
    });
    this.eventBus.on("upsell:quantity-changed", (data) => {
      const { quantity } = data;
      this.logger.debug("Upsell quantity changed:", data);
      this.state.quantity = quantity;
      this.render();
    });
  }
  readBundleSelection() {
    if (!this.state.bundleSelectorId) return;
    const el = document.querySelector(
      `[data-next-bundle-selector][data-next-selector-id="${this.state.bundleSelectorId}"]`
    );
    if (!el) return;
    const fn = el["_getSelectedBundleItems"];
    if (typeof fn === "function") {
      const items = fn();
      if (items) {
        this.state.bundleItems = items;
        this.render();
      }
    }
  }
  getPackageName(packageId) {
    const campaignStore = useCampaignStore.getState();
    const packageData = campaignStore.getPackage(packageId);
    return packageData?.name || `Package ${packageId}`;
  }
  render() {
    if (this.renderDebounceTimer) {
      clearTimeout(this.renderDebounceTimer);
    }
    this.renderDebounceTimer = setTimeout(() => {
      this.doRender();
    }, 50);
  }
  doRender() {
    if (!this.shadowRoot) return;
    if (this.state.mode === "none" && !this.state.bundleSelectorId || !this.isUpsellPage) {
      if (this.container) {
        this.container.style.display = "none";
      }
      return;
    }
    if (this.container) {
      this.container.style.display = "block";
    }
    const packageName = this.state.packageId ? this.getPackageName(this.state.packageId) : "None";
    const modeLabel = this.state.mode === "bundle" ? "📦 Bundle" : this.state.mode === "selector" ? "🎯 Selector" : "➡️ Direct";
    const bundleHasItems = (this.state.bundleItems?.length ?? 0) > 0;
    this.shadowRoot.innerHTML = `
      <style>
        :host {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        }

        .upsell-badge {
          background: linear-gradient(135deg, rgba(30, 41, 59, 0.95) 0%, rgba(15, 23, 42, 0.95) 100%);
          backdrop-filter: blur(10px);
          border: 2px solid rgba(99, 102, 241, 0.4);
          border-radius: 8px;
          padding: 14px 18px;
          display: inline-flex;
          flex-direction: column;
          gap: 10px;
          font-size: 14px;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4), 0 0 0 1px rgba(99, 102, 241, 0.1);
          transition: all 0.2s ease;
          min-width: 320px;
        }

        .upsell-badge:hover {
          background: linear-gradient(135deg, rgba(51, 65, 85, 0.95) 0%, rgba(30, 41, 59, 0.95) 100%);
          border-color: rgba(99, 102, 241, 0.6);
          box-shadow: 0 6px 16px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(99, 102, 241, 0.2);
          transform: translateY(-1px);
        }

        .badge-header {
          display: flex;
          align-items: center;
          gap: 8px;
          padding-bottom: 10px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .debug-label {
          color: rgba(255, 255, 255, 0.5);
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.8px;
          flex: 1;
        }

        .mode-badge {
          background: rgba(99, 102, 241, 0.15);
          border: 1px solid rgba(99, 102, 241, 0.3);
          color: #a5b4fc;
          padding: 4px 10px;
          border-radius: 4px;
          font-size: 11px;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .badge-content {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .info-row {
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .info-label {
          color: rgba(255, 255, 255, 0.5);
          font-size: 11px;
          font-weight: 500;
          min-width: 50px;
        }

        .info-value {
          color: rgba(255, 255, 255, 0.95);
          font-size: 14px;
          font-weight: 600;
          flex: 1;
        }

        .package-id {
          background: rgba(99, 102, 241, 0.2);
          border: 1px solid rgba(99, 102, 241, 0.3);
          color: #c7d2fe;
          padding: 4px 10px;
          border-radius: 4px;
          font-size: 13px;
          font-weight: 700;
          font-family: 'Courier New', monospace;
        }

        .package-name {
          color: rgba(255, 255, 255, 0.9);
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .quantity-badge {
          background: rgba(34, 197, 94, 0.15);
          border: 1px solid rgba(34, 197, 94, 0.3);
          color: #86efac;
          padding: 4px 12px;
          border-radius: 4px;
          font-size: 13px;
          font-weight: 700;
          font-family: 'Courier New', monospace;
        }

        .selector-id-value {
          color: rgba(255, 255, 255, 0.7);
          font-size: 12px;
          font-family: 'Courier New', monospace;
          background: rgba(255, 255, 255, 0.05);
          padding: 4px 10px;
          border-radius: 4px;
        }

        .status-indicator {
          width: 10px;
          height: 10px;
          border-radius: 50%;
          margin-left: auto;
        }

        .status-indicator.selected {
          background: #22c55e;
          box-shadow: 0 0 10px rgba(34, 197, 94, 0.6);
        }

        .status-indicator.unselected {
          background: rgba(255, 255, 255, 0.2);
        }
      </style>

      <div class="upsell-badge">
        <div class="badge-header">
          <span class="debug-label">🔍 Debug Info</span>
          <span class="mode-badge">${modeLabel}</span>
        </div>

        <div class="badge-content">
          ${this.state.mode === "bundle" ? `
            <div class="info-row">
              <span class="info-label">Bundle:</span>
              <span class="selector-id-value">${this.state.bundleSelectorId ?? ""}</span>
              <span class="status-indicator ${bundleHasItems ? "selected" : "unselected"}"></span>
            </div>
            ${bundleHasItems ? this.state.bundleItems.map((item) => `
              <div class="info-row">
                <span class="info-label">Item:</span>
                <span class="package-id">#${item.packageId}</span>
                <span class="info-value package-name">${this.getPackageName(item.packageId)}</span>
                <span class="quantity-badge">×${item.quantity}</span>
              </div>
            `).join("") : `
              <div class="info-row">
                <span class="info-label">Status:</span>
                <span class="info-value">No selection</span>
              </div>
            `}
          ` : this.state.packageId ? `
            <div class="info-row">
              <span class="info-label">Package:</span>
              <span class="package-id">#${this.state.packageId}</span>
              <span class="status-indicator selected"></span>
            </div>
            <div class="info-row">
              <span class="info-label">Name:</span>
              <span class="info-value package-name" title="${packageName}">${packageName}</span>
            </div>
          ` : `
            <div class="info-row">
              <span class="info-label">Status:</span>
              <span class="info-value">No selection</span>
              <span class="status-indicator unselected"></span>
            </div>
          `}

          ${this.state.quantity > 1 ? `
            <div class="info-row">
              <span class="info-label">Qty:</span>
              <span class="quantity-badge">×${this.state.quantity}</span>
            </div>
          ` : ""}

          ${this.state.selectorId ? `
            <div class="info-row">
              <span class="info-label">ID:</span>
              <span class="selector-id-value">${this.state.selectorId}</span>
            </div>
          ` : ""}
        </div>
      </div>
    `;
  }
  destroy() {
    if (this.renderDebounceTimer) {
      clearTimeout(this.renderDebounceTimer);
    }
    if (this.container) {
      this.container.remove();
      this.container = null;
      this.shadowRoot = null;
    }
  }
  hide() {
    if (this.container) {
      this.container.style.display = "none";
    }
  }
  show() {
    if (this.container && this.isUpsellPage) {
      this.container.style.display = "block";
    }
  }
}
const upsellSelector = UpsellSelector.getInstance();
HighlightJS.registerLanguage("json", json);
function escapeAttr$1(str) {
  return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;");
}
const HLJS_THEME_CSS = `
  .raw-data-wrapper .hljs { color: #f8f8f8; background: transparent; }
  .raw-data-wrapper .hljs-comment,
  .raw-data-wrapper .hljs-quote { color: #aeaeae; font-style: italic; }
  .raw-data-wrapper .hljs-keyword,
  .raw-data-wrapper .hljs-selector-tag,
  .raw-data-wrapper .hljs-type { color: #e28964; }
  .raw-data-wrapper .hljs-string { color: #65b042; }
  .raw-data-wrapper .hljs-subst { color: #daefa3; }
  .raw-data-wrapper .hljs-regexp,
  .raw-data-wrapper .hljs-link { color: #e9c062; }
  .raw-data-wrapper .hljs-title,
  .raw-data-wrapper .hljs-section,
  .raw-data-wrapper .hljs-tag,
  .raw-data-wrapper .hljs-name,
  .raw-data-wrapper .hljs-attr { color: #89bdff; }
  .raw-data-wrapper .hljs-symbol,
  .raw-data-wrapper .hljs-bullet,
  .raw-data-wrapper .hljs-number,
  .raw-data-wrapper .hljs-literal { color: #3387cc; }
  .raw-data-wrapper .hljs-attribute { color: #cda869; }
  .raw-data-wrapper .hljs-meta { color: #8996a8; }
  .raw-data-wrapper .hljs-punctuation { color: #cccccc; }
`;
class RawDataHelper {
  static generateRawDataContent(data) {
    const dataStr = JSON.stringify(data, null, 2) ?? "null";
    const highlighted = HighlightJS.highlight(dataStr, { language: "json" }).value;
    const copyPayload = escapeAttr$1(dataStr);
    return `
      <style>
        .raw-data-wrapper {
          position: relative;
          height: 100%;
          background: #0f0f0f;
          display: flex;
          flex-direction: column;
        }
        .copy-button {
          position: absolute;
          top: 10px;
          right: 24px;
          z-index: 10;
          width: 28px;
          height: 28px;
          padding: 0;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 6px;
          color: #c5c8c6;
          cursor: pointer;
          transition: background 0.15s ease, color 0.15s ease, border-color 0.15s ease;
        }
        .copy-button:hover {
          background: rgba(255, 255, 255, 0.12);
          color: #ffffff;
          border-color: rgba(255, 255, 255, 0.18);
        }
        .copy-button:active { background: rgba(255, 255, 255, 0.16); }
        .copy-button.copied {
          background: rgba(76, 175, 80, 0.18);
          color: #98c379;
          border-color: rgba(152, 195, 121, 0.4);
        }
        .copy-button .icon-copied { display: none; }
        .copy-button.copied .icon-copy { display: none; }
        .copy-button.copied .icon-copied { display: inline; }
        .copy-button .copy-label {
          position: absolute;
          width: 1px;
          height: 1px;
          padding: 0;
          margin: -1px;
          overflow: hidden;
          clip: rect(0, 0, 0, 0);
          border: 0;
        }
        .json-pre {
          flex: 1;
          margin: 0;
          padding: 16px 20px 24px;
          overflow: auto;
          font-family: 'SF Mono', 'Monaco', 'Consolas', monospace;
          font-size: 12px;
          line-height: 1.6;
          white-space: pre;
        }
        ${HLJS_THEME_CSS}
      </style>
      <div class="raw-data-wrapper">
        <button
          type="button"
          class="copy-button"
          data-raw-copy="${copyPayload}"
          title="Copy JSON"
          aria-label="Copy JSON"
        >
          <svg class="icon-copy" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
          </svg>
          <svg class="icon-copied" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
          <span class="copy-label">Copy</span>
        </button>
        <pre class="json-pre"><code class="hljs language-json">${highlighted}</code></pre>
      </div>
    `;
  }
  /**
   * Wire up the "Copy" button for any raw-data viewers inside `root`.
   * Idempotent — calling repeatedly is safe; existing listeners are not re-bound.
   */
  static bindCopyHandlers(root) {
    const buttons = root.querySelectorAll("button[data-raw-copy]");
    buttons.forEach((btn) => {
      if (btn.dataset.rawCopyBound === "1") return;
      btn.dataset.rawCopyBound = "1";
      btn.addEventListener("click", () => {
        const payload = btn.getAttribute("data-raw-copy") ?? "";
        const label = btn.querySelector(".copy-label");
        const originalLabel = label?.textContent ?? "Copy";
        navigator.clipboard.writeText(payload).then(() => {
          btn.classList.add("copied");
          if (label) label.textContent = "Copied!";
          window.setTimeout(() => {
            btn.classList.remove("copied");
            if (label) label.textContent = originalLabel;
          }, 2e3);
        }).catch(() => {
          if (label) label.textContent = "Copy failed";
        });
      });
    });
  }
}
function fa(def) {
  const [width, height, , , path] = def.icon;
  return { width, height, path };
}
const ICONS = {
  cart: fa(faCartShopping),
  tag: fa(faTag),
  package: fa(faBox),
  settings: fa(faGear),
  megaphone: fa(faBullhorn),
  card: fa(faCreditCard),
  chart: fa(faChartColumn),
  database: fa(faDatabase),
  filter: fa(faFilter),
  search: fa(faMagnifyingGlass),
  "search-x": fa(faMagnifyingGlassMinus),
  inbox: fa(faInbox),
  bolt: fa(faBolt),
  check: fa(faCheck),
  "check-circle": fa(faCircleCheck),
  "minus-circle": fa(faCircleMinus),
  ban: fa(faBan),
  "x-circle": fa(faCircleXmark),
  clock: fa(faClock),
  alert: fa(faTriangleExclamation),
  pause: fa(faPause),
  x: fa(faXmark),
  // Feather-style "activity" pulse line (stroked, 24×24 viewBox).
  activity: {
    width: 24,
    height: 24,
    path: "M22 12h-4l-3 9L9 3l-3 9H2",
    stroke: true
  },
  // Brand glyphs (Simple Icons path data, single-colour, 24×24 viewBox).
  google: {
    width: 24,
    height: 24,
    path: "M12.48 10.92v3.28h7.84c-.24 1.84-.853 3.187-1.787 4.133-1.147 1.147-2.933 2.4-6.053 2.4-4.827 0-8.6-3.893-8.6-8.72s3.773-8.72 8.6-8.72c2.6 0 4.507 1.027 5.907 2.347l2.307-2.307C18.747 1.44 16.133 0 12.48 0 5.867 0 .307 5.387.307 12s5.56 12 12.173 12c3.573 0 6.267-1.173 8.373-3.36 2.16-2.16 2.84-5.213 2.84-7.667 0-.76-.053-1.467-.173-2.053H12.48z"
  },
  // Facebook logo: brand-blue circle with the white "f" (keeps its own fills).
  facebook: {
    width: 24,
    height: 24,
    body: '<path fill="#1877F2" d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/><path fill="#ffffff" d="M16.671 15.543l.532-3.47h-3.328v-2.25c0-.949.465-1.874 1.956-1.874h1.513V4.996s-1.374-.235-2.686-.235c-2.741 0-4.533 1.662-4.533 4.669v2.643H7.078v3.47h3.047v8.385a12.06 12.06 0 0 0 3.75 0v-8.385h2.796z"/>'
  },
  // NextCampaign "N" mark in brand blue (keeps its own fill).
  next: {
    width: 117,
    height: 102,
    body: '<path fill="#3C7DFF" d="M83.5,58.3l-1.9-1.3L27.2,21.2c-.7-.4-1.4-.6-2-.6-2,0-3.6,1.6-3.6,3.6v53.4c0,2,1.6,3.6,3.6,3.6h3.8v12.3h-3.8c-8.8,0-15.8-7.1-15.8-15.8V24.3c0-8.8,7.1-15.8,15.8-15.8,3.1,0,6.2.9,8.7,2.6h0l49,33.4.5.4v13.5ZM90.2,8.4c8.8,0,15.8,7.1,15.8,15.8v53.4c0,8.8-7.1,15.8-15.8,15.8s-6.2-.9-8.7-2.6h0l-49-33.4-.5-.4v-13.5l1.9,1.3,54.3,35.7c.7.4,1.4.7,2,.7,2,0,3.6-1.6,3.6-3.6V24.3c0-2-1.6-3.6-3.6-3.6h-3.8v-12.3h3.8Z"/>'
  },
  // RudderStack logo: blue rounded tile with the white "sail" mark.
  rudderstack: {
    width: 24,
    height: 24,
    body: '<rect width="24" height="24" rx="5.5" fill="#2E5CE6"/><path d="M6.5 6.5H17A10.5 10.5 0 0 1 6.5 17Z" fill="#ffffff"/>'
  },
  // Google Tag Manager logo (layered blues, keeps its own fills).
  gtm: {
    width: 48,
    height: 48,
    body: '<polygon points="28.1 45.74 19.93 37.56 37.48 19.83 45.8 28.15 28.1 45.74" fill="#8AB4F8"/><path d="M28.16,10.51,19.84,2.19,2.2,19.83a5.88,5.88,0,0,0,0,8.32L19.84,45.79,28,37.59,14.67,24Z" fill="#4285F4"/><path d="M45.8,19.83,28.16,2.19a5.88,5.88,0,0,0-8.32,8.32L37.49,28.15a5.88,5.88,0,0,0,8.32-8.32Z" fill="#8AB4F8"/><circle cx="23.94" cy="41.7" r="5.83" transform="translate(-22.48 29.14) rotate(-45)" fill="#1A73E8"/>'
  }
};
function lucide(name, opts = {}) {
  const spec = ICONS[name];
  const size = opts.size ?? 16;
  const cls = opts.class ? ` ${opts.class}` : "";
  const style = `vertical-align:-0.125em;${opts.style ?? ""}`;
  if (spec.body) {
    return `<svg class="fa-icon${cls}" width="${size}" height="${size}" viewBox="0 0 ${spec.width} ${spec.height}" style="${style}" aria-hidden="true">${spec.body}</svg>`;
  }
  const paths = Array.isArray(spec.path) ? spec.path : [spec.path ?? ""];
  const paint = spec.stroke ? 'fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"' : 'fill="currentColor"';
  const body = paths.map((d) => `<path d="${d}"/>`).join("");
  return `<svg class="fa-icon${cls}" width="${size}" height="${size}" viewBox="0 0 ${spec.width} ${spec.height}" ${paint} style="${style}" aria-hidden="true">${body}</svg>`;
}
class CartPanel {
  constructor() {
    this.id = "cart";
    this.title = "Cart State";
    this.icon = lucide("cart");
  }
  getContent() {
    const tabs = this.getTabs();
    return tabs[0]?.getContent() || "";
  }
  getTabs() {
    return [
      {
        id: "overview",
        label: "Overview",
        icon: "📊",
        getContent: () => this.getOverviewContent()
      },
      {
        id: "items",
        label: "Items",
        icon: "📦",
        getContent: () => this.getItemsContent()
      },
      {
        id: "raw",
        label: "Raw Data",
        icon: "🔧",
        getContent: () => this.getRawDataContent()
      }
    ];
  }
  getOverviewContent() {
    const cartState = useCartStore.getState();
    return `
      <div class="enhanced-panel">
        <div class="metrics-grid">
          <div class="metric-card">
            <div class="metric-icon">📦</div>
            <div class="metric-content">
              <div class="metric-value">${cartState.items.length}</div>
              <div class="metric-label">Unique Items</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🔢</div>
            <div class="metric-content">
              <div class="metric-value">${cartState.totalQuantity}</div>
              <div class="metric-label">Total Quantity</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">💰</div>
            <div class="metric-content">
              <div class="metric-value">${formatCurrency(cartState.subtotal.toNumber())}</div>
              <div class="metric-label">Subtotal</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🚚</div>
            <div class="metric-content">
              <div class="metric-value">${formatCurrency(cartState.shippingMethod?.price.toNumber() ?? 0)}</div>
              <div class="metric-label">Shipping</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">📊</div>
            <div class="metric-content">
              <div class="metric-value">$0.00</div>
              <div class="metric-label">Tax</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">💳</div>
            <div class="metric-content">
              <div class="metric-value">${formatCurrency(cartState.total.toNumber())}</div>
              <div class="metric-label">Total</div>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  getItemsContent() {
    const cartState = useCartStore.getState();
    return `
      <div class="enhanced-panel">
        <div class="section">
          ${cartState.items.length === 0 ? `
            <div class="empty-state">
              <div class="empty-icon">🛒</div>
              <div class="empty-text">Cart is empty</div>
              <button class="empty-action" onclick="window.nextDebug.addTestItems()">Add Test Items</button>
            </div>
          ` : `
            <div class="cart-items-list">
              ${cartState.items.map((item) => `
                <div class="cart-item-card">
                  <div class="item-info">
                    <div class="item-title">${item.title}</div>
                    <div class="item-details">
                      Package ID: ${item.packageId} • Price: $${item.price}
                    </div>
                  </div>
                  <div class="item-quantity">
                    <button onclick="window.nextDebug.updateQuantity(${item.packageId}, ${item.quantity - 1})" 
                            class="qty-btn">-</button>
                    <span class="qty-value">${item.quantity}</span>
                    <button onclick="window.nextDebug.updateQuantity(${item.packageId}, ${item.quantity + 1})" 
                            class="qty-btn">+</button>
                  </div>
                  <div class="item-total">$${(item.price * item.quantity).toFixed(2)}</div>
                  <button onclick="window.nextDebug.removeItem(${item.packageId})" 
                          class="remove-btn">×</button>
                </div>
              `).join("")}
            </div>
          `}
        </div>
      </div>
    `;
  }
  getRawDataContent() {
    const cartState = useCartStore.getState();
    return RawDataHelper.generateRawDataContent(cartState);
  }
  getActions() {
    return [
      {
        label: "Clear Cart",
        action: () => cartOperations.clear(),
        variant: "danger"
      },
      {
        label: "Add Test Items",
        action: this.addTestItems,
        variant: "secondary"
      },
      {
        label: "Recalculate",
        action: () => cartOperations.calculateTotals(),
        variant: "primary"
      },
      {
        label: "Export Cart",
        action: this.exportCart,
        variant: "secondary"
      }
    ];
  }
  addTestItems() {
    const testItems = [
      { packageId: 999, quantity: 1, price: 19.99, title: "Debug Test Item 1", isUpsell: false },
      { packageId: 998, quantity: 2, price: 29.99, title: "Debug Test Item 2", isUpsell: false },
      { packageId: 997, quantity: 1, price: 9.99, title: "Debug Test Item 3", isUpsell: false }
    ];
    testItems.forEach((item) => void cartOperations.addItem(item));
  }
  exportCart() {
    const cartState = useCartStore.getState();
    const data = JSON.stringify(cartState, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `cart-state-${(/* @__PURE__ */ new Date()).toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
class OrderPanel {
  constructor() {
    this.id = "order";
    this.title = "Order State";
    this.icon = lucide("package");
  }
  getContent() {
    const tabs = this.getTabs();
    return tabs[0]?.getContent() || "";
  }
  getTabs() {
    return [
      {
        id: "overview",
        label: "Overview",
        icon: "📊",
        getContent: () => this.getOverviewContent()
      },
      {
        id: "lines",
        label: "Order Lines",
        icon: "📋",
        getContent: () => this.getOrderLinesContent()
      },
      {
        id: "addresses",
        label: "Addresses",
        icon: "📍",
        getContent: () => this.getAddressesContent()
      },
      {
        id: "raw",
        label: "Raw Data",
        icon: "🔧",
        getContent: () => this.getRawDataContent()
      }
    ];
  }
  getOverviewContent() {
    const orderState = useOrderStore.getState();
    const order = orderState.order;
    if (!order) {
      return this.getEmptyState();
    }
    const orderTotal = orderState.getOrderTotal();
    const canAddUpsells = orderState.canAddUpsells();
    const currency = order.currency || "USD";
    const currencySymbol = this.getCurrencySymbol(currency);
    return `
      <div class="enhanced-panel">
        <div class="metrics-grid">
          <div class="metric-card">
            <div class="metric-icon">🔖</div>
            <div class="metric-content">
              <div class="metric-value">${order.number || "N/A"}</div>
              <div class="metric-label">Order Number</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🆔</div>
            <div class="metric-content">
              <div class="metric-value" style="font-size: 0.9em; word-break: break-all;">${orderState.refId || "N/A"}</div>
              <div class="metric-label">Reference ID</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">📦</div>
            <div class="metric-content">
              <div class="metric-value">${order.lines?.length || 0}</div>
              <div class="metric-label">Total Lines</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🎯</div>
            <div class="metric-content">
              <div class="metric-value">${order.lines?.filter((l) => l.is_upsell).length || 0}</div>
              <div class="metric-label">Upsells</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">💰</div>
            <div class="metric-content">
              <div class="metric-value">${currencySymbol}${orderTotal.toFixed(2)}</div>
              <div class="metric-label">Order Total</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">${canAddUpsells ? "✅" : "❌"}</div>
            <div class="metric-content">
              <div class="metric-value">${canAddUpsells ? "Yes" : "No"}</div>
              <div class="metric-label">Can Add Upsells</div>
            </div>
          </div>
        </div>
        
        <div class="section">
          <h4>Order Details</h4>
          <div class="info-grid">
            <div class="info-item">
              <span class="info-label">Status:</span>
              <span class="info-value">Active</span>
            </div>
            <div class="info-item">
              <span class="info-label">Currency:</span>
              <span class="info-value">${order.currency || "USD"}</span>
            </div>
            <div class="info-item">
              <span class="info-label">Loaded At:</span>
              <span class="info-value">${orderState.orderLoadedAt ? new Date(orderState.orderLoadedAt).toLocaleString() : "N/A"}</span>
            </div>
            <div class="info-item">
              <span class="info-label">Shipping Method:</span>
              <span class="info-value">${order.shipping_method || "N/A"}</span>
            </div>
            <div class="info-item">
              <span class="info-label">Order URL:</span>
              <span class="info-value" style="font-size: 0.8em; word-break: break-all;">${order.order_status_url ? "Available" : "N/A"}</span>
            </div>
          </div>
        </div>
        
        <div class="section">
          <h4>Totals Breakdown</h4>
          <div class="totals-breakdown">
            <div class="total-item">
              <span>Subtotal (excl. tax):</span>
              <span>${currencySymbol}${parseFloat(order.total_excl_tax || "0").toFixed(2)}</span>
            </div>
            <div class="total-item">
              <span>Shipping:</span>
              <span>${currencySymbol}${parseFloat(order.shipping_excl_tax || "0").toFixed(2)}</span>
            </div>
            <div class="total-item">
              <span>Tax:</span>
              <span>${currencySymbol}${parseFloat(order.total_tax || "0").toFixed(2)}</span>
            </div>
            <div class="total-item total-final">
              <span>Total (incl. tax):</span>
              <span>${currencySymbol}${parseFloat(order.total_incl_tax || "0").toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  getOrderLinesContent() {
    const orderState = useOrderStore.getState();
    const order = orderState.order;
    if (!order || !order.lines || order.lines.length === 0) {
      return this.getEmptyState("No order lines available");
    }
    const currency = order.currency || "USD";
    const currencySymbol = this.getCurrencySymbol(currency);
    return `
      <div class="enhanced-panel">
        <div class="section">
          <style>
            .order-table {
              width: 100%;
              border-collapse: collapse;
              font-size: 0.9em;
            }
            .order-table th {
              background: rgba(255, 255, 255, 0.05);
              padding: 8px;
              text-align: left;
              border-bottom: 2px solid rgba(255, 255, 255, 0.1);
              font-weight: 600;
            }
            .order-table td {
              padding: 8px;
              border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            }
            .order-table tr:hover {
              background: rgba(255, 255, 255, 0.02);
            }
            .order-table .upsell-row {
              background: rgba(255, 215, 0, 0.05);
            }
            .order-table .upsell-badge {
              background: #ffd700;
              color: #000;
              padding: 2px 6px;
              border-radius: 3px;
              font-size: 0.75em;
              font-weight: bold;
              margin-left: 8px;
              display: inline-block;
            }
            .order-table .text-right {
              text-align: right;
            }
            .order-table .text-center {
              text-align: center;
            }
          </style>
          
          <table class="order-table">
            <thead>
              <tr>
                <th style="width: 5%">#</th>
                <th style="width: 35%">Product</th>
                <th style="width: 15%">SKU</th>
                <th style="width: 10%" class="text-center">Qty</th>
                <th style="width: 12%" class="text-right">Price</th>
                <th style="width: 11%" class="text-right">Tax</th>
                <th style="width: 12%" class="text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              ${order.lines.map((line, index) => `
                <tr ${line.is_upsell ? 'class="upsell-row"' : ""}>
                  <td>${index + 1}</td>
                  <td>
                    ${line.product_title || line.title || "Unknown Product"}
                    ${line.is_upsell ? '<span class="upsell-badge">POST-PURCHASE</span>' : ""}
                  </td>
                  <td>${line.product_sku || "N/A"}</td>
                  <td class="text-center">${line.quantity || 1}</td>
                  <td class="text-right">${currencySymbol}${parseFloat(line.price_excl_tax || "0").toFixed(2)}</td>
                  <td class="text-right">${currencySymbol}${(parseFloat(line.price_incl_tax || "0") - parseFloat(line.price_excl_tax || "0")).toFixed(2)}</td>
                  <td class="text-right"><strong>${currencySymbol}${parseFloat(line.price_incl_tax || "0").toFixed(2)}</strong></td>
                </tr>
              `).join("")}
              
              <tr style="border-top: 2px solid rgba(255, 255, 255, 0.1);">
                <td colspan="6" class="text-right"><strong>Order Total:</strong></td>
                <td class="text-right"><strong>${currencySymbol}${parseFloat(order.total_incl_tax || "0").toFixed(2)} ${currency}</strong></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
  }
  getAddressesContent() {
    const orderState = useOrderStore.getState();
    const order = orderState.order;
    if (!order) {
      return this.getEmptyState();
    }
    const formatAddressTable = (address, type) => {
      const icon = type === "shipping" ? "📦" : "💳";
      const title = type === "shipping" ? "Shipping Address" : "Billing Address";
      if (!address) {
        return `
          <div class="address-table-container">
            <div class="address-header">
              <span class="address-icon">${icon}</span>
              <h4>${title}</h4>
            </div>
            <div class="address-empty">No ${type} address provided</div>
          </div>
        `;
      }
      return `
        <div class="address-table-container">
          <div class="address-header">
            <span class="address-icon">${icon}</span>
            <h4>${title}</h4>
          </div>
          <table class="address-table">
            <tbody>
              ${address.first_name || address.last_name ? `
                <tr>
                  <td class="field-label">Name</td>
                  <td class="field-value">${address.first_name || ""} ${address.last_name || ""}</td>
                </tr>
              ` : ""}
              ${address.line1 ? `
                <tr>
                  <td class="field-label">Address 1</td>
                  <td class="field-value">${address.line1}</td>
                </tr>
              ` : ""}
              ${address.line2 ? `
                <tr>
                  <td class="field-label">Address 2</td>
                  <td class="field-value">${address.line2}</td>
                </tr>
              ` : ""}
              ${address.line4 || address.state || address.postcode ? `
                <tr>
                  <td class="field-label">City/State/Zip</td>
                  <td class="field-value">${address.line4 || ""}${address.state ? `, ${address.state}` : ""} ${address.postcode || ""}</td>
                </tr>
              ` : ""}
              ${address.country ? `
                <tr>
                  <td class="field-label">Country</td>
                  <td class="field-value">${address.country}</td>
                </tr>
              ` : ""}
              ${address.phone_number ? `
                <tr>
                  <td class="field-label">Phone</td>
                  <td class="field-value">${address.phone_number}</td>
                </tr>
              ` : ""}
            </tbody>
          </table>
        </div>
      `;
    };
    return `
      <div class="enhanced-panel">
        <style>
          .addresses-container {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
          }
          .address-table-container {
            flex: 1;
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            overflow: hidden;
          }
          .address-header {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 16px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
          }
          .address-header h4 {
            margin: 0;
            font-size: 1em;
            font-weight: 600;
          }
          .address-icon {
            font-size: 1.2em;
          }
          .address-table {
            width: 100%;
            border-collapse: collapse;
          }
          .address-table td {
            padding: 10px 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
          }
          .address-table tr:last-child td {
            border-bottom: none;
          }
          .field-label {
            width: 40%;
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.9em;
          }
          .field-value {
            color: rgba(255, 255, 255, 0.9);
            font-size: 0.9em;
          }
          .address-empty {
            padding: 30px;
            text-align: center;
            color: rgba(255, 255, 255, 0.4);
            font-style: italic;
          }
          .customer-info-section {
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            overflow: hidden;
          }
          .customer-header {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 12px 16px;
            background: rgba(255, 255, 255, 0.05);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
          }
          .customer-header h4 {
            margin: 0;
            font-size: 1em;
            font-weight: 600;
          }
          .customer-table {
            width: 100%;
            border-collapse: collapse;
          }
          .customer-table td {
            padding: 10px 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
          }
          .customer-table tr:last-child td {
            border-bottom: none;
          }
        </style>
        
        <div class="addresses-container">
          ${formatAddressTable(order.shipping_address, "shipping")}
          ${formatAddressTable(order.billing_address, "billing")}
        </div>
        
        <div class="customer-info-section">
          <div class="customer-header">
            <span class="address-icon">👤</span>
            <h4>Customer Information</h4>
          </div>
          <table class="customer-table">
            <tbody>
              <tr>
                <td class="field-label">Name</td>
                <td class="field-value">${order.user?.first_name || ""} ${order.user?.last_name || ""}</td>
              </tr>
              <tr>
                <td class="field-label">Email</td>
                <td class="field-value">${order.user?.email || "N/A"}</td>
              </tr>
              <tr>
                <td class="field-label">Phone</td>
                <td class="field-value">${order.user?.phone_number || "N/A"}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
  }
  // Removed getUpsellsContent method as it's no longer needed
  getRawDataContent() {
    const orderState = useOrderStore.getState();
    return RawDataHelper.generateRawDataContent({
      order: orderState.order,
      refId: orderState.refId,
      orderLoadedAt: orderState.orderLoadedAt,
      isLoading: orderState.isLoading,
      isProcessingUpsell: orderState.isProcessingUpsell,
      error: orderState.error,
      upsellError: orderState.upsellError,
      pendingUpsells: orderState.pendingUpsells,
      completedUpsellPages: orderState.completedUpsellPages,
      viewedUpsellPages: orderState.viewedUpsellPages,
      upsellJourney: orderState.upsellJourney
    });
  }
  getEmptyState(message = "No order loaded") {
    return `
      <div class="enhanced-panel">
        <div class="empty-state">
          <div class="empty-icon">📦</div>
          <div class="empty-text">${message}</div>
          <div class="empty-hint">Load an order to see details here</div>
        </div>
      </div>
    `;
  }
  getActions() {
    const orderState = useOrderStore.getState();
    const actions = [];
    if (orderState.order) {
      actions.push({
        label: "Clear Order",
        action: () => orderState.clearOrder(),
        variant: "danger"
      });
      actions.push({
        label: "Reload Order",
        action: async () => {
          if (orderState.refId) {
            orderState.clearOrder();
            console.log("Reload order functionality requires API client");
          }
        },
        variant: "primary"
      });
      if (orderState.pendingUpsells.length > 0) {
        actions.push({
          label: "Clear Pending",
          action: () => orderState.clearPendingUpsells(),
          variant: "secondary"
        });
      }
      actions.push({
        label: "Export Order",
        action: this.exportOrder,
        variant: "secondary"
      });
    }
    actions.push({
      label: "Reset Store",
      action: () => orderState.reset(),
      variant: "danger"
    });
    return actions;
  }
  exportOrder() {
    const orderState = useOrderStore.getState();
    const data = JSON.stringify({
      order: orderState.order,
      refId: orderState.refId,
      upsellJourney: orderState.upsellJourney,
      completedUpsellPages: orderState.completedUpsellPages,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString()
    }, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `order-state-${orderState.refId || "unknown"}-${(/* @__PURE__ */ new Date()).toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
  getCurrencySymbol(currency) {
    const symbols = {
      "USD": "$",
      "EUR": "€",
      "GBP": "£",
      "AUD": "$",
      "CAD": "$",
      "JPY": "¥",
      "CNY": "¥",
      "INR": "₹",
      "KRW": "₩",
      "BRL": "R$",
      "MXN": "$",
      "CHF": "Fr",
      "SEK": "kr",
      "NOK": "kr",
      "DKK": "kr",
      "PLN": "zł",
      "RUB": "₽",
      "ZAR": "R",
      "NZD": "$",
      "SGD": "$",
      "HKD": "$",
      "THB": "฿",
      "PHP": "₱",
      "IDR": "Rp",
      "MYR": "RM",
      "VND": "₫",
      "TRY": "₺",
      "AED": "د.إ",
      "SAR": "﷼",
      "ILS": "₪",
      "EGP": "£",
      "COP": "$",
      "CLP": "$",
      "ARS": "$",
      "PEN": "S/"
    };
    return symbols[currency] || currency + " ";
  }
}
const PURCHASE_EVENTS = ["dl_purchase", "dl_upsell_purchase"];
const ITEMS_OPTIONAL_EVENTS = [
  "dl_user_data",
  "dl_view_cart",
  "dl_view_item_list",
  "dl_view_search_results"
];
const VALUE_REQUIRED_EVENTS = [
  "dl_view_item",
  "dl_add_to_cart",
  "dl_remove_from_cart",
  "dl_view_cart",
  "dl_begin_checkout",
  "dl_add_shipping_info",
  "dl_add_payment_info",
  "dl_purchase",
  "dl_upsell_purchase"
];
const SHIPPING_RELEVANT_EVENTS = [
  "dl_add_shipping_info",
  "dl_purchase",
  "dl_upsell_purchase"
];
const UNRESOLVED_TOKENS = ["", "undefined", "null", "nan"];
function toNumber(value) {
  if (typeof value === "number") return value;
  if (typeof value === "string") return parseFloat(value);
  return NaN;
}
function toNumberOrZero(value) {
  if (value == null || value === "") return 0;
  const n = toNumber(value);
  return Number.isFinite(n) ? n : 0;
}
function isUnresolvedId(value) {
  return value == null || UNRESOLVED_TOKENS.includes(String(value).trim().toLowerCase());
}
function looksUnresolvedName(value) {
  if (value == null) return true;
  const name = String(value).trim();
  return /undefined|\bnull\b/i.test(name) || /^package\s+0$/i.test(name);
}
function isEcommerceEvent(data) {
  if (!data || typeof data !== "object") return false;
  const hasEcommerce = data.ecommerce && typeof data.ecommerce === "object";
  const isDlEvent = typeof data.event === "string" && data.event.startsWith("dl_");
  return Boolean(hasEcommerce && isDlEvent);
}
function auditEcommerceEvent(data) {
  if (!isEcommerceEvent(data)) return [];
  const checks = [];
  const ecommerce = data.ecommerce ?? {};
  const eventName = String(data.event);
  const isPurchase = PURCHASE_EVENTS.includes(eventName);
  const items = Array.isArray(ecommerce.items) ? ecommerce.items : [];
  const multiItem = items.length > 1;
  if (!isPurchase) {
    checks.push({
      label: "Transaction ID",
      status: "skipped",
      field: "ecommerce.transaction_id",
      detail: `Not applicable — only purchase events require a transaction_id.`
    });
  } else if (isUnresolvedId(ecommerce.transaction_id)) {
    checks.push({
      label: "Transaction ID",
      status: "error",
      field: "ecommerce.transaction_id",
      detail: `Missing transaction_id on ${eventName} — GA4 cannot de-duplicate the purchase, so revenue may be double-counted.`
    });
  } else {
    checks.push({
      label: "Transaction ID",
      status: "pass",
      field: "ecommerce.transaction_id",
      detail: `Present: "${ecommerce.transaction_id}".`
    });
  }
  if (isUnresolvedId(ecommerce.currency)) {
    checks.push({
      label: "Currency",
      status: "warning",
      field: "ecommerce.currency",
      detail: `Missing currency "${ecommerce.currency}" — some platforms reject the event.`
    });
  } else {
    checks.push({
      label: "Currency",
      status: "pass",
      field: "ecommerce.currency",
      detail: `Present: "${ecommerce.currency}".`
    });
  }
  if (items.length > 0) {
    checks.push({
      label: "Items present",
      status: "pass",
      field: "ecommerce.items",
      detail: `${items.length} item${items.length === 1 ? "" : "s"} in the payload.`
    });
  } else if (ITEMS_OPTIONAL_EVENTS.includes(eventName)) {
    checks.push({
      label: "Items present",
      status: "skipped",
      field: "ecommerce.items",
      detail: `Empty items is allowed for ${eventName} (cart/list snapshot).`
    });
  } else {
    checks.push({
      label: "Items present",
      status: "warning",
      field: "ecommerce.items",
      detail: `No items in the ecommerce payload for ${eventName}.`
    });
  }
  let itemsTotal = 0;
  let itemsTotalComputable = items.length > 0;
  items.forEach((item, i) => {
    const base = `ecommerce.items[${i}]`;
    const prefix = multiItem ? `Item ${i + 1} · ` : "";
    if (isUnresolvedId(item?.item_id)) {
      checks.push({
        label: `${prefix}Package ID resolved`,
        status: "error",
        field: `${base}.item_id`,
        detail: `Unresolved item_id "${item?.item_id}" — the package was not resolved.`
      });
    } else {
      checks.push({
        label: `${prefix}Package ID resolved`,
        status: "pass",
        field: `${base}.item_id`,
        detail: `item_id "${item?.item_id}".`
      });
    }
    if (looksUnresolvedName(item?.item_name)) {
      checks.push({
        label: `${prefix}Package name resolved`,
        status: "error",
        field: `${base}.item_name`,
        detail: `Unresolved item_name "${item?.item_name}" — the package was not resolved.`
      });
    } else {
      checks.push({
        label: `${prefix}Package name resolved`,
        status: "pass",
        field: `${base}.item_name`,
        detail: `item_name "${item?.item_name}".`
      });
    }
    const price = toNumber(item?.price);
    const quantity = toNumber(item?.quantity);
    if (!Number.isFinite(price) || price < 0) {
      checks.push({
        label: `${prefix}Price valid`,
        status: "warning",
        field: `${base}.price`,
        detail: `Invalid price "${item?.price}".`
      });
      itemsTotalComputable = false;
    } else {
      checks.push({
        label: `${prefix}Price valid`,
        status: "pass",
        field: `${base}.price`,
        detail: `Per-unit price ${price}.`
      });
    }
    if (!Number.isFinite(quantity) || quantity < 1) {
      checks.push({
        label: `${prefix}Quantity valid`,
        status: "warning",
        field: `${base}.quantity`,
        detail: `Invalid quantity "${item?.quantity}" (expected ≥ 1).`
      });
      itemsTotalComputable = false;
    } else {
      checks.push({
        label: `${prefix}Quantity valid`,
        status: "pass",
        field: `${base}.quantity`,
        detail: `Quantity ${quantity}.`
      });
    }
    if (Number.isFinite(price) && Number.isFinite(quantity)) {
      itemsTotal += price * quantity;
    }
  });
  const value = toNumber(ecommerce.value);
  const hasValue = ecommerce.value != null && ecommerce.value !== "";
  const valueRequired = isPurchase || VALUE_REQUIRED_EVENTS.includes(eventName);
  if (hasValue && (!Number.isFinite(value) || value < 0)) {
    checks.push({
      label: "Revenue value",
      status: "warning",
      field: "ecommerce.value",
      detail: `Invalid ecommerce.value "${ecommerce.value}".`
    });
  } else if (!hasValue && isPurchase) {
    checks.push({
      label: "Revenue value",
      status: "error",
      field: "ecommerce.value",
      detail: `Missing ecommerce.value on ${eventName} — no revenue is reported.`
    });
  } else if (!hasValue && valueRequired) {
    checks.push({
      label: "Revenue value",
      status: "warning",
      field: "ecommerce.value",
      detail: `Missing ecommerce.value on ${eventName} — GA4 expects value (item revenue) alongside currency.`
    });
  } else if (hasValue) {
    checks.push({
      label: "Revenue value",
      status: "pass",
      field: "ecommerce.value",
      detail: `value ${value}.`
    });
  } else {
    checks.push({
      label: "Revenue value",
      status: "skipped",
      field: "ecommerce.value",
      detail: `No value on ${eventName} — not required for this event.`
    });
  }
  if (!itemsTotalComputable) {
    checks.push({
      label: "Revenue reconciles",
      status: "skipped",
      field: "ecommerce.value",
      detail: `Not checked — no items or an invalid item price/quantity.`
    });
  } else if (!hasValue || !Number.isFinite(value)) {
    checks.push({
      label: "Revenue reconciles",
      status: "skipped",
      field: "ecommerce.value",
      detail: `Not checked — no revenue value to reconcile against.`
    });
  } else {
    const { reconciles, diagnosis } = reconcileValue(
      itemsTotal,
      value,
      toNumberOrZero(ecommerce.tax),
      toNumberOrZero(ecommerce.shipping)
    );
    checks.push({
      label: "Revenue reconciles",
      status: reconciles ? "pass" : "warning",
      field: "ecommerce.value",
      detail: reconciles ? `Items total ${itemsTotal.toFixed(2)} = ecommerce.value ${value.toFixed(2)} (Σ price × quantity).` : `ecommerce.value ${value.toFixed(2)} ≠ items total ${itemsTotal.toFixed(2)} (value must equal Σ price × quantity)` + (diagnosis ? ` — ${diagnosis}` : ".")
    });
  }
  if (SHIPPING_RELEVANT_EVENTS.includes(eventName)) {
    const hasShipping = ecommerce.shipping != null && ecommerce.shipping !== "";
    const shippingNum = toNumber(ecommerce.shipping);
    if (!hasShipping) {
      checks.push({
        label: "Shipping cost",
        status: "skipped",
        field: "ecommerce.shipping",
        detail: `No shipping in payload — free shipping, or a method is not selected yet.`
      });
    } else if (!Number.isFinite(shippingNum) || shippingNum < 0) {
      checks.push({
        label: "Shipping cost",
        status: "warning",
        field: "ecommerce.shipping",
        detail: `Invalid shipping "${ecommerce.shipping}".`
      });
    } else {
      checks.push({
        label: "Shipping cost",
        status: "pass",
        field: "ecommerce.shipping",
        detail: `Shipping ${shippingNum.toFixed(2)}.`
      });
    }
  }
  if (eventName === "dl_add_shipping_info") {
    const tier = ecommerce.shipping_tier ?? data.shipping_tier;
    if (isUnresolvedId(tier)) {
      checks.push({
        label: "Shipping tier",
        status: "warning",
        field: "ecommerce.shipping_tier",
        detail: `Missing shipping_tier — GA4 recommends the chosen shipping method (e.g. "Ground").`
      });
    } else {
      checks.push({
        label: "Shipping tier",
        status: "pass",
        field: "ecommerce.shipping_tier",
        detail: `"${tier}".`
      });
    }
  }
  if (eventName === "dl_add_payment_info") {
    const paymentType = ecommerce.payment_type ?? data.payment_type;
    if (isUnresolvedId(paymentType)) {
      checks.push({
        label: "Payment type",
        status: "warning",
        field: "ecommerce.payment_type",
        detail: `Missing payment_type — GA4 recommends the chosen payment method (e.g. "Credit Card").`
      });
    } else {
      checks.push({
        label: "Payment type",
        status: "pass",
        field: "ecommerce.payment_type",
        detail: `"${paymentType}".`
      });
    }
  }
  const meta = data.upsell_metadata;
  if (meta && typeof meta === "object") {
    if (isUnresolvedId(meta.package_id) || String(meta.package_id) === "0") {
      checks.push({
        label: "Upsell package ID resolved",
        status: "error",
        field: "upsell_metadata.package_id",
        detail: `Unresolved package_id "${meta.package_id}".`
      });
    } else {
      checks.push({
        label: "Upsell package ID resolved",
        status: "pass",
        field: "upsell_metadata.package_id",
        detail: `package_id "${meta.package_id}".`
      });
    }
    if (looksUnresolvedName(meta.package_name)) {
      checks.push({
        label: "Upsell package name resolved",
        status: "error",
        field: "upsell_metadata.package_name",
        detail: `Unresolved package_name "${meta.package_name}".`
      });
    } else {
      checks.push({
        label: "Upsell package name resolved",
        status: "pass",
        field: "upsell_metadata.package_name",
        detail: `package_name "${meta.package_name}".`
      });
    }
  }
  return checks;
}
function isDataLayerEvent(data) {
  return Boolean(data) && typeof data === "object" && typeof data.event === "string" && data.event.startsWith("dl_");
}
function auditDataLayerEvent(data) {
  if (!isDataLayerEvent(data)) return [];
  const checks = [];
  const eventName = String(data.event);
  checks.push({
    label: "Event name",
    status: "pass",
    field: "event",
    detail: `"${eventName}".`
  });
  if (isUnresolvedId(data.event_id)) {
    checks.push({
      label: "Event ID",
      status: "warning",
      field: "event_id",
      detail: `Missing event_id — this event cannot be matched to a provider delivery record.`
    });
  } else {
    checks.push({
      label: "Event ID",
      status: "pass",
      field: "event_id",
      detail: `"${data.event_id}" — used to correlate provider delivery.`
    });
  }
  checks.push(...auditEcommerceEvent(data));
  return checks;
}
function checksToIssues(checks) {
  return checks.filter(
    (c) => c.status === "error" || c.status === "warning"
  ).map((c) => ({ level: c.status, field: c.field, message: c.detail }));
}
function validateDataLayerEvent(data) {
  return checksToIssues(auditDataLayerEvent(data));
}
function worstLevel(issues) {
  if (issues.some((i) => i.level === "error")) return "error";
  if (issues.length > 0) return "warning";
  return null;
}
const DELIVERY_STATUS_ICON = {
  sent: "check-circle",
  blocked: "ban",
  skipped: "minus-circle",
  failed: "x-circle",
  pending: "clock"
};
const DELIVERY_STATUS_COLOR = {
  sent: "#1f9d55",
  blocked: "#9aa0a6",
  skipped: "#6b7280",
  failed: "#e3342f",
  pending: "#d6a700"
};
const FLOW_NODE_H = 42;
const FLOW_NODE_GAP = 8;
const FLOW_WIRE_W = 44;
const INTERNAL_EVENT_PATTERNS = [
  "cart:updated",
  "cart:item-added",
  "cart:item-removed",
  "cart:quantity-changed",
  "cart:package-swapped",
  "campaign:loaded",
  "checkout:started",
  "checkout:form-initialized",
  "checkout:spreedly-ready",
  "checkout:express-started",
  "order:completed",
  "order:redirect-missing",
  "error:occurred",
  "timer:expired",
  "config:updated",
  "coupon:applied",
  "coupon:removed",
  "coupon:validation-failed",
  "selector:item-selected",
  "selector:action-completed",
  "selector:selection-changed",
  "shipping:method-selected",
  "shipping:method-changed",
  "action:success",
  "action:failed",
  "upsell:accepted",
  "upsell-selector:item-selected",
  "upsell:quantity-changed",
  "upsell:option-selected",
  "message:displayed",
  "payment:tokenized",
  "payment:error",
  "checkout:express-completed",
  "checkout:express-failed",
  "express-checkout:initialized",
  "express-checkout:error",
  "express-checkout:started",
  "express-checkout:failed",
  "express-checkout:completed",
  "express-checkout:redirect-missing",
  "address:autocomplete-filled",
  "address:location-fields-shown",
  "checkout:location-fields-shown",
  "checkout:billing-location-fields-shown",
  "upsell:initialized",
  "upsell:adding",
  "upsell:added",
  "upsell:error",
  "accordion:toggled",
  "accordion:opened",
  "accordion:closed",
  "upsell:skipped",
  "upsell:viewed",
  "exit-intent:shown",
  "exit-intent:clicked",
  "exit-intent:dismissed",
  "exit-intent:closed",
  "exit-intent:action",
  "fomo:shown"
];
const FILTERED_EVENTS = [
  "dataLayer.push",
  "gtm.dom",
  "gtm.js",
  "gtm.load",
  "gtm.click",
  "gtm.linkClick",
  "gtm.scrollDepth",
  "gtm.timer",
  "gtm.historyChange",
  "gtm.video"
];
const _EventTimelinePanel = class _EventTimelinePanel {
  // Clear after 2 hours
  constructor() {
    this.id = "event-timeline";
    this.title = "Analytics & Events";
    this.icon = lucide("activity");
    this.events = [];
    this.maxEvents = 1e3;
    this.isRecording = true;
    this.showInternalEvents = false;
    this.view = "analytics";
    this.updateTimeout = null;
    this.saveTimeout = null;
    this.selectedEventId = null;
    this.selectedDetailTab = "flow";
    this.selectedFlowNode = null;
    this.searchTerm = "";
    this.providerFilter = null;
    this.issuesOnly = false;
    this.filterDrawerOpen = false;
    this.eventBus = EventBus.getInstance();
    const urlParams = new URLSearchParams(window.location.search);
    const windowConfig = window.nextConfig;
    const isDebugMode = urlParams.get("debugger") === "true" || urlParams.get("debug") === "true" || windowConfig?.debugger === true || windowConfig?.debug === true;
    if (isDebugMode) {
      this.loadSavedState();
      this.initializeEventWatching();
      _EventTimelinePanel.instance = this;
    }
  }
  loadSavedState() {
    this.checkAndCleanExpiredStorage();
    const savedShowInternal = localStorage.getItem(
      _EventTimelinePanel.SHOW_INTERNAL_KEY
    );
    if (savedShowInternal !== null) {
      this.showInternalEvents = savedShowInternal === "true";
    }
    const savedView = localStorage.getItem(_EventTimelinePanel.VIEW_KEY);
    if (savedView === "analytics" || savedView === "events") {
      this.view = savedView;
    }
    try {
      const savedEvents = localStorage.getItem(
        _EventTimelinePanel.EVENTS_STORAGE_KEY
      );
      if (savedEvents) {
        const parsed = JSON.parse(savedEvents);
        if (Array.isArray(parsed)) {
          const oneHourAgo = Date.now() - 60 * 60 * 1e3;
          this.events = parsed.filter((event) => event.timestamp > oneHourAgo).slice(0, _EventTimelinePanel.MAX_STORED_EVENTS).map((event) => ({
            ...event,
            relativeTime: this.formatRelativeTime(event.timestamp)
          }));
        }
      }
    } catch (error) {
      console.error("Failed to load saved events:", error);
      localStorage.removeItem(_EventTimelinePanel.EVENTS_STORAGE_KEY);
    }
  }
  checkAndCleanExpiredStorage() {
    try {
      const expiryTime = localStorage.getItem(
        _EventTimelinePanel.STORAGE_EXPIRY_KEY
      );
      const now = Date.now();
      if (!expiryTime || parseInt(expiryTime) < now) {
        localStorage.removeItem(_EventTimelinePanel.EVENTS_STORAGE_KEY);
        const newExpiry = now + _EventTimelinePanel.STORAGE_EXPIRY_HOURS * 60 * 60 * 1e3;
        localStorage.setItem(
          _EventTimelinePanel.STORAGE_EXPIRY_KEY,
          newExpiry.toString()
        );
      }
    } catch (error) {
      console.error("Failed to check storage expiry:", error);
    }
  }
  saveEvents() {
    if (this.saveTimeout) {
      clearTimeout(this.saveTimeout);
    }
    this.saveTimeout = setTimeout(() => {
      try {
        const oneHourAgo = Date.now() - 60 * 60 * 1e3;
        const recentEvents = this.events.filter((event) => event.timestamp > oneHourAgo).slice(0, _EventTimelinePanel.MAX_STORED_EVENTS);
        if (recentEvents.length > 0) {
          const simplifiedEvents = recentEvents.map((event) => ({
            id: event.id,
            timestamp: event.timestamp,
            type: event.type,
            name: event.name,
            // Limit data size to first 200 chars if it's a string
            data: typeof event.data === "string" && event.data.length > 200 ? event.data.substring(0, 200) + "..." : event.data,
            source: event.source,
            isInternal: event.isInternal
          }));
          const serialized = this.safeStringify(simplifiedEvents);
          if (serialized.length > 5e5) {
            const halfEvents = simplifiedEvents.slice(
              0,
              Math.floor(simplifiedEvents.length / 2)
            );
            localStorage.setItem(
              _EventTimelinePanel.EVENTS_STORAGE_KEY,
              this.safeStringify(halfEvents)
            );
          } else {
            localStorage.setItem(
              _EventTimelinePanel.EVENTS_STORAGE_KEY,
              serialized
            );
          }
        }
        if (!localStorage.getItem(_EventTimelinePanel.STORAGE_EXPIRY_KEY)) {
          const expiry = Date.now() + _EventTimelinePanel.STORAGE_EXPIRY_HOURS * 60 * 60 * 1e3;
          localStorage.setItem(
            _EventTimelinePanel.STORAGE_EXPIRY_KEY,
            expiry.toString()
          );
        }
      } catch (error) {
        console.error("Failed to save events:", error);
        if (error instanceof DOMException && error.name === "QuotaExceededError") {
          localStorage.removeItem(_EventTimelinePanel.EVENTS_STORAGE_KEY);
        }
      }
    }, 500);
  }
  safeStringify(obj) {
    const seen = /* @__PURE__ */ new WeakSet();
    return JSON.stringify(obj, (_key, value) => {
      if (typeof value === "object" && value !== null) {
        if (seen.has(value)) {
          return "[Circular Reference]";
        }
        seen.add(value);
      }
      if (value instanceof Window) return "[Window]";
      if (value instanceof Document) return "[Document]";
      if (value instanceof HTMLElement) return "[HTMLElement]";
      if (value instanceof Node) return "[Node]";
      if (value instanceof Event) {
        return {
          type: value.type,
          target: value.target ? "[EventTarget]" : void 0,
          timeStamp: value.timeStamp,
          bubbles: value.bubbles,
          cancelable: value.cancelable
        };
      }
      if (typeof value === "function") return "[Function]";
      return value;
    });
  }
  toggleInternalEvents() {
    this.showInternalEvents = !this.showInternalEvents;
    localStorage.setItem(
      _EventTimelinePanel.SHOW_INTERNAL_KEY,
      String(this.showInternalEvents)
    );
  }
  setView(view) {
    this.view = view;
    localStorage.setItem(_EventTimelinePanel.VIEW_KEY, view);
  }
  initializeEventWatching() {
    this.watchDataLayer();
    this.watchInternalEvents();
    this.watchDOMEvents();
    this.watchPerformanceEvents();
  }
  watchDataLayer() {
    if (typeof window === "undefined") return;
    window.dataLayer = window.dataLayer || [];
    const originalPush = window.dataLayer.push;
    window.dataLayer.push = (...args) => {
      if (this.isRecording) {
        args.forEach((event) => {
          let source = "GTM DataLayer";
          let isInternal = false;
          if (event.event && event.event.startsWith("gtm_")) {
            source = "GTM Internal";
            isInternal = true;
          } else if (event.timestamp || event.event_context) {
            source = "Analytics Manager";
          }
          if (event.event && INTERNAL_EVENT_PATTERNS.includes(event.event)) {
            isInternal = true;
          }
          this.addEvent({
            type: "dataLayer",
            name: event.event || "dataLayer.push",
            data: event,
            source,
            isInternal
          });
        });
      }
      return originalPush.apply(window.dataLayer, args);
    };
    if (window.dataLayer.length > 0) {
      window.dataLayer.forEach((event) => {
        if (typeof event === "object" && event.event) {
          this.addEvent({
            type: "dataLayer",
            name: event.event,
            data: event,
            source: "GTM DataLayer (Historical)",
            isInternal: INTERNAL_EVENT_PATTERNS.includes(event.event)
          });
        }
      });
    }
  }
  watchInternalEvents() {
    const eventHandler = (eventName, data) => {
      if (eventName.includes("error") || eventName.includes("Error")) {
        return;
      }
      if (this.isRecording) {
        this.addEvent({
          type: "internal",
          name: eventName,
          data,
          source: "SDK EventBus",
          isInternal: true
        });
      }
    };
    const originalEmit = this.eventBus.emit.bind(this.eventBus);
    this.eventBus.emit = (event, data) => {
      eventHandler(event, data);
      return originalEmit(event, data);
    };
  }
  watchDOMEvents() {
    if (typeof window === "undefined") return;
    const eventsToWatch = [
      "click",
      "submit",
      "change",
      "focus",
      "blur",
      "scroll",
      "resize",
      "load"
      // Removed 'error' to prevent infinite loops
    ];
    const eventsToIgnore = [
      "debug:event-added",
      "debug:update-content",
      "debug:panel-switched",
      // Webflow interaction events
      "ix2-animation-started",
      "ix2-animation-stopped",
      "ix2-animation-completed",
      "ix2-animation-paused",
      "ix2-animation-resumed",
      "ix2-animation",
      "ix2-element-hover",
      "ix2-element-unhover",
      "ix2-element-click",
      "ix2-page-start",
      "ix2-page-finish",
      "ix2-scroll",
      "ix2-tabs-change",
      "ix2-slider-change",
      "ix2-dropdown-open",
      "ix2-dropdown-close",
      // Other Webflow events
      "w-close",
      "w-open",
      "w-tab-active",
      "w-tab-inactive",
      "w-slider-move",
      "w-dropdown-toggle"
    ];
    const originalDispatch = EventTarget.prototype.dispatchEvent;
    EventTarget.prototype.dispatchEvent = function(event) {
      if (event instanceof CustomEvent && !eventsToWatch.includes(event.type) && !eventsToIgnore.includes(event.type) && !event.type.startsWith("debug:") && !event.type.startsWith("ix2-") && !event.type.startsWith("w-") && !event.type.includes("error") && !event.type.includes("Error")) {
        const self = _EventTimelinePanel.getInstance();
        if (self && self.isRecording) {
          try {
            self.addEvent({
              type: "dom",
              name: event.type,
              data: event.detail || {},
              source: "DOM CustomEvent",
              isInternal: INTERNAL_EVENT_PATTERNS.includes(event.type)
            });
          } catch (e) {
          }
        }
      }
      return originalDispatch.call(this, event);
    };
  }
  static getInstance() {
    return _EventTimelinePanel.instance;
  }
  watchPerformanceEvents() {
    if (typeof window === "undefined" || !window.performance) return;
    const self = this;
    const originalMark = performance.mark;
    performance.mark = function(name) {
      const result = originalMark.call(performance, name);
      if (self.isRecording) {
        self.addEvent({
          type: "performance",
          name: `mark: ${name}`,
          data: { markName: name },
          source: "Performance API",
          isInternal: true
        });
      }
      return result;
    };
    const originalMeasure = performance.measure;
    performance.measure = function(name, startMark, endMark) {
      const result = originalMeasure.call(
        performance,
        name,
        startMark,
        endMark
      );
      if (self.isRecording) {
        self.addEvent({
          type: "performance",
          name: `measure: ${name}`,
          data: { measureName: name, startMark, endMark },
          source: "Performance API",
          isInternal: true
        });
      }
      return result;
    };
  }
  addEvent(eventData) {
    if (FILTERED_EVENTS.includes(eventData.name || "")) {
      return;
    }
    const now = Date.now();
    const event = {
      id: `event_${now}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: eventData.timestamp || now,
      type: eventData.type || "internal",
      name: eventData.name || "unknown",
      data: eventData.data || {},
      source: eventData.source || "Unknown",
      relativeTime: this.formatRelativeTime(eventData.timestamp || now),
      isInternal: eventData.isInternal || false
    };
    this.events.unshift(event);
    if (this.events.length > this.maxEvents) {
      this.events = this.events.slice(0, this.maxEvents);
    }
    this.saveEvents();
    if (typeof document !== "undefined") {
      if (this.updateTimeout) {
        clearTimeout(this.updateTimeout);
      }
      this.updateTimeout = setTimeout(() => {
        document.dispatchEvent(
          new CustomEvent("debug:event-added", {
            detail: {
              panelId: this.id,
              event
            }
          })
        );
      }, 100);
    }
  }
  formatRelativeTime(timestamp) {
    const diff = Date.now() - timestamp;
    const seconds = Math.floor(diff / 1e3);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    if (hours > 0) return `${hours}h ${minutes % 60}m ago`;
    if (minutes > 0) return `${minutes}m ${seconds % 60}s ago`;
    if (seconds > 0) return `${seconds}s ago`;
    return "just now";
  }
  formatTimestamp(timestamp) {
    const date = new Date(timestamp);
    const time = date.toLocaleTimeString("en-US", {
      hour12: false,
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit"
    });
    const ms = date.getMilliseconds().toString().padStart(3, "0");
    return `${time}.${ms}`;
  }
  getFilteredEvents() {
    let events;
    if (this.view === "analytics") {
      events = this.events.filter((event) => event.name.startsWith("dl_"));
    } else if (this.showInternalEvents) {
      events = this.events;
    } else {
      events = this.events.filter((event) => !event.isInternal);
    }
    const term = this.searchTerm.trim().toLowerCase();
    if (term) {
      events = events.filter(
        (e) => e.name.toLowerCase().includes(term) || e.source.toLowerCase().includes(term)
      );
    }
    if (this.providerFilter) {
      events = events.filter(
        (e) => this.getDeliveriesForEvent(e).some(
          (d) => d.provider === this.providerFilter
        )
      );
    }
    if (this.issuesOnly) {
      events = events.filter((e) => this.eventHasIssues(e));
    }
    return events;
  }
  /** True when an event failed/was blocked by a provider, or fails validation. */
  eventHasIssues(event) {
    const deliveryProblem = this.getDeliveriesForEvent(event).some(
      (d) => d.status === "failed" || d.status === "blocked"
    );
    return deliveryProblem || Boolean(worstLevel(this.getEventIssues(event)));
  }
  /** True when any timeline filter (search/provider/issues) is active. */
  hasActiveFilters() {
    return this.activeFilterCount() > 0;
  }
  /** Number of active narrowing filters — drives the filter button badge. */
  activeFilterCount() {
    let n = 0;
    if (this.searchTerm.trim() !== "") n += 1;
    if (this.providerFilter !== null) n += 1;
    if (this.issuesOnly) n += 1;
    return n;
  }
  getEventTypeColor(type) {
    const colors = {
      dataLayer: "#4CAF50",
      internal: "#2196F3",
      dom: "#FF9800",
      performance: "#9C27B0"
    };
    return colors[type] || "#666";
  }
  getEventTypeBadge(type) {
    const badges = {
      dataLayer: "GTM",
      internal: "SDK",
      dom: "DOM",
      performance: "PERF"
    };
    return badges[type] || type.toUpperCase();
  }
  /** Validation issues for an event's ecommerce payload (dataLayer only). */
  getEventIssues(event) {
    if (event.type !== "dataLayer") return [];
    return validateDataLayerEvent(event.data);
  }
  /** Full validation checklist (pass + fail + skipped) for the detail view. */
  getEventChecks(event) {
    if (event.type !== "dataLayer") return [];
    return auditDataLayerEvent(event.data);
  }
  /** Why a given event has no checklist — shown in the empty Validation tab. */
  noValidationReason(event) {
    if (event.type !== "dataLayer") {
      return `Validation applies to dataLayer (<code>dl_</code>) events. This is a ${event.type} event — nothing to validate.`;
    }
    return `Not a <code>dl_</code> event, so there is no dataLayer contract to validate.`;
  }
  renderValidationBadge(event) {
    const level = worstLevel(this.getEventIssues(event));
    if (!level) return "";
    const isError = level === "error";
    const cls = isError ? "validation-badge validation-badge-error" : "validation-badge validation-badge-warning";
    const ico = lucide(isError ? "x-circle" : "alert", { size: 12 });
    return `<span class="${cls}">${ico} ${isError ? "INVALID" : "CHECK"}</span>`;
  }
  renderCheckRow(check) {
    const icon = _EventTimelinePanel.CHECK_ICON[check.status];
    return `
      <li class="event-check event-check-${check.status}">
        <span class="event-check-status">${lucide(icon, { size: 14 })}</span>
        <div class="event-check-body">
          <div class="event-check-head">
            <span class="event-check-label">${this.escapeHtml(check.label)}</span>
            <code class="event-check-field">${this.escapeHtml(check.field)}</code>
          </div>
          <div class="event-check-detail">${this.escapeHtml(check.detail)}</div>
        </div>
      </li>`;
  }
  renderValidationSection(event) {
    const checks = this.getEventChecks(event);
    if (checks.length === 0) return "";
    const errors = checks.filter((c) => c.status === "error").length;
    const warnings = checks.filter((c) => c.status === "warning").length;
    const passed = checks.filter((c) => c.status === "pass").length;
    const checked = checks.filter((c) => c.status !== "skipped").length;
    const summaryClass = errors ? "event-validation-fail" : warnings ? "event-validation-warn" : "event-validation-ok";
    const summaryIcon = errors ? "x-circle" : warnings ? "alert" : "check-circle";
    const summaryText = errors ? `${errors} failed, ${warnings} warning${warnings === 1 ? "" : "s"} of ${checked} checks` : warnings ? `${warnings} warning${warnings === 1 ? "" : "s"} of ${checked} checks` : `All ${passed} checks passed`;
    const rows = checks.map((c) => this.renderCheckRow(c)).join("");
    return `
      <div class="event-validation ${summaryClass}">
        <div class="event-validation-summary">
          <span class="event-validation-icon">${lucide(summaryIcon, { size: 14 })}</span>
          <span class="event-validation-summary-text">${summaryText}</span>
        </div>
        <ul class="event-check-list">${rows}</ul>
      </div>`;
  }
  escapeHtml(value) {
    return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  // ── Provider delivery correlation ──────────────────────────────────────────
  // dataLayer events carry `event_id`; provider delivery records carry the same
  // id, so a timeline event can be joined to "who received it".
  getEventId(event) {
    const id = event.data?.event_id;
    return typeof id === "string" ? id : void 0;
  }
  /** Delivery records that belong to this timeline event (matched by event_id). */
  getDeliveriesForEvent(event) {
    const eventId = this.getEventId(event);
    if (!eventId) return [];
    return analyticsDebug.getDeliveries().filter((record) => record.eventId === eventId);
  }
  formatDeliveryDuration(ms) {
    if (ms === void 0) return "";
    return ms < 1e3 ? `${ms}ms` : `${(ms / 1e3).toFixed(2)}s`;
  }
  /**
   * Per-provider delivery chips shown on an event row — one chip per provider
   * that handled the event, tinted by its delivery status (sent/failed/…), so
   * you can see at a glance who received it without opening the modal.
   */
  renderDeliverySummary(event) {
    const deliveries = this.getDeliveriesForEvent(event);
    if (deliveries.length === 0) return "";
    const chips = deliveries.map((d) => {
      const color = DELIVERY_STATUS_COLOR[d.status];
      const duration = this.formatDeliveryDuration(d.durationMs);
      const title = `${d.provider}: ${d.status}` + (duration ? ` · ${duration}` : "") + (d.error ? ` · ${d.error}` : d.detail ? ` · ${d.detail}` : "");
      const brand = this.providerIcon(d.provider);
      const glyph = brand ? lucide(brand, { size: 11 }) : lucide(DELIVERY_STATUS_ICON[d.status], { size: 11 });
      return `<span class="delivery-chip" style="--chip:${color}" title="${this.escapeAttr(title)}">${glyph}<span class="delivery-chip-name">${this.escapeHtml(this.providerAbbrev(d.provider))}</span></span>`;
    }).join("");
    return `<span class="delivery-summary" title="Provider delivery">${chips}</span>`;
  }
  /**
   * Short provider label for compact row chips (Facebook → FB, RudderStack → RS).
   * Falls back to the capital-letter acronym, then the first 3 characters.
   */
  providerAbbrev(name) {
    const known = {
      NextCampaign: "NEXT",
      GTM: "GTM",
      Facebook: "FB",
      RudderStack: "RS"
    };
    if (known[name]) return known[name];
    const caps = name.replace(/[^A-Z]/g, "");
    return (caps.length >= 2 ? caps : name.slice(0, 3)).toUpperCase();
  }
  /**
   * Brand icon for a provider, when one exists (GTM, Facebook, RudderStack,
   * NextCampaign). Returns null for providers without a brand glyph (e.g.
   * Custom), so callers fall back to a generic/status icon.
   */
  providerIcon(name) {
    const map = {
      // NextCampaign is the SDK's own provider — its "N" brand mark.
      NextCampaign: "next",
      GTM: "gtm",
      Facebook: "facebook",
      RudderStack: "rudderstack"
    };
    return map[name] ?? null;
  }
  /**
   * The Flow tab: a node graph of the event. The source ("Original event") node
   * on the left fans out to one node per provider that handled it; the panel
   * below shows the selected node's payload — the original event for the source
   * node, the transformed payload each provider actually dispatched otherwise.
   */
  renderFlowDetail(event) {
    const deliveries = this.getDeliveriesForEvent(event);
    if (deliveries.length === 0) {
      return `
        <div class="flow">
          <div class="flow-graph flow-graph-solo">
            ${this.renderFlowSourceNode(event, [], true)}
          </div>
          <div class="flow-detail">
            <div class="delivery-empty">
              No provider deliveries recorded for this event.
              ${this.getEventId(event) ? "Providers may have been disabled, or this event is not dispatched to the provider layer." : "This event has no <code>event_id</code>, so it cannot be matched to a provider delivery."}
            </div>
            <div class="flow-detail-view">${RawDataHelper.generateRawDataContent(event.data)}</div>
          </div>
        </div>`;
    }
    const selected = this.selectedFlowNode ? deliveries.find((d) => d.id === this.selectedFlowNode) ?? null : null;
    const providerNodes = deliveries.map((d) => this.renderFlowProviderNode(d, selected?.id === d.id)).join("");
    const detail = selected ? this.renderFlowProviderPanel(selected) : this.renderFlowSourcePanel(event, deliveries.length);
    return `
      <div class="flow">
        <div class="flow-graph">
          <div class="flow-col flow-col-source">
            ${this.renderFlowSourceNode(event, deliveries, selected === null)}
          </div>
          <div class="flow-col flow-col-wire">
            ${this.renderFlowWire(deliveries, selected?.id ?? null)}
          </div>
          <div class="flow-col flow-col-providers">
            ${providerNodes}
          </div>
        </div>
        <div class="flow-detail">${detail}</div>
      </div>`;
  }
  /**
   * The source node — the original event every provider branches from. Shows a
   * per-status delivery summary (e.g. "3 sent · 1 skipped") so you can gauge the
   * fan-out without clicking each provider.
   */
  renderFlowSourceNode(event, deliveries, active) {
    const count = deliveries.length;
    const sub = count > 0 ? `${count} provider${count === 1 ? "" : "s"}` : "no providers";
    const order = [
      "sent",
      "skipped",
      "blocked",
      "failed",
      "pending"
    ];
    const summary = order.map((status) => ({
      status,
      n: deliveries.filter((d) => d.status === status).length
    })).filter(({ n }) => n > 0).map(
      ({ status, n }) => `<span class="flow-summary-item">
             <span class="flow-summary-dot" style="background:${DELIVERY_STATUS_COLOR[status]}"></span>${n} ${status}
           </span>`
    ).join("");
    return `
      <button class="flow-node flow-node-source ${active ? "active" : ""}"
              onclick="window.eventTimelinePanel_selectFlowNode(null)">
        <span class="flow-node-kind">Original event</span>
        <span class="flow-node-name">${this.escapeHtml(event.name)}</span>
        <span class="flow-node-sub">${sub}</span>
        ${summary ? `<span class="flow-summary">${summary}</span>` : ""}
      </button>`;
  }
  /**
   * One provider node as a single table-like row: brand + name on the left,
   * status + duration right-aligned. Tinted by status, clickable for its payload.
   */
  renderFlowProviderNode(record, active) {
    const color = DELIVERY_STATUS_COLOR[record.status];
    const brand = this.providerIcon(record.provider);
    const glyph = brand ? `${lucide(brand, { size: 14 })} ` : "";
    const duration = this.formatDeliveryDuration(record.durationMs);
    return `
      <button class="flow-node flow-node-provider ${active ? "active" : ""}"
              style="--accent:${color}"
              onclick="window.eventTimelinePanel_selectFlowNode('${this.escapeAttr(record.id)}')">
        <span class="flow-node-dot" style="background:${color}"></span>
        <span class="flow-node-name">${glyph}${this.escapeHtml(record.provider)}</span>
        <span class="flow-node-status" style="color:${color}">
          ${lucide(DELIVERY_STATUS_ICON[record.status], { size: 12 })} ${record.status}${duration ? ` · ${duration}` : ""}
        </span>
      </button>`;
  }
  /**
   * SVG connectors from the source node to each provider node. Geometry is
   * arithmetic: provider node `i` sits at `i * (H + GAP) + H/2`, and the source
   * connects to the vertical centre of the whole column. The selected branch is
   * drawn thicker and in its status colour; branches that never carried the
   * event (blocked/failed) are dashed so it's clear it did not flow there.
   */
  renderFlowWire(deliveries, selectedId) {
    const n = deliveries.length;
    const colH = n * FLOW_NODE_H + (n - 1) * FLOW_NODE_GAP;
    const sourceY = colH / 2;
    const w = FLOW_WIRE_W;
    const cx = w / 2;
    const paths = deliveries.map((d, i) => {
      const y = i * (FLOW_NODE_H + FLOW_NODE_GAP) + FLOW_NODE_H / 2;
      const active = selectedId === d.id;
      const stroke = active ? DELIVERY_STATUS_COLOR[d.status] : "rgba(255,255,255,0.18)";
      const didNotFlow = d.status === "blocked" || d.status === "skipped" || d.status === "failed";
      const dash = didNotFlow ? ' stroke-dasharray="4 3"' : "";
      return `<path d="M0,${sourceY} C${cx},${sourceY} ${cx},${y} ${w},${y}" fill="none" stroke="${stroke}" stroke-width="${active ? 2 : 1.5}"${dash} />`;
    }).join("");
    return `<svg class="flow-wire" width="${w}" height="${colH}" viewBox="0 0 ${w} ${colH}" preserveAspectRatio="none">${paths}</svg>`;
  }
  /** Detail panel for the source node: the original event payload. */
  renderFlowSourcePanel(event, providerCount) {
    return `
      <div class="flow-detail-head">
        <span class="flow-detail-title">Original event · ${this.escapeHtml(event.name)}</span>
        <span class="flow-detail-meta">Dispatched to ${providerCount} provider${providerCount === 1 ? "" : "s"}</span>
      </div>
      <div class="flow-detail-view">${RawDataHelper.generateRawDataContent(event.data)}</div>`;
  }
  /**
   * Detail panel for a provider node, framed by delivery outcome:
   * - `sent` → the transformed payload the provider dispatched.
   * - `blocked` / `skipped` → nothing was sent, so no provider payload exists;
   *   show only the reason (the original event lives on the source node).
   * - `failed` → the error plus whatever it attempted.
   */
  renderFlowProviderPanel(record) {
    const provider = this.escapeHtml(record.provider);
    const dispatched = record.sentPayload !== void 0;
    const nothingSent = record.status === "blocked" || record.status === "skipped";
    const noteHtml = (text) => `<div class="flow-detail-note">${text}</div>`;
    let title;
    let note = "";
    switch (record.status) {
      case "blocked":
        title = `Blocked — nothing sent to ${provider}`;
        note = noteHtml(this.escapeHtml(record.detail || "blocked by config"));
        break;
      case "skipped":
        title = `Skipped — nothing sent to ${provider}`;
        note = noteHtml(
          this.escapeHtml(record.detail || "not handled by this provider")
        );
        break;
      case "failed":
        title = `Failed — ${provider} errored`;
        if (dispatched)
          note = noteHtml(
            "Prepared payload below — dispatch failed, so it was not confirmed delivered."
          );
        break;
      case "pending":
        title = `Sending to ${provider}…`;
        break;
      default:
        title = `Sent to ${provider}`;
        if (!dispatched)
          note = noteHtml("No payload reported — showing original event.");
    }
    const meta = [
      `<span class="flow-detail-status" style="color:${DELIVERY_STATUS_COLOR[record.status]}">${lucide(DELIVERY_STATUS_ICON[record.status], { size: 12 })} ${record.status}</span>`,
      record.durationMs !== void 0 ? `<span>${this.formatDeliveryDuration(record.durationMs)}</span>` : ""
    ].filter(Boolean).join("");
    const error = record.error ? `<div class="flow-detail-error">${this.escapeHtml(record.error)}</div>` : "";
    let body;
    if (nothingSent) {
      body = `<div class="delivery-empty">Nothing was dispatched. Select the <strong>Original event</strong> node to inspect the payload.</div>`;
    } else {
      const payload = dispatched ? record.sentPayload : record.payload;
      body = payload !== void 0 ? `<div class="flow-detail-view">${RawDataHelper.generateRawDataContent(payload)}</div>` : `<div class="delivery-empty">This provider reported no payload for this event.</div>`;
    }
    return `
      <div class="flow-detail-head">
        <span class="flow-detail-title">${title}</span>
        <span class="flow-detail-meta">${meta}</span>
      </div>
      ${note}
      ${error}
      ${body}`;
  }
  /** Tabbed detail body for the event modal: Flow / Validation. */
  renderDetailTabs(event) {
    const deliveryCount = this.getDeliveriesForEvent(event).length;
    const issues = this.getEventIssues(event);
    const issueLevel = worstLevel(issues);
    const flowBadge = deliveryCount > 0 ? `<span class="tab-count">${deliveryCount}</span>` : "";
    const validationBadge = issueLevel ? `<span class="tab-count tab-count-${issueLevel}">${issues.length}</span>` : "";
    const tab = (id, label, badge = "") => `
      <button
        class="detail-tab ${this.selectedDetailTab === id ? "active" : ""}"
        onclick="window.eventTimelinePanel_setTab('${id}')">
        ${label}${badge}
      </button>`;
    const body = this.selectedDetailTab === "validation" ? this.renderValidationSection(event) || `<div class="delivery-empty">${this.noValidationReason(event)}</div>` : this.renderFlowDetail(event);
    return `
      <div class="detail-tabs">
        ${tab("flow", "Flow", flowBadge)}
        ${tab("validation", "Validation", validationBadge)}
      </div>
      <div class="detail-tab-body detail-tab-body-${this.selectedDetailTab}">${body}</div>`;
  }
  /** Top strip: which analytics providers are registered and ready. */
  renderProviderStrip() {
    const providers = analyticsDebug.getProviders();
    if (providers.length === 0) {
      return `
        <div class="provider-strip provider-strip-empty">
          No analytics providers registered (analytics disabled or not yet initialized).
        </div>`;
    }
    const chips = providers.map((p) => {
      const status = !p.enabled ? lucide("pause", { size: 13, style: "color:#9aa0a6" }) : p.ready ? lucide("check-circle", { size: 13, style: "color:#1f9d55" }) : lucide("clock", { size: 13, style: "color:#d6a700" });
      const brand = this.providerIcon(p.name);
      const brandIcon = brand ? `<span class="provider-chip-brand">${lucide(brand, { size: 13 })}</span>` : "";
      const state = !p.enabled ? "disabled" : p.ready ? "ready" : "not ready";
      const blocked = p.blockedEvents.length > 0 ? ` · blocks ${p.blockedEvents.length}` : "";
      const active = this.providerFilter === p.name ? " active" : "";
      const hint = `${p.name}: ${state}${blocked} · click to filter timeline`;
      return `
          <button
            class="provider-chip${active}"
            title="${this.escapeHtml(hint)}"
            onclick="window.eventTimelinePanel_filterProvider('${this.escapeAttr(p.name)}')">
            ${brandIcon}
            <span class="provider-chip-name">${this.escapeHtml(p.name)}</span>
            <span class="provider-chip-icon">${status}</span>
          </button>`;
    }).join("");
    return `
      <div class="provider-strip">
        <span class="provider-strip-label">Providers</span>
        ${chips}
      </div>`;
  }
  /** Empty-state message, aware of the dl_-only default filter. */
  renderEmptyState() {
    if (this.events.length === 0) {
      return `
        <div class="empty-state">
          <div class="empty-state-icon">${lucide("inbox", { size: 44 })}</div>
          <div class="empty-state-text">No events captured yet</div>
        </div>`;
    }
    const hiddenByView = this.view === "analytics" && this.events.some((e) => !e.name.startsWith("dl_"));
    if (hiddenByView && !this.hasActiveFilters()) {
      const other = this.events.filter((e) => !e.name.startsWith("dl_")).length;
      return `
        <div class="empty-state">
          <div class="empty-state-icon">${lucide("inbox", { size: 44 })}</div>
          <div class="empty-state-text">No <code>dl_</code> events yet</div>
          <div class="empty-state-sub">${other} non-dl_ event${other === 1 ? "" : "s"} captured — switch to the Events view to see them.</div>
          <button class="filter-clear" onclick="window.eventTimelinePanel_setView('events')">Go to Events</button>
        </div>`;
    }
    return `
      <div class="empty-state">
        <div class="empty-state-icon">${lucide("search-x", { size: 44 })}</div>
        <div class="empty-state-text">No events match the current filters</div>
        ${this.hasActiveFilters() ? `
          <button class="filter-clear" onclick="window.eventTimelinePanel_clearFilters()">
            Clear filters
          </button>` : ""}
      </div>`;
  }
  /** Segmented control switching between the Analytics and Events views. */
  renderViewTabs() {
    const dlCount = this.events.filter((e) => e.name.startsWith("dl_")).length;
    const allCount = this.events.length;
    const tab = (id, label, ico, count) => `
      <button class="view-tab ${this.view === id ? "active" : ""}"
              onclick="window.eventTimelinePanel_setView('${id}')">
        ${lucide(ico, { size: 14 })}
        <span>${label}</span>
        <span class="view-tab-count">${count}</span>
      </button>`;
    return `
      <div class="view-tabs">
        ${tab("analytics", "Analytics", "chart", dlCount)}
        ${tab("events", "Events", "bolt", allCount)}
      </div>`;
  }
  /** Compact ecommerce figures for an Analytics row: total value and item count. */
  getEcommerceSummary(event) {
    const ec = event.data?.ecommerce;
    if (!ec || typeof ec !== "object") return { value: null, items: null };
    const raw = ec.value ?? ec.value_change;
    const num = typeof raw === "number" ? raw : typeof raw === "string" ? parseFloat(raw) : NaN;
    const currency = typeof ec.currency === "string" ? ec.currency : "";
    const value = Number.isFinite(num) ? `${num.toFixed(2)}${currency ? ` ${currency}` : ""}` : null;
    const arr = Array.isArray(ec.items) ? ec.items : Array.isArray(ec.items_added) ? ec.items_added : null;
    return { value, items: arr ? arr.length : null };
  }
  renderTableHead() {
    const cols = this.view === "analytics" ? `<th style="width:13%">Time</th>
           <th style="width:33%">Event</th>
           <th style="width:16%">Value</th>
           <th style="width:9%">Items</th>
           <th style="width:29%">Delivery</th>` : `<th style="width:14%">Time</th>
           <th style="width:11%">Type</th>
           <th style="width:41%">Event</th>
           <th style="width:34%">Source</th>`;
    return `<thead><tr>${cols}</tr></thead>`;
  }
  renderEventRow(event) {
    const open = `window.eventTimelinePanel_showModal('${event.id}')`;
    const time = `<td class="event-time">${this.formatTimestamp(event.timestamp)}</td>`;
    const typeBadge = `<span class="event-type-badge" style="background:${this.getEventTypeColor(event.type)}22;color:${this.getEventTypeColor(event.type)};">${this.getEventTypeBadge(event.type)}</span>`;
    if (this.view === "analytics") {
      const { value, items } = this.getEcommerceSummary(event);
      const delivery = this.renderDeliverySummary(event);
      return `
        <tr class="event-row" onclick="${open}">
          ${time}
          <td>
            <span class="event-name">${event.name}</span>
            ${this.renderValidationBadge(event)}
          </td>
          <td class="event-num">${value ?? '<span class="event-muted">—</span>'}</td>
          <td class="event-num">${items ?? '<span class="event-muted">—</span>'}</td>
          <td>${delivery || '<span class="event-muted">—</span>'}</td>
        </tr>`;
    }
    return `
      <tr class="event-row" onclick="${open}">
        ${time}
        <td>${typeBadge}</td>
        <td>
          <span class="event-name">${event.name}</span>
          ${event.isInternal ? '<span class="internal-badge">INTERNAL</span>' : ""}
          ${this.renderValidationBadge(event)}
        </td>
        <td class="event-source">${event.source}</td>
      </tr>`;
  }
  /**
   * Right-side filter drawer. The single home for all timeline filters — add
   * future filters as new `.filter-section` blocks here. Rendered only when
   * open; a transparent backdrop closes it on outside click.
   */
  renderFilterDrawer() {
    if (!this.filterDrawerOpen) return "";
    const providers = analyticsDebug.getProviders();
    const providerSection = providers.length ? providers.map((p) => {
      const on = this.providerFilter === p.name;
      return `
              <button class="filter-chip ${on ? "active" : ""}"
                      onclick="window.eventTimelinePanel_filterProvider('${this.escapeAttr(p.name)}')">
                ${on ? lucide("check", { size: 13 }) : ""}
                ${this.escapeHtml(p.name)}
              </button>`;
    }).join("") : `<span class="filter-hint">No providers registered.</span>`;
    const toggle = (active, label, onclick) => `
      <button class="filter-row-toggle ${active ? "active" : ""}" onclick="${onclick}">
        <span class="filter-checkbox">${active ? lucide("check", { size: 12 }) : ""}</span>
        ${label}
      </button>`;
    return `
      <div class="filter-backdrop" onclick="window.eventTimelinePanel_toggleDrawer()"></div>
      <aside class="filter-drawer" role="dialog" aria-label="Timeline filters">
        <header class="filter-drawer-header">
          <span class="filter-drawer-title">${lucide("filter", { size: 15 })} Filters</span>
          <button class="filter-drawer-close" title="Close" onclick="window.eventTimelinePanel_toggleDrawer()">
            ${lucide("x", { size: 16 })}
          </button>
        </header>

        <div class="filter-drawer-body">
          <div class="filter-section">
            <label class="filter-label">Search</label>
            <div class="events-search-wrap">
              ${lucide("search", { size: 14, style: "opacity:0.6" })}
              <input
                class="events-search"
                data-debug-search
                type="search"
                placeholder="Event name or source…"
                value="${this.escapeHtml(this.searchTerm).replace(/"/g, "&quot;")}"
                oninput="window.eventTimelinePanel_search(this.value)" />
            </div>
          </div>

          <div class="filter-section">
            <label class="filter-label">Provider</label>
            <div class="filter-chips">${providerSection}</div>
          </div>

          ${this.view === "events" ? `
            <div class="filter-section">
              <label class="filter-label">Events</label>
              ${toggle(this.showInternalEvents, "Include internal SDK events", "window.eventTimelinePanel_toggleInternal()")}
            </div>` : ""}

          <div class="filter-section">
            <label class="filter-label">Status</label>
            ${toggle(this.issuesOnly, "Issues only (failed/blocked or invalid)", "window.eventTimelinePanel_toggleIssues()")}
          </div>
        </div>

        <footer class="filter-drawer-footer">
          <span class="filter-hint">${this.activeFilterCount()} active</span>
          ${this.hasActiveFilters() ? `<button class="filter-clear" onclick="window.eventTimelinePanel_clearFilters()">Clear all</button>` : ""}
        </footer>
      </aside>`;
  }
  escapeAttr(value) {
    return String(value).replace(/\\/g, "\\\\").replace(/'/g, "\\'");
  }
  /** Ask the overlay to re-render this panel's content. */
  requestRerender() {
    if (typeof document !== "undefined") {
      document.dispatchEvent(
        new CustomEvent("debug:update-content", {
          detail: { panelId: this.id }
        })
      );
    }
  }
  showEventModal(eventId) {
    this.selectedEventId = eventId;
    this.selectedFlowNode = null;
    if (typeof document !== "undefined") {
      document.dispatchEvent(
        new CustomEvent("debug:update-content", {
          detail: { panelId: this.id }
        })
      );
    }
  }
  closeEventModal() {
    this.selectedEventId = null;
    if (typeof document !== "undefined") {
      document.dispatchEvent(
        new CustomEvent("debug:update-content", {
          detail: { panelId: this.id }
        })
      );
    }
  }
  getContent() {
    const filteredEvents = this.getFilteredEvents();
    const invalidCount = filteredEvents.filter(
      (e) => worstLevel(this.getEventIssues(e)) === "error"
    ).length;
    const selectedEvent = this.selectedEventId ? this.events.find((e) => e.id === this.selectedEventId) : null;
    const modalHtml = selectedEvent ? `
      <div class="event-modal-overlay" onclick="window.eventTimelinePanel_closeModal()">
        <div class="event-modal" onclick="event.stopPropagation()">
          <div class="event-modal-header">
            <h3 class="event-modal-title">${selectedEvent.name}</h3>
            <button class="event-modal-close" onclick="window.eventTimelinePanel_closeModal()">${lucide("x", { size: 16 })}</button>
          </div>
          <div class="event-modal-body">
            <div class="event-modal-meta">
              <span class="event-modal-meta-item">
                <span class="event-type-badge" style="background: ${this.getEventTypeColor(selectedEvent.type)}22; color: ${this.getEventTypeColor(selectedEvent.type)};">
                  ${this.getEventTypeBadge(selectedEvent.type)}
                </span>
              </span>
              <span class="event-modal-meta-item">
                <span class="event-modal-meta-label">Source</span>
                <span>${selectedEvent.source}</span>
              </span>
              <span class="event-modal-meta-item">
                <span class="event-modal-meta-label">Time</span>
                <span>${this.formatTimestamp(selectedEvent.timestamp)}</span>
                <span class="event-modal-meta-muted">· ${selectedEvent.relativeTime}</span>
              </span>
            </div>
            ${this.renderDetailTabs(selectedEvent)}
          </div>
        </div>
      </div>
    ` : "";
    if (typeof window !== "undefined") {
      window.eventTimelinePanel_showModal = (eventId) => {
        this.showEventModal(eventId);
      };
      window.eventTimelinePanel_closeModal = () => {
        this.closeEventModal();
      };
      window.eventTimelinePanel_setTab = (tab) => {
        this.selectedDetailTab = tab;
        this.requestRerender();
      };
      window.eventTimelinePanel_selectFlowNode = (id) => {
        this.selectedFlowNode = id;
        this.requestRerender();
      };
      window.eventTimelinePanel_search = (value) => {
        this.searchTerm = value;
        this.requestRerender();
      };
      window.eventTimelinePanel_filterProvider = (provider) => {
        this.providerFilter = this.providerFilter === provider ? null : provider;
        this.requestRerender();
      };
      window.eventTimelinePanel_toggleIssues = () => {
        this.issuesOnly = !this.issuesOnly;
        this.requestRerender();
      };
      window.eventTimelinePanel_clearFilters = () => {
        this.searchTerm = "";
        this.providerFilter = null;
        this.issuesOnly = false;
        this.requestRerender();
      };
      window.eventTimelinePanel_toggleDrawer = () => {
        this.filterDrawerOpen = !this.filterDrawerOpen;
        this.requestRerender();
      };
      window.eventTimelinePanel_toggleInternal = () => {
        this.toggleInternalEvents();
        this.requestRerender();
      };
      window.eventTimelinePanel_setView = (view) => {
        this.setView(view);
        this.requestRerender();
      };
    }
    return `
      <style>
        .events-table-container {
          height: 100%;
          display: flex;
          flex-direction: column;
          background: #0f0f0f;
          position: relative; /* anchors the filter drawer */
        }
        /* Modal Styles */
        .event-modal-overlay {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0, 0, 0, 0.8);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 100000;
          backdrop-filter: blur(4px);
        }
        .event-modal {
          background: #1a1a1a;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 12px;
          width: 90%;
          max-width: 800px;
          /* Definite height (not just max) so the flex chain has room to give
             the payload viewer — otherwise it collapses to its min-height. */
          height: 85vh;
          max-height: 820px;
          display: flex;
          flex-direction: column;
          box-shadow: 0 20px 60px rgba(0, 0, 0, 0.8);
        }
        .event-modal-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 20px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .event-modal-title {
          margin: 0;
          font-size: 1.2em;
          color: rgba(255, 255, 255, 0.9);
          font-weight: 600;
        }
        .event-modal-close {
          background: none;
          border: none;
          color: rgba(255, 255, 255, 0.6);
          font-size: 24px;
          cursor: pointer;
          padding: 0;
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 6px;
          transition: all 0.2s;
        }
        .event-modal-close:hover {
          background: rgba(255, 255, 255, 0.1);
          color: rgba(255, 255, 255, 0.9);
        }
        .event-modal-body {
          flex: 1;
          min-height: 0;
          display: flex;
          flex-direction: column;
          overflow: hidden;
          padding: 20px;
        }
        /* Compact single-row meta strip with divider between items. */
        .event-modal-meta {
          display: flex;
          flex-wrap: wrap;
          align-items: center;
          row-gap: 6px;
          margin-bottom: 18px;
          font-size: 0.85em;
        }
        .event-modal-meta-item {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 0 14px;
          color: #e6e6e6;
        }
        .event-modal-meta-item:first-child { padding-left: 0; }
        .event-modal-meta-item + .event-modal-meta-item {
          border-left: 1px solid rgba(255, 255, 255, 0.12);
        }
        .event-modal-meta-label {
          color: rgba(255, 255, 255, 0.45);
        }
        .event-modal-meta-muted { color: rgba(255, 255, 255, 0.4); }
        /* ── Provider strip ── */
        .provider-strip {
          display: flex;
          align-items: center;
          flex-wrap: wrap;
          gap: 8px;
          padding: 8px 20px;
          background: rgba(255, 255, 255, 0.03);
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
          font-size: 0.85em;
        }
        .provider-strip-empty { color: rgba(255, 255, 255, 0.5); }
        .provider-strip-label {
          color: rgba(255, 255, 255, 0.45);
          text-transform: uppercase;
          letter-spacing: 0.05em;
          font-size: 0.8em;
          margin-right: 4px;
        }
        .provider-chip {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 2px 9px;
          border-radius: 12px;
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid rgba(255, 255, 255, 0.08);
          color: #e6e6e6;
          cursor: pointer;
          font: inherit;
          transition: background 0.15s, border-color 0.15s;
        }
        .provider-chip:hover { background: rgba(255, 255, 255, 0.12); }
        .provider-chip.active {
          background: rgba(60, 125, 255, 0.22);
          border-color: #3C7DFF;
          color: #fff;
        }
        .provider-chip-icon { font-size: 0.9em; }
        .provider-chip-brand {
          display: inline-flex;
          align-items: center;
          opacity: 0.95;
        }
        /* ── Filter controls ── */
        .events-search-wrap {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 4px 8px;
          border-radius: 6px;
          background: rgba(0, 0, 0, 0.25);
          border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .events-search-icon { font-size: 0.85em; opacity: 0.6; }
        .events-search {
          background: none;
          border: none;
          outline: none;
          color: #fff;
          font: inherit;
          font-size: 0.85em;
          width: 150px;
        }
        .events-search::placeholder { color: rgba(255, 255, 255, 0.4); }
        .filter-toggle {
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: rgba(255, 255, 255, 0.75);
          padding: 5px 10px;
          border-radius: 6px;
          cursor: pointer;
          font-size: 0.82em;
          transition: all 0.15s;
        }
        .filter-toggle:hover { color: #fff; }
        .filter-toggle.active {
          background: rgba(214, 167, 0, 0.2);
          border-color: #d6a700;
          color: #ffd84d;
        }
        .filter-clear {
          background: none;
          border: none;
          color: rgba(255, 255, 255, 0.55);
          cursor: pointer;
          font-size: 0.82em;
          text-decoration: underline;
        }
        .filter-clear:hover { color: #fff; }
        /* ── Filter button (opens drawer) ── */
        .filter-button {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 6px 12px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: rgba(255, 255, 255, 0.85);
          cursor: pointer;
          font: inherit;
          font-size: 0.85em;
          transition: all 0.15s;
        }
        .filter-button:hover { background: rgba(255, 255, 255, 0.1); color: #fff; }
        .filter-button.open,
        .filter-button.active {
          border-color: #3C7DFF;
          color: #fff;
        }
        .filter-button.active { background: rgba(60, 125, 255, 0.18); }
        .filter-button-badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-width: 17px;
          height: 17px;
          padding: 0 5px;
          border-radius: 9px;
          background: #3C7DFF;
          color: #fff;
          font-size: 0.72em;
          font-weight: 700;
        }
        /* ── Filter drawer (right side) ── */
        .filter-backdrop {
          position: absolute;
          inset: 0;
          background: rgba(0, 0, 0, 0.3);
          z-index: 20;
        }
        .filter-drawer {
          position: absolute;
          top: 0;
          right: 0;
          bottom: 0;
          width: 290px;
          max-width: 85%;
          z-index: 21;
          background: #161616;
          border-left: 1px solid rgba(255, 255, 255, 0.12);
          box-shadow: -8px 0 24px rgba(0, 0, 0, 0.45);
          display: flex;
          flex-direction: column;
          animation: filter-drawer-in 0.16s ease-out;
        }
        @keyframes filter-drawer-in {
          from { transform: translateX(12px); opacity: 0.4; }
          to { transform: translateX(0); opacity: 1; }
        }
        .filter-drawer-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 12px 14px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .filter-drawer-title {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          color: #fff;
          font-weight: 600;
          font-size: 0.95em;
        }
        .filter-drawer-close {
          background: none;
          border: none;
          color: rgba(255, 255, 255, 0.6);
          cursor: pointer;
          padding: 2px;
          display: inline-flex;
        }
        .filter-drawer-close:hover { color: #fff; }
        .filter-drawer-body {
          flex: 1;
          overflow-y: auto;
          padding: 14px;
          display: flex;
          flex-direction: column;
          gap: 18px;
        }
        .filter-section { display: flex; flex-direction: column; gap: 8px; }
        .filter-label {
          color: rgba(255, 255, 255, 0.45);
          text-transform: uppercase;
          letter-spacing: 0.05em;
          font-size: 0.72em;
          font-weight: 600;
        }
        .filter-chips { display: flex; flex-wrap: wrap; gap: 6px; }
        .filter-chip {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          padding: 4px 10px;
          border-radius: 14px;
          background: rgba(255, 255, 255, 0.06);
          border: 1px solid rgba(255, 255, 255, 0.1);
          color: rgba(255, 255, 255, 0.8);
          cursor: pointer;
          font: inherit;
          font-size: 0.82em;
          transition: all 0.15s;
        }
        .filter-chip:hover { color: #fff; }
        .filter-chip.active {
          background: rgba(60, 125, 255, 0.22);
          border-color: #3C7DFF;
          color: #fff;
        }
        .filter-row-toggle {
          display: flex;
          align-items: center;
          gap: 9px;
          padding: 7px 8px;
          border-radius: 6px;
          background: none;
          border: 1px solid transparent;
          color: rgba(255, 255, 255, 0.8);
          cursor: pointer;
          font: inherit;
          font-size: 0.85em;
          text-align: left;
          width: 100%;
        }
        .filter-row-toggle:hover { background: rgba(255, 255, 255, 0.05); }
        .filter-row-toggle.active { color: #fff; }
        .filter-checkbox {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 16px;
          height: 16px;
          border-radius: 4px;
          border: 1px solid rgba(255, 255, 255, 0.25);
          flex-shrink: 0;
        }
        .filter-row-toggle.active .filter-checkbox {
          background: #3C7DFF;
          border-color: #3C7DFF;
          color: #fff;
        }
        .filter-drawer-footer {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 14px;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
        }
        .filter-hint { color: rgba(255, 255, 255, 0.45); font-size: 0.8em; }
        .delivery-count { display: inline-flex; align-items: center; gap: 2px; }
        /* ── Per-row delivery summary (provider chips) ── */
        .delivery-summary {
          display: inline-flex;
          flex-wrap: wrap;
          gap: 4px;
          margin-left: 8px;
          vertical-align: middle;
        }
        .delivery-chip {
          display: inline-flex;
          align-items: center;
          gap: 3px;
          padding: 1px 6px;
          border-radius: 9px;
          font-size: 0.72em;
          font-weight: 600;
          line-height: 1.5;
          color: var(--chip, #9aa0a6);
          background: color-mix(in srgb, var(--chip, #9aa0a6) 16%, transparent);
          border: 1px solid
            color-mix(in srgb, var(--chip, #9aa0a6) 38%, transparent);
        }
        .delivery-chip-name { letter-spacing: 0.02em; }
        /* ── Detail modal tabs ── */
        .detail-tabs {
          display: flex;
          gap: 4px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
          margin-bottom: 12px;
        }
        .detail-tab {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          background: none;
          border: none;
          border-bottom: 2px solid transparent;
          color: rgba(255, 255, 255, 0.6);
          padding: 8px 14px;
          cursor: pointer;
          font-size: 0.9em;
          transition: color 0.15s, border-color 0.15s;
        }
        .detail-tab:hover { color: rgba(255, 255, 255, 0.9); }
        .detail-tab.active {
          color: #fff;
          border-bottom-color: #3C7DFF;
        }
        .tab-count {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-width: 18px;
          height: 18px;
          padding: 0 5px;
          border-radius: 9px;
          background: rgba(255, 255, 255, 0.12);
          color: #fff;
          font-size: 0.75em;
        }
        .tab-count-error { background: #e3342f; }
        .tab-count-warning { background: #d6a700; color: #1a1a1a; }
        /* Fills the modal below the tabs so the payload viewer can grow. */
        .detail-tab-body {
          flex: 1;
          min-height: 0;
          display: flex;
          flex-direction: column;
        }
        /* Flow: the JSON viewer is the single scroll region — a scroll container
           here would break the flex height chain the viewer depends on. */
        .detail-tab-body-flow {
          overflow: hidden;
        }
        /* Validation: content is a plain list, so this tab scrolls itself. */
        .detail-tab-body-validation {
          overflow-y: auto;
        }
        /* ── Flow tab: node graph (source → providers) ── */
        /* Column that lets the payload viewer below the graph grow to fill. */
        .flow {
          display: flex;
          flex-direction: column;
          gap: 14px;
          flex: 1;
          min-height: 0;
        }
        .flow-graph {
          display: flex;
          align-items: center;
          gap: 0;
        }
        .flow-graph-solo { justify-content: flex-start; }
        .flow-col { display: flex; flex-direction: column; }
        .flow-col-source { flex: 0 0 auto; }
        .flow-col-wire { flex: 0 0 auto; }
        .flow-col-providers {
          flex: 1 1 auto;
          gap: 8px; /* == FLOW_NODE_GAP */
          min-width: 0;
        }
        .flow-wire { display: block; }
        .flow-node {
          display: flex;
          flex-direction: column;
          justify-content: center;
          text-align: left;
          background: rgba(255, 255, 255, 0.04);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          color: #e6e6e6;
          padding: 8px 12px;
          cursor: pointer;
          font: inherit;
          transition: background 0.15s, border-color 0.15s, box-shadow 0.15s;
        }
        .flow-node:hover { background: rgba(255, 255, 255, 0.07); }
        .flow-node.active {
          border-color: rgba(60, 125, 255, 0.7);
          background: rgba(60, 125, 255, 0.12);
          box-shadow: 0 0 0 1px rgba(60, 125, 255, 0.4);
        }
        .flow-node-source {
          width: 210px;
          gap: 3px;
          padding: 11px 14px;
          border-left: 3px solid rgba(60, 125, 255, 0.7);
        }
        .flow-node-kind {
          color: rgba(255, 255, 255, 0.4);
          font-size: 0.66em;
          font-weight: 600;
          text-transform: uppercase;
          letter-spacing: 0.08em;
        }
        .flow-node-name {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          color: #fff;
          font-size: 0.92em;
          font-weight: 600;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
        .flow-node-sub { color: rgba(255, 255, 255, 0.5); font-size: 0.76em; }
        /* Per-status delivery summary on the source node */
        .flow-summary {
          display: flex;
          flex-wrap: wrap;
          gap: 4px 10px;
          margin-top: 6px;
        }
        .flow-summary-item {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          color: rgba(255, 255, 255, 0.7);
          font-size: 0.72em;
          font-weight: 600;
        }
        .flow-summary-dot {
          width: 7px;
          height: 7px;
          border-radius: 50%;
        }
        /* Provider node: single table-like row, status right-aligned */
        .flow-node-provider {
          flex-direction: row;
          align-items: center;
          gap: 9px;
          height: 42px; /* == FLOW_NODE_H */
          padding: 0 14px;
          box-sizing: border-box;
        }
        .flow-node-provider.active { border-color: var(--accent, #3C7DFF); }
        .flow-node-provider .flow-node-name { flex: 0 1 auto; }
        .flow-node-dot {
          flex: 0 0 auto;
          width: 9px;
          height: 9px;
          border-radius: 50%;
          box-shadow: 0 0 0 3px color-mix(in srgb, var(--accent, #9aa0a6) 22%, transparent);
        }
        .flow-node-status {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          margin-left: auto; /* push status + duration to the right edge */
          padding-left: 10px;
          white-space: nowrap;
          font-size: 0.76em;
          font-weight: 600;
        }
        /* ── Flow tab: selected-node detail panel ── */
        .flow-detail {
          border-top: 1px solid rgba(255, 255, 255, 0.08);
          padding-top: 12px;
          flex: 1;
          min-height: 0;
          display: flex;
          flex-direction: column;
        }
        .flow-detail-head {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 10px;
          flex-wrap: wrap;
          margin-bottom: 8px;
        }
        .flow-detail-title {
          color: #fff;
          font-size: 0.86em;
          font-weight: 600;
        }
        .flow-detail-meta {
          display: inline-flex;
          align-items: center;
          gap: 10px;
          color: rgba(255, 255, 255, 0.5);
          font-size: 0.8em;
        }
        .flow-detail-status {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          font-weight: 600;
        }
        .flow-detail-error {
          color: #e3342f;
          font-size: 0.82em;
          margin-bottom: 8px;
        }
        .flow-detail-note {
          color: rgba(255, 255, 255, 0.6);
          background: rgba(154, 160, 166, 0.12);
          border-left: 3px solid #9aa0a6;
          border-radius: 4px;
          font-size: 0.82em;
          line-height: 1.45;
          padding: 8px 10px;
          margin-bottom: 8px;
        }
        .flow-detail-view {
          flex: 1;
          min-height: 200px;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          overflow: hidden;
          /* Anchor for the absolutely-filled viewer below. */
          position: relative;
        }
        /* RawDataHelper's viewer uses height:100%, which doesn't resolve through
           a flex chain capped by max-height — so it grows and gets clipped with
           no scroll. Fill the box by absolute positioning instead, so the pre's
           own overflow:auto scrolls. */
        .flow-detail-view > .raw-data-wrapper {
          position: absolute;
          inset: 0;
          height: auto;
        }
        .delivery-empty {
          color: rgba(255, 255, 255, 0.5);
          line-height: 1.5;
          padding: 12px 4px;
        }
        /* ── View segmented tabs (Analytics | Events) ── */
        .view-tabs {
          display: flex;
          gap: 2px;
          padding: 8px 12px 0;
          background: rgba(255, 255, 255, 0.02);
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .view-tab {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 8px 16px;
          background: none;
          border: none;
          border-bottom: 2px solid transparent;
          color: rgba(255, 255, 255, 0.55);
          cursor: pointer;
          font: inherit;
          font-size: 0.92em;
          transition: color 0.15s, border-color 0.15s;
        }
        .view-tab:hover { color: rgba(255, 255, 255, 0.9); }
        .view-tab.active { color: #fff; border-bottom-color: #3C7DFF; }
        .view-tab-count {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-width: 18px;
          height: 18px;
          padding: 0 5px;
          border-radius: 9px;
          background: rgba(255, 255, 255, 0.1);
          font-size: 0.72em;
          font-weight: 600;
        }
        .view-tab.active .view-tab-count { background: rgba(60, 125, 255, 0.3); color: #fff; }
        .event-num {
          font-family: 'SF Mono', monospace;
          font-size: 0.85em;
          color: rgba(255, 255, 255, 0.85);
          white-space: nowrap;
        }
        .event-muted { color: rgba(255, 255, 255, 0.3); }
        .events-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          gap: 12px;
          flex-wrap: wrap;
          padding: 12px 20px;
          background: rgba(255, 255, 255, 0.02);
          border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        .events-stats {
          display: flex;
          gap: 20px;
          align-items: center;
        }
        .event-stat {
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .event-stat-value {
          font-weight: 600;
          color: #3C7DFF;
        }
        .event-stat-label {
          color: rgba(255, 255, 255, 0.6);
          font-size: 0.9em;
        }
        .events-controls {
          display: flex;
          gap: 12px;
          align-items: center;
          flex-wrap: wrap;
          justify-content: flex-end;
        }
        .toggle-internal {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 6px 12px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 6px;
          color: rgba(255, 255, 255, 0.8);
          cursor: pointer;
          transition: all 0.2s ease;
        }
        .toggle-internal:hover {
          background: rgba(255, 255, 255, 0.1);
        }
        .toggle-internal.active {
          background: rgba(60, 125, 255, 0.2);
          border-color: #3C7DFF;
        }
        .recording-status {
          display: flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          background: ${this.isRecording ? "rgba(239, 68, 68, 0.2)" : "rgba(255, 255, 255, 0.05)"};
          border: 1px solid ${this.isRecording ? "#EF4444" : "rgba(255, 255, 255, 0.1)"};
          border-radius: 6px;
          color: ${this.isRecording ? "#EF4444" : "rgba(255, 255, 255, 0.6)"};
        }
        .recording-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: currentColor;
          ${this.isRecording ? "animation: pulse 1.5s infinite;" : ""}
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
        .events-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 0.9em;
        }
        .events-table th {
          /* Opaque background is required: a translucent sticky header lets the
             scrolled rows bleed through and looks like it overlaps the data. */
          background: #1e1e1e;
          padding: 10px;
          text-align: left;
          border-bottom: 2px solid rgba(255, 255, 255, 0.1);
          font-weight: 600;
          color: rgba(255, 255, 255, 0.8);
          position: sticky;
          top: 0;
          z-index: 10;
        }
        .events-table td {
          padding: 10px;
          border-bottom: 1px solid rgba(255, 255, 255, 0.05);
          color: rgba(255, 255, 255, 0.7);
        }
        .events-table tr:hover {
          background: rgba(255, 255, 255, 0.02);
        }
        .event-type-badge {
          display: inline-block;
          padding: 2px 8px;
          border-radius: 4px;
          font-size: 0.75em;
          font-weight: 600;
          text-transform: uppercase;
        }
        .event-name {
          font-weight: 500;
          color: rgba(255, 255, 255, 0.9);
        }
        .event-source {
          font-size: 0.85em;
          color: rgba(255, 255, 255, 0.5);
        }
        .event-time {
          font-family: 'SF Mono', monospace;
          font-size: 0.85em;
          color: rgba(255, 255, 255, 0.5);
        }
        .event-row {
          cursor: pointer;
          transition: background 0.2s;
        }
        .event-row:hover {
          background: rgba(255, 255, 255, 0.02);
        }
        .internal-badge {
          display: inline-block;
          padding: 1px 6px;
          background: rgba(156, 39, 176, 0.2);
          color: #9C27B0;
          border-radius: 3px;
          font-size: 0.7em;
          font-weight: 600;
          margin-left: 6px;
        }
        .empty-state {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          height: 300px;
          color: rgba(255, 255, 255, 0.4);
        }
        .empty-state-icon {
          font-size: 48px;
          margin-bottom: 16px;
        }
        .empty-state .filter-clear { margin-top: 12px; }
        .empty-state-text {
          font-size: 1.1em;
        }
        .empty-state-sub {
          font-size: 0.9em;
          color: rgba(255, 255, 255, 0.5);
          margin-top: 6px;
        }
        .empty-state code {
          font-family: 'SF Mono', monospace;
          background: rgba(255, 255, 255, 0.1);
          padding: 1px 5px;
          border-radius: 4px;
        }
        .validation-badge {
          display: inline-block;
          padding: 1px 6px;
          border-radius: 3px;
          font-size: 0.7em;
          font-weight: 700;
          margin-left: 6px;
        }
        .validation-badge-error { background: rgba(244, 67, 54, 0.2); color: #f44336; }
        .validation-badge-warning { background: rgba(255, 152, 0, 0.2); color: #ff9800; }
        .event-validation {
          border-radius: 8px;
          padding: 12px 14px;
          margin-bottom: 16px;
          font-size: 0.9em;
        }
        .event-validation-ok {
          background: rgba(76, 175, 80, 0.12);
          color: #81c784;
          border: 1px solid rgba(76, 175, 80, 0.3);
        }
        .event-validation-warn {
          background: rgba(255, 152, 0, 0.1);
          border: 1px solid rgba(255, 152, 0, 0.3);
        }
        .event-validation-fail {
          background: rgba(244, 67, 54, 0.1);
          border: 1px solid rgba(244, 67, 54, 0.3);
        }
        .event-validation-summary {
          display: flex;
          align-items: center;
          gap: 8px;
          font-weight: 700;
          margin-bottom: 10px;
        }
        .event-validation-ok .event-validation-summary { color: #81c784; }
        .event-validation-warn .event-validation-summary { color: #ffb74d; }
        .event-validation-fail .event-validation-summary { color: #ef5350; }
        .event-check-list { list-style: none; margin: 0; padding: 0; }
        .event-check {
          display: flex;
          gap: 8px;
          align-items: flex-start;
          padding: 6px 0;
          border-top: 1px solid rgba(255, 255, 255, 0.06);
        }
        .event-check:first-child { border-top: none; }
        .event-check-status { flex: 0 0 auto; line-height: 1; margin-top: 1px; }
        .event-check-pass .event-check-status { color: #66bb6a; }
        .event-check-warning .event-check-status { color: #ffa726; }
        .event-check-error .event-check-status { color: #ef5350; }
        .event-check-skipped { opacity: 0.55; }
        .event-check-skipped .event-check-status { color: rgba(255, 255, 255, 0.5); }
        .event-check-body { flex: 1 1 auto; min-width: 0; }
        .event-check-head {
          display: flex;
          gap: 8px;
          align-items: baseline;
          flex-wrap: wrap;
        }
        .event-check-label { font-weight: 600; color: rgba(255, 255, 255, 0.92); }
        .event-check-field {
          color: #4fc3f7;
          font-family: 'SF Mono', monospace;
          font-size: 0.85em;
          white-space: nowrap;
        }
        .event-check-detail {
          color: rgba(255, 255, 255, 0.7);
          font-size: 0.88em;
          margin-top: 2px;
        }
      </style>
      
      <div class="events-table-container">
        ${this.renderViewTabs()}
        ${this.view === "analytics" ? this.renderProviderStrip() : ""}
        <div class="events-header">
          <div class="events-stats">
            <div class="event-stat">
              <span class="event-stat-value">${filteredEvents.length}</span>
              <span class="event-stat-label">${this.view === "analytics" ? "dl_ events" : "Events"}</span>
            </div>
            ${this.view === "analytics" ? `
              <div class="event-stat">
                <span class="event-stat-value" style="color: ${invalidCount > 0 ? "#f44336" : "inherit"};">${invalidCount}</span>
                <span class="event-stat-label">Invalid</span>
              </div>
            ` : `
              <div class="event-stat">
                <span class="event-stat-value">${this.events.length}</span>
                <span class="event-stat-label">Total captured</span>
              </div>
            `}
          </div>

          <div class="events-controls">
            <button class="filter-button ${this.activeFilterCount() > 0 ? "active" : ""} ${this.filterDrawerOpen ? "open" : ""}"
                    title="Filters"
                    onclick="window.eventTimelinePanel_toggleDrawer()">
              ${lucide("filter", { size: 15 })}
              <span>Filters</span>
              ${this.activeFilterCount() > 0 ? `<span class="filter-button-badge">${this.activeFilterCount()}</span>` : ""}
            </button>

            <div class="recording-status">
              <span class="recording-dot"></span>
              <span>${this.isRecording ? "Recording" : "Paused"}</span>
            </div>
          </div>
        </div>

        ${filteredEvents.length === 0 ? this.renderEmptyState() : `
          <div style="flex: 1; overflow-y: auto;">
            <table class="events-table">
              ${this.renderTableHead()}
              <tbody>
                ${filteredEvents.slice(0, 100).map((event) => this.renderEventRow(event)).join("")}
              </tbody>
            </table>
          </div>
        `}
        ${this.renderFilterDrawer()}
      </div>
      ${modalHtml}
    `;
  }
  getActions() {
    return [
      {
        label: this.isRecording ? "Pause" : "Resume",
        variant: this.isRecording ? "secondary" : "primary",
        action: () => {
          this.isRecording = !this.isRecording;
        }
      },
      {
        label: "Clear Events",
        variant: "danger",
        action: () => {
          this.events = [];
          localStorage.removeItem(_EventTimelinePanel.EVENTS_STORAGE_KEY);
          analyticsDebug.clear();
        }
      },
      {
        label: "Export Events",
        variant: "primary",
        action: () => {
          const dataStr = JSON.stringify(this.events, null, 2);
          const dataBlob = new Blob([dataStr], { type: "application/json" });
          const url = URL.createObjectURL(dataBlob);
          const link = document.createElement("a");
          link.href = url;
          link.download = `events-${Date.now()}.json`;
          link.click();
          URL.revokeObjectURL(url);
        }
      }
    ];
  }
};
_EventTimelinePanel.EVENTS_STORAGE_KEY = "debug-events-history";
_EventTimelinePanel.SHOW_INTERNAL_KEY = "debug-events-show-internal";
_EventTimelinePanel.VIEW_KEY = "debug-events-view";
_EventTimelinePanel.MAX_STORED_EVENTS = 100;
_EventTimelinePanel.STORAGE_EXPIRY_KEY = "debug-events-expiry";
_EventTimelinePanel.STORAGE_EXPIRY_HOURS = 2;
_EventTimelinePanel.instance = null;
_EventTimelinePanel.CHECK_ICON = {
  pass: "check-circle",
  warning: "alert",
  error: "x-circle",
  skipped: "minus-circle"
};
let EventTimelinePanel = _EventTimelinePanel;
class ConfigPanel {
  constructor() {
    this.id = "config";
    this.title = "Configuration";
    this.icon = lucide("settings");
  }
  getContent() {
    const tabs = this.getTabs();
    return tabs[0]?.getContent() || "";
  }
  getTabs() {
    return [
      {
        id: "overview",
        label: "Overview",
        icon: "📊",
        getContent: () => this.getOverviewContent()
      },
      {
        id: "settings",
        label: "Settings",
        icon: "⚙️",
        getContent: () => this.getSettingsContent()
      },
      {
        id: "raw",
        label: "Raw Data",
        icon: "🔧",
        getContent: () => this.getRawDataContent()
      }
    ];
  }
  getOverviewContent() {
    const config = configStore.getState();
    const sdkVersion = typeof window !== "undefined" && window.__NEXT_SDK_VERSION__ ? window.__NEXT_SDK_VERSION__ : "1.0.0";
    return `
      <div class="enhanced-panel">
        <div class="metrics-grid">
          <div class="metric-card">
            <div class="metric-icon">🔧</div>
            <div class="metric-content">
              <div class="metric-value">${config.debug ? "ON" : "OFF"}</div>
              <div class="metric-label">Debug Mode</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🌍</div>
            <div class="metric-content">
              <div class="metric-value">${config.environment || "production"}</div>
              <div class="metric-label">Environment</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🔑</div>
            <div class="metric-content">
              <div class="metric-value">${config.apiKey ? "SET" : "MISSING"}</div>
              <div class="metric-label">API Key</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">📦</div>
            <div class="metric-content">
              <div class="metric-value">${sdkVersion}</div>
              <div class="metric-label">SDK Version</div>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  getSettingsContent() {
    const config = configStore.getState();
    const sdkVersion = typeof window !== "undefined" && window.__NEXT_SDK_VERSION__ ? window.__NEXT_SDK_VERSION__ : "1.0.0";
    return `
      <div class="enhanced-panel">
        <div class="section">
          <div class="config-groups">
            <div class="config-group">
              <h4 class="config-group-title">Core Settings</h4>
              <div class="config-items">
                <div class="config-item">
                  <span class="config-key">SDK Version:</span>
                  <span class="config-value">${sdkVersion}</span>
                </div>
                <div class="config-item">
                  <span class="config-key">API Key:</span>
                  <span class="config-value">${config.apiKey ? `${config.apiKey.substring(0, 8)}...` : "Not set"}</span>
                </div>
                <div class="config-item">
                  <span class="config-key">Environment:</span>
                  <span class="config-value">${config.environment || "production"}</span>
                </div>
                <div class="config-item">
                  <span class="config-key">Base URL:</span>
                  <span class="config-value">https://campaigns.apps.29next.com</span>
                </div>
              </div>
            </div>

            <div class="config-group">
              <h4 class="config-group-title">Feature Flags</h4>
              <div class="config-items">
                <div class="config-item">
                  <span class="config-key">Debug Mode:</span>
                  <span class="config-value ${config.debug ? "enabled" : "disabled"}">${config.debug ? "Enabled" : "Disabled"}</span>
                </div>
                <div class="config-item">
                  <span class="config-key">Test Mode:</span>
                  <span class="config-value ${config.testMode ?? false ? "enabled" : "disabled"}">${config.testMode ?? false ? "Enabled" : "Disabled"}</span>
                </div>
                <div class="config-item">
                  <span class="config-key">Analytics:</span>
                  <span class="config-value ${config.enableAnalytics ?? true ? "enabled" : "disabled"}">${config.enableAnalytics ?? true ? "Enabled" : "Disabled"}</span>
                </div>
                <div class="config-item">
                  <span class="config-key">Auto Initialize:</span>
                  <span class="config-value ${config.autoInit ?? true ? "enabled" : "disabled"}">${config.autoInit ?? true ? "Enabled" : "Disabled"}</span>
                </div>
              </div>
            </div>

            <div class="config-group">
              <h4 class="config-group-title">Performance</h4>
              <div class="config-items">
                <div class="config-item">
                  <span class="config-key">Rate Limit:</span>
                  <span class="config-value">${config.rateLimit ?? 4} req/sec</span>
                </div>
                <div class="config-item">
                  <span class="config-key">Cache TTL:</span>
                  <span class="config-value">${config.cacheTtl ?? 300}s</span>
                </div>
                <div class="config-item">
                  <span class="config-key">Retry Attempts:</span>
                  <span class="config-value">${config.retryAttempts ?? 3}</span>
                </div>
                <div class="config-item">
                  <span class="config-key">Timeout:</span>
                  <span class="config-value">${config.timeout ?? 1e4}ms</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  getRawDataContent() {
    const config = configStore.getState();
    return RawDataHelper.generateRawDataContent(config);
  }
  getActions() {
    return [
      {
        label: "Toggle Debug",
        action: () => this.toggleDebug(),
        variant: "primary"
      },
      {
        label: "Toggle Test Mode",
        action: () => this.toggleTestMode(),
        variant: "secondary"
      },
      {
        label: "Export Config",
        action: () => this.exportConfig(),
        variant: "secondary"
      },
      {
        label: "Reset Config",
        action: () => this.resetConfig(),
        variant: "danger"
      }
    ];
  }
  toggleDebug() {
    const configStore$1 = configStore.getState();
    configStore$1.updateConfig({ debug: !configStore$1.debug });
    document.dispatchEvent(new CustomEvent("debug:update-content"));
  }
  toggleTestMode() {
    const configStore$1 = configStore.getState();
    configStore$1.updateConfig({ testMode: !(configStore$1.testMode ?? false) });
    document.dispatchEvent(new CustomEvent("debug:update-content"));
  }
  exportConfig() {
    const config = configStore.getState();
    const data = JSON.stringify(config, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `next-config-${(/* @__PURE__ */ new Date()).toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
  resetConfig() {
    if (confirm("Are you sure you want to reset the configuration to defaults?")) {
      const configStore$1 = configStore.getState();
      configStore$1.reset();
      document.dispatchEvent(new CustomEvent("debug:update-content"));
    }
  }
}
class CheckoutPanel {
  constructor() {
    this.id = "checkout";
    this.title = "Checkout State";
    this.icon = lucide("card");
  }
  getContent() {
    const tabs = this.getTabs();
    return tabs[0]?.getContent() || "";
  }
  getTabs() {
    return [
      {
        id: "overview",
        label: "Overview",
        icon: "📊",
        getContent: () => this.getOverviewContent()
      },
      {
        id: "customer",
        label: "Customer Info",
        icon: "👤",
        getContent: () => this.getCustomerContent()
      },
      {
        id: "validation",
        label: "Validation",
        icon: "✅",
        getContent: () => this.getValidationContent()
      },
      {
        id: "raw",
        label: "Raw Data",
        icon: "🔧",
        getContent: () => this.getRawDataContent()
      }
    ];
  }
  getOverviewContent() {
    const checkoutState = useCheckoutStore.getState();
    return `
      <div class="enhanced-panel">
        <div class="metrics-grid">
          <div class="metric-card">
            <div class="metric-icon">📋</div>
            <div class="metric-content">
              <div class="metric-value">${checkoutState.step || "Not Started"}</div>
              <div class="metric-label">Current Step</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">${checkoutState.isProcessing ? "⏳" : "✅"}</div>
            <div class="metric-content">
              <div class="metric-value">${checkoutState.isProcessing ? "PROCESSING" : "READY"}</div>
              <div class="metric-label">Form Status</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🔒</div>
            <div class="metric-content">
              <div class="metric-value">${checkoutState.paymentMethod || "None"}</div>
              <div class="metric-label">Payment Method</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🚚</div>
            <div class="metric-content">
              <div class="metric-value">${checkoutState.shippingMethod?.name || "None"}</div>
              <div class="metric-label">Shipping Method</div>
            </div>
          </div>
        </div>

        <div class="section">
          <h3 class="section-title">Form Fields Status</h3>
          <div class="form-fields-grid">
            ${this.renderFormFields(checkoutState)}
          </div>
        </div>
        
        <div class="section">
          <h3 class="section-title">Current Form Data</h3>
          <div class="form-data-summary">
            ${Object.keys(checkoutState.formData).length > 0 ? Object.entries(checkoutState.formData).map(([key, value]) => `
                <div class="form-field-row">
                  <span class="field-name">${this.formatFieldName(key)}</span>
                  <span class="field-value">${value || "Empty"}</span>
                </div>
              `).join("") : '<div class="empty-state">No form data yet</div>'}
          </div>
        </div>
      </div>
    `;
  }
  getCustomerContent() {
    const checkoutState = useCheckoutStore.getState();
    const formData = checkoutState.formData;
    const hasFormData = Object.keys(formData).length > 0;
    return `
      <div class="enhanced-panel">
        <div class="section">
          <div class="customer-info">
            ${hasFormData ? `
              <div class="info-card">
                <h4>Contact Information</h4>
                <div class="info-row">
                  <span class="info-label">Email:</span>
                  <span class="info-value">${formData.email || "Not provided"}</span>
                </div>
                <div class="info-row">
                  <span class="info-label">Phone:</span>
                  <span class="info-value">${formData.phone || "Not provided"}</span>
                </div>
                <div class="info-row">
                  <span class="info-label">Name:</span>
                  <span class="info-value">${formData.fname || ""} ${formData.lname || ""}</span>
                </div>
              </div>
              
              <div class="info-card">
                <h4>Shipping Address</h4>
                <div class="address-info">
                  ${formData.address1 ? `
                    <div class="info-row">
                      <span class="info-label">Address:</span>
                      <span class="info-value">${formData.address1}</span>
                    </div>
                    ${formData.address2 ? `
                      <div class="info-row">
                        <span class="info-label">Address 2:</span>
                        <span class="info-value">${formData.address2}</span>
                      </div>
                    ` : ""}
                    <div class="info-row">
                      <span class="info-label">City:</span>
                      <span class="info-value">${formData.city || "Not provided"}</span>
                    </div>
                    <div class="info-row">
                      <span class="info-label">State/Province:</span>
                      <span class="info-value">${formData.province || "Not provided"}</span>
                    </div>
                    <div class="info-row">
                      <span class="info-label">Postal Code:</span>
                      <span class="info-value">${formData.postal || "Not provided"}</span>
                    </div>
                    <div class="info-row">
                      <span class="info-label">Country:</span>
                      <span class="info-value">${formData.country || "Not provided"}</span>
                    </div>
                  ` : '<div class="info-empty">Not provided</div>'}
                </div>
              </div>

              <div class="info-card">
                <h4>Billing Address</h4>
                <div class="address-info">
                  ${checkoutState.sameAsShipping ? `
                    <div class="info-same">Same as shipping address</div>
                  ` : checkoutState.billingAddress ? `
                    <div class="info-row">
                      <span class="info-label">Name:</span>
                      <span class="info-value">${checkoutState.billingAddress.first_name} ${checkoutState.billingAddress.last_name}</span>
                    </div>
                    <div class="info-row">
                      <span class="info-label">Address:</span>
                      <span class="info-value">${checkoutState.billingAddress.address1}</span>
                    </div>
                    <div class="info-row">
                      <span class="info-label">City:</span>
                      <span class="info-value">${checkoutState.billingAddress.city}, ${checkoutState.billingAddress.province} ${checkoutState.billingAddress.postal}</span>
                    </div>
                  ` : '<div class="info-empty">Not provided</div>'}
                </div>
              </div>
            ` : `
              <div class="empty-state">
                <div class="empty-icon">👤</div>
                <div class="empty-text">No customer information yet</div>
                <div class="empty-subtitle">Fill out the checkout form to see data here</div>
              </div>
            `}
          </div>
        </div>
      </div>
    `;
  }
  getValidationContent() {
    const checkoutState = useCheckoutStore.getState();
    return `
      <div class="enhanced-panel">
        <div class="section">
          <div class="validation-errors">
            ${checkoutState.errors && Object.keys(checkoutState.errors).length > 0 ? `
              ${Object.entries(checkoutState.errors).map(([field, error]) => `
                <div class="error-item">
                  <span class="error-field">${field}:</span>
                  <span class="error-message">${error}</span>
                </div>
              `).join("")}
            ` : `
              <div class="empty-state">
                <div class="empty-icon">✅</div>
                <div class="empty-text">No validation errors</div>
              </div>
            `}
          </div>
        </div>
      </div>
    `;
  }
  getRawDataContent() {
    const checkoutState = useCheckoutStore.getState();
    return RawDataHelper.generateRawDataContent(checkoutState);
  }
  getActions() {
    return [
      {
        label: "Fill Test Data",
        action: () => this.fillTestData(),
        variant: "primary"
      },
      {
        label: "Validate Form",
        action: () => this.validateForm(),
        variant: "secondary"
      },
      {
        label: "Clear Errors",
        action: () => this.clearErrors(),
        variant: "secondary"
      },
      {
        label: "Reset Checkout",
        action: () => this.resetCheckout(),
        variant: "danger"
      },
      {
        label: "Export State",
        action: () => this.exportState(),
        variant: "secondary"
      }
    ];
  }
  renderFormFields(checkoutState) {
    const requiredFields = [
      "email",
      "fname",
      "lname",
      "address1",
      "city",
      "province",
      "postal",
      "phone",
      "country"
    ];
    return requiredFields.map((field) => {
      const hasValue = this.hasFieldValue(checkoutState, field);
      const hasError = checkoutState.errors && checkoutState.errors[field];
      return `
        <div class="field-status-card ${hasValue ? "filled" : "empty"} ${hasError ? "error" : ""}">
          <div class="field-name">${this.formatFieldName(field)}</div>
          <div class="field-status">
            ${hasValue ? "✅" : "⏳"}
            ${hasError ? " ❌" : ""}
          </div>
        </div>
      `;
    }).join("");
  }
  hasFieldValue(checkoutState, field) {
    if (checkoutState.formData && checkoutState.formData[field]) {
      return checkoutState.formData[field].toString().trim().length > 0;
    }
    if (checkoutState.billingAddress && checkoutState.billingAddress[field]) {
      return checkoutState.billingAddress[field].toString().trim().length > 0;
    }
    return false;
  }
  formatFieldName(field) {
    const fieldNames = {
      fname: "First Name",
      lname: "Last Name",
      email: "Email",
      phone: "Phone",
      address1: "Address",
      address2: "Address 2",
      city: "City",
      province: "State/Province",
      postal: "Postal Code",
      country: "Country",
      accepts_marketing: "Accepts Marketing"
    };
    return fieldNames[field] || field.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase()).trim();
  }
  fillTestData() {
    const checkoutStore = useCheckoutStore.getState();
    const testFormData = {
      email: "test@test.com",
      fname: "Test",
      lname: "Order",
      phone: "+14807581224",
      address1: "Test Address 123",
      address2: "",
      city: "Tempe",
      province: "AZ",
      postal: "85281",
      country: "US",
      accepts_marketing: true
    };
    checkoutStore.clearAllErrors();
    checkoutStore.updateFormData(testFormData);
    checkoutStore.setPaymentMethod("credit-card");
    checkoutStore.setSameAsShipping(true);
    checkoutStore.setShippingMethod({
      id: 1,
      name: "Standard Shipping",
      price: 0,
      code: "standard"
    });
    console.log("✅ Test data filled successfully");
    document.dispatchEvent(new CustomEvent("debug:update-content"));
    setTimeout(() => {
      document.dispatchEvent(new CustomEvent("checkout:test-data-filled", {
        detail: testFormData
      }));
    }, 100);
  }
  validateForm() {
    const checkoutStore = useCheckoutStore.getState();
    const formData = checkoutStore.formData;
    const requiredFields = ["email", "fname", "lname", "address1", "city", "country"];
    let hasErrors = false;
    checkoutStore.clearAllErrors();
    requiredFields.forEach((field) => {
      if (!formData[field] || formData[field].toString().trim() === "") {
        checkoutStore.setError(field, `${this.formatFieldName(field)} is required`);
        hasErrors = true;
      }
    });
    if (!hasErrors) {
      console.log("✅ Form validation passed");
    }
    document.dispatchEvent(new CustomEvent("debug:update-content"));
  }
  clearErrors() {
    const checkoutStore = useCheckoutStore.getState();
    checkoutStore.clearAllErrors();
    document.dispatchEvent(new CustomEvent("debug:update-content"));
  }
  resetCheckout() {
    if (confirm("Are you sure you want to reset the checkout state?")) {
      const checkoutStore = useCheckoutStore.getState();
      checkoutStore.reset();
      document.dispatchEvent(new CustomEvent("debug:update-content"));
    }
  }
  exportState() {
    const checkoutState = useCheckoutStore.getState();
    const data = JSON.stringify(checkoutState, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `checkout-state-${(/* @__PURE__ */ new Date()).toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
class StoragePanel {
  constructor() {
    this.id = "storage";
    this.title = "Storage";
    this.icon = lucide("database");
  }
  getContent() {
    const tabs = this.getTabs();
    return tabs[0]?.getContent() || "";
  }
  getTabs() {
    return [
      {
        id: "overview",
        label: "Overview",
        icon: "📊",
        getContent: () => this.getOverviewContent()
      },
      {
        id: "next-data",
        label: "Next Data",
        icon: "🏷️",
        getContent: () => this.getNextContent()
      },
      {
        id: "local-storage",
        label: "Local Storage",
        icon: "💾",
        getContent: () => this.getLocalStorageContent()
      },
      {
        id: "session-storage",
        label: "Session Storage",
        icon: "⏰",
        getContent: () => this.getSessionStorageContent()
      }
    ];
  }
  getOverviewContent() {
    const localStorage2 = this.getLocalStorageData();
    const sessionStorage2 = this.getSessionStorageData();
    return `
      <div class="enhanced-panel">
        <div class="metrics-grid">
          <div class="metric-card">
            <div class="metric-icon">💾</div>
            <div class="metric-content">
              <div class="metric-value">${localStorage2.length}</div>
              <div class="metric-label">LocalStorage Items</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">⏰</div>
            <div class="metric-content">
              <div class="metric-value">${sessionStorage2.length}</div>
              <div class="metric-label">SessionStorage Items</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">📊</div>
            <div class="metric-content">
              <div class="metric-value">${this.getStorageSize()}KB</div>
              <div class="metric-label">Total Size</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🏷️</div>
            <div class="metric-content">
              <div class="metric-value">${this.getNextItems().length}</div>
              <div class="metric-label">Next Items</div>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  getNextContent() {
    return `
      <div class="enhanced-panel">
        <div class="section">
          <div class="storage-items">
            ${this.getNextItems().length === 0 ? `
              <div class="empty-state">
                <div class="empty-icon">💾</div>
                <div class="empty-text">No Next storage items found</div>
              </div>
            ` : `
              ${this.getNextItems().map((item) => `
                <div class="storage-item-card next-item">
                  <div class="storage-item-header">
                    <span class="storage-key">${item.key}</span>
                    <span class="storage-type ${item.type}">${item.type}</span>
                    <button class="storage-delete-btn" onclick="window.nextDebug.deleteStorageItem('${item.key}', '${item.type}')">×</button>
                  </div>
                  <div class="storage-item-size">${item.size} bytes</div>
                  <div class="storage-item-value">
                    <pre><code>${item.formattedValue}</code></pre>
                  </div>
                </div>
              `).join("")}
            `}
          </div>
        </div>
      </div>
    `;
  }
  getLocalStorageContent() {
    const localStorage2 = this.getLocalStorageData();
    return `
      <div class="enhanced-panel">
        <div class="section">
          <div class="storage-items">
            ${localStorage2.length === 0 ? `
              <div class="empty-state">
                <div class="empty-icon">💾</div>
                <div class="empty-text">No localStorage items</div>
              </div>
            ` : `
              ${localStorage2.map((item) => `
                <div class="storage-item-card ${item.key.includes("next") ? "next-item" : ""}">
                  <div class="storage-item-header">
                    <span class="storage-key">${item.key}</span>
                    <span class="storage-type local">local</span>
                    <button class="storage-delete-btn" onclick="window.nextDebug.deleteStorageItem('${item.key}', 'local')">×</button>
                  </div>
                  <div class="storage-item-size">${item.size} bytes</div>
                  <div class="storage-item-value">
                    <pre><code>${item.formattedValue}</code></pre>
                  </div>
                </div>
              `).join("")}
            `}
          </div>
        </div>
      </div>
    `;
  }
  getSessionStorageContent() {
    const sessionStorage2 = this.getSessionStorageData();
    return `
      <div class="enhanced-panel">
        <div class="section">
          <div class="storage-items">
            ${sessionStorage2.length === 0 ? `
              <div class="empty-state">
                <div class="empty-icon">⏰</div>
                <div class="empty-text">No sessionStorage items</div>
              </div>
            ` : `
              ${sessionStorage2.map((item) => `
                <div class="storage-item-card ${item.key.includes("next") ? "next-item" : ""}">
                  <div class="storage-item-header">
                    <span class="storage-key">${item.key}</span>
                    <span class="storage-type session">session</span>
                    <button class="storage-delete-btn" onclick="window.nextDebug.deleteStorageItem('${item.key}', 'session')">×</button>
                  </div>
                  <div class="storage-item-size">${item.size} bytes</div>
                  <div class="storage-item-value">
                    <pre><code>${item.formattedValue}</code></pre>
                  </div>
                </div>
              `).join("")}
            `}
          </div>
        </div>
      </div>
    `;
  }
  getActions() {
    return [
      {
        label: "Clear Next Data",
        action: () => this.clearNextStorage(),
        variant: "danger"
      },
      {
        label: "Clear All Local",
        action: () => this.clearLocalStorage(),
        variant: "danger"
      },
      {
        label: "Clear All Session",
        action: () => this.clearSessionStorage(),
        variant: "danger"
      },
      {
        label: "Export Storage",
        action: () => this.exportStorage(),
        variant: "secondary"
      }
    ];
  }
  getLocalStorageData() {
    const items = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        const value = localStorage.getItem(key) || "";
        items.push({
          key,
          value,
          size: new Blob([value]).size,
          formattedValue: this.formatValue(value)
        });
      }
    }
    return items.sort((a, b) => a.key.localeCompare(b.key));
  }
  getSessionStorageData() {
    const items = [];
    for (let i = 0; i < sessionStorage.length; i++) {
      const key = sessionStorage.key(i);
      if (key) {
        const value = sessionStorage.getItem(key) || "";
        items.push({
          key,
          value,
          size: new Blob([value]).size,
          formattedValue: this.formatValue(value)
        });
      }
    }
    return items.sort((a, b) => a.key.localeCompare(b.key));
  }
  getNextItems() {
    const items = [];
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && (key.includes("next") || key.includes("29next") || key.includes("campaign"))) {
        const value = localStorage.getItem(key) || "";
        items.push({
          key,
          value,
          size: new Blob([value]).size,
          formattedValue: this.formatValue(value),
          type: "local"
        });
      }
    }
    for (let i = 0; i < sessionStorage.length; i++) {
      const key = sessionStorage.key(i);
      if (key && (key.includes("next") || key.includes("29next") || key.includes("campaign"))) {
        const value = sessionStorage.getItem(key) || "";
        items.push({
          key,
          value,
          size: new Blob([value]).size,
          formattedValue: this.formatValue(value),
          type: "session"
        });
      }
    }
    return items.sort((a, b) => a.key.localeCompare(b.key));
  }
  formatValue(value) {
    try {
      const parsed = JSON.parse(value);
      return JSON.stringify(parsed, null, 2);
    } catch {
      if (value.length > 200) {
        return value.substring(0, 200) + "...";
      }
      return value;
    }
  }
  getStorageSize() {
    let total = 0;
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key) {
        const value = localStorage.getItem(key) || "";
        total += new Blob([key + value]).size;
      }
    }
    for (let i = 0; i < sessionStorage.length; i++) {
      const key = sessionStorage.key(i);
      if (key) {
        const value = sessionStorage.getItem(key) || "";
        total += new Blob([key + value]).size;
      }
    }
    return Math.round(total / 1024);
  }
  clearNextStorage() {
    if (confirm("Are you sure you want to clear all Next storage data?")) {
      const nextItems = this.getNextItems();
      nextItems.forEach((item) => {
        if (item.type === "local") {
          localStorage.removeItem(item.key);
        } else {
          sessionStorage.removeItem(item.key);
        }
      });
      document.dispatchEvent(new CustomEvent("debug:update-content"));
    }
  }
  clearLocalStorage() {
    if (confirm("Are you sure you want to clear ALL localStorage data?")) {
      localStorage.clear();
      document.dispatchEvent(new CustomEvent("debug:update-content"));
    }
  }
  clearSessionStorage() {
    if (confirm("Are you sure you want to clear ALL sessionStorage data?")) {
      sessionStorage.clear();
      document.dispatchEvent(new CustomEvent("debug:update-content"));
    }
  }
  exportStorage() {
    const data = {
      localStorage: this.getLocalStorageData(),
      sessionStorage: this.getSessionStorageData(),
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `storage-data-${(/* @__PURE__ */ new Date()).toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
}
const ATTEMPT_LIMIT = 20;
class OffersPanel {
  constructor() {
    this.id = "offers";
    this.title = "Offers & Discounts";
    this.icon = lucide("tag");
    this.attempts = [];
    this.promptApplyCoupon = async () => {
      const input = window.prompt("Coupon code to apply:");
      if (!input) return;
      const code = input.trim();
      if (!code) return;
      const result = await cartOperations.applyCoupon(code);
      if (!result.success) {
        window.alert(`Coupon failed: ${result.message}`);
      }
    };
    const bus = EventBus.getInstance();
    bus.on("coupon:applied", (payload) => {
      const code = "code" in payload ? payload.code : payload.coupon.code;
      this.record({ code, result: "applied" });
    });
    bus.on("coupon:validation-failed", (payload) => {
      this.record({
        code: payload.code,
        result: "failed",
        message: payload.message
      });
    });
    bus.on("coupon:removed", (payload) => {
      this.record({ code: payload.code, result: "removed" });
    });
    useCartStore.subscribe(
      (state, prev) => {
        if (state.vouchers !== prev.vouchers || state.offerDiscounts !== prev.offerDiscounts || state.voucherDiscounts !== prev.voucherDiscounts || state.totalDiscount !== prev.totalDiscount || state.hasDiscounts !== prev.hasDiscounts) {
          this.requestRefresh();
        }
      }
    );
    useCampaignStore.subscribe((state, prev) => {
      if (state.data?.offers !== prev.data?.offers) {
        this.requestRefresh();
      }
    });
  }
  requestRefresh() {
    document.dispatchEvent(new CustomEvent("debug:update-content"));
  }
  getContent() {
    return this.getTabs()[0]?.getContent() ?? "";
  }
  getTabs() {
    return [
      {
        id: "overview",
        label: "Overview",
        icon: "📊",
        getContent: () => this.getOverviewContent()
      },
      {
        id: "offers",
        label: "Offers",
        icon: "🎁",
        getContent: () => this.getOffersContent()
      },
      {
        id: "coupons",
        label: "Coupons",
        icon: "🎟️",
        getContent: () => this.getCouponsContent()
      },
      {
        id: "raw",
        label: "Raw Data",
        icon: "🔧",
        getContent: () => this.getRawDataContent()
      }
    ];
  }
  getActions() {
    return [
      {
        label: "Apply Coupon",
        action: this.promptApplyCoupon,
        variant: "primary"
      }
    ];
  }
  record(entry) {
    this.attempts.unshift({ ...entry, timestamp: Date.now() });
    if (this.attempts.length > ATTEMPT_LIMIT) {
      this.attempts.length = ATTEMPT_LIMIT;
    }
    this.requestRefresh();
  }
  getOverviewContent() {
    const state = useCartStore.getState();
    const offerCount = state.offerDiscounts?.length ?? 0;
    const couponCount = state.vouchers.length;
    const totalDiscount = state.totalDiscount.toNumber();
    const discountPct = state.totalDiscountPercentage.toNumber();
    const breakdown = [
      ...(state.offerDiscounts ?? []).map((d) => ({ ...d, kind: "Offer" })),
      ...(state.voucherDiscounts ?? []).map((d) => ({ ...d, kind: "Coupon" }))
    ];
    return `
      <div class="enhanced-panel">
        <div class="metrics-grid">
          <div class="metric-card">
            <div class="metric-icon">💸</div>
            <div class="metric-content">
              <div class="metric-value">${formatCurrency(totalDiscount)}</div>
              <div class="metric-label">Total Discount</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">📉</div>
            <div class="metric-content">
              <div class="metric-value">${discountPct.toFixed(2)}%</div>
              <div class="metric-label">Discount %</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🎟️</div>
            <div class="metric-content">
              <div class="metric-value">${couponCount}</div>
              <div class="metric-label">Active Coupons</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🎁</div>
            <div class="metric-content">
              <div class="metric-value">${offerCount}</div>
              <div class="metric-label">Active Offers</div>
            </div>
          </div>
        </div>

        <div class="section">
          <h3 class="section-title">Discount Breakdown</h3>
          ${breakdown.length === 0 ? `
                <div class="empty-state">
                  <div class="empty-icon">🏷️</div>
                  <div class="empty-text">No discounts applied</div>
                </div>
              ` : `
                <div class="cart-items-list">
                  ${breakdown.map(
      (d) => `
                    <div class="cart-item-card">
                      <div class="item-info">
                        <div class="item-title">${escapeHtml$1(d.name ?? "(unnamed)")}</div>
                        <div class="item-details">
                          ${d.kind}${d.description ? ` • ${escapeHtml$1(d.description)}` : ""}
                        </div>
                      </div>
                      <div class="item-total">${escapeHtml$1(d.amount)}</div>
                    </div>
                  `
    ).join("")}
                </div>
              `}
        </div>
      </div>
    `;
  }
  getOffersContent() {
    const cartState = useCartStore.getState();
    const campaign = useCampaignStore.getState().data;
    const applied = cartState.offerDiscounts ?? [];
    const allOffers = campaign?.offers ?? [];
    const automaticOffers = allOffers.filter((o) => o.type === "offer");
    const appliedIds = new Set(
      applied.map((d) => d.offer_id).filter((id) => id !== void 0)
    );
    const offersByRefId = new Map(allOffers.map((o) => [o.ref_id, o]));
    const appliedSection = applied.length === 0 ? `
          <div class="empty-state">
            <div class="empty-icon">🎁</div>
            <div class="empty-text">No offers currently applied</div>
          </div>
        ` : `
          <div class="cart-items-list">
            ${applied.map((offer) => {
      const detail = offer.offer_id !== void 0 ? offersByRefId.get(offer.offer_id) : void 0;
      return `
              <div class="cart-item-card">
                <div class="item-info">
                  <div class="item-title">${escapeHtml$1(offer.name ?? "(unnamed offer)")}</div>
                  ${offer.offer_id !== void 0 ? `<div class="item-details" style="opacity: 0.65; font-size: 11px;">Offer ID: ${offer.offer_id}</div>` : ""}
                  ${detail ? `
                        <div class="item-details">
                          <strong>Condition:</strong> ${escapeHtml$1(formatCondition(detail))}
                        </div>
                        <div class="item-details">
                          <strong>Benefit:</strong> ${escapeHtml$1(formatBenefit(detail))}
                        </div>
                      ` : offer.description ? `<div class="item-details">${escapeHtml$1(offer.description)}</div>` : ""}
                </div>
                <div class="item-total">${escapeHtml$1(offer.amount)}</div>
              </div>
            `;
    }).join("")}
          </div>
        `;
    const availableSection = automaticOffers.length === 0 ? `
          <div class="empty-state">
            <div class="empty-icon">📭</div>
            <div class="empty-text">No automatic offers declared on this campaign</div>
          </div>
        ` : `
          <div class="cart-items-list">
            ${automaticOffers.map((o) => renderAvailableOffer(o, appliedIds.has(o.ref_id))).join("")}
          </div>
        `;
    return `
      <div class="enhanced-panel">
        <div class="section">
          <h3 class="section-title">Applied Offers (${applied.length})</h3>
          ${appliedSection}
        </div>
        <div class="section">
          <h3 class="section-title">Available Offers (${automaticOffers.length})</h3>
          ${availableSection}
        </div>
      </div>
    `;
  }
  getCouponsContent() {
    const state = useCartStore.getState();
    const campaign = useCampaignStore.getState().data;
    const applied = state.vouchers;
    const voucherDiscounts = state.voucherDiscounts ?? [];
    const appliedLower = new Set(applied.map((c) => c.toLowerCase()));
    const availableVouchers = (campaign?.offers ?? []).filter(
      (o) => o.type === "voucher"
    );
    const appliedSection = applied.length === 0 ? `
          <div class="empty-state">
            <div class="empty-icon">🎟️</div>
            <div class="empty-text">No coupons applied</div>
          </div>
        ` : `
          <div class="cart-items-list">
            ${applied.map((code) => {
      const match = voucherDiscounts.find(
        (d) => d.name?.toLowerCase() === code.toLowerCase()
      );
      const amount = match?.amount ?? "—";
      const detail = availableVouchers.find(
        (v) => (v.code ?? "").toLowerCase() === code.toLowerCase()
      );
      return `
                  <div class="cart-item-card">
                    <div class="item-info">
                      <div class="item-title">${escapeHtml$1(code)}</div>
                      ${detail ? `
                            <div class="item-details">
                              <strong>Condition:</strong> ${escapeHtml$1(formatCondition(detail))}
                            </div>
                            <div class="item-details">
                              <strong>Benefit:</strong> ${escapeHtml$1(formatBenefit(detail))}
                            </div>
                          ` : match?.description ? `<div class="item-details">${escapeHtml$1(match.description)}</div>` : ""}
                    </div>
                    <div class="item-total">${escapeHtml$1(amount)}</div>
                    <button
                      class="remove-btn"
                      onclick="window.__nextDebugRemoveCoupon &amp;&amp; window.__nextDebugRemoveCoupon('${escapeAttr(code)}')"
                      title="Remove ${escapeAttr(code)}">×</button>
                  </div>
                `;
    }).join("")}
          </div>
        `;
    const attemptsSection = this.attempts.length === 0 ? `
          <div class="empty-state">
            <div class="empty-icon">📜</div>
            <div class="empty-text">No coupon activity this session</div>
          </div>
        ` : `
          <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
            <thead>
              <tr style="text-align: left; opacity: 0.7;">
                <th style="padding: 6px 4px;">Time</th>
                <th style="padding: 6px 4px;">Code</th>
                <th style="padding: 6px 4px;">Result</th>
                <th style="padding: 6px 4px;">Message</th>
              </tr>
            </thead>
            <tbody>
              ${this.attempts.map(
      (a) => `
                <tr style="border-top: 1px solid rgba(255,255,255,0.08);">
                  <td style="padding: 6px 4px; opacity: 0.7;">${formatTime(a.timestamp)}</td>
                  <td style="padding: 6px 4px; font-family: monospace;">${escapeHtml$1(a.code)}</td>
                  <td style="padding: 6px 4px;">${resultBadge(a.result)}</td>
                  <td style="padding: 6px 4px; opacity: 0.85;">${escapeHtml$1(a.message ?? "")}</td>
                </tr>
              `
    ).join("")}
            </tbody>
          </table>
        `;
    const availableSection = availableVouchers.length === 0 ? `
          <div class="empty-state">
            <div class="empty-icon">📭</div>
            <div class="empty-text">No voucher codes declared on this campaign</div>
          </div>
        ` : `
          <div class="cart-items-list">
            ${availableVouchers.map((v) => {
      const code = v.code ?? "";
      const hasCode = !!code;
      const isApplied = hasCode && appliedLower.has(code.toLowerCase());
      const disabled = !hasCode || isApplied;
      const label = !hasCode ? "No code" : isApplied ? "Applied" : "Apply";
      return `
                  <div class="cart-item-card">
                    <div class="item-info">
                      <div class="item-title">
                        <code style="font-family: monospace;">${hasCode ? escapeHtml$1(code) : '<em style="opacity: 0.6;">(no code)</em>'}</code>
                        ${isApplied ? '<span style="color: #4caf50; font-size: 11px; margin-left: 8px;">● applied</span>' : ""}
                      </div>
                      <div class="item-details" style="opacity: 0.85;">${escapeHtml$1(v.name)}</div>
                      <div class="item-details">
                        <strong>Condition:</strong> ${escapeHtml$1(formatCondition(v))}
                      </div>
                      <div class="item-details">
                        <strong>Benefit:</strong> ${escapeHtml$1(formatBenefit(v))}
                      </div>
                    </div>
                    <button
                      class="qty-btn"
                      style="padding: 8px 14px; font-size: 12px; min-width: 76px; white-space: nowrap;"
                      onclick="window.__nextDebugApplyCoupon &amp;&amp; window.__nextDebugApplyCoupon('${escapeAttr(code)}')"
                      ${disabled ? "disabled" : ""}
                      title="${hasCode ? `Apply ${escapeAttr(code)}` : "Voucher has no code"}">${label}</button>
                  </div>
                `;
    }).join("")}
          </div>
        `;
    return `
      <div class="enhanced-panel">
        <div class="section">
          <h3 class="section-title">Applied Coupons (${applied.length})</h3>
          ${appliedSection}
        </div>
        <div class="section">
          <h3 class="section-title">Available Voucher Codes (${availableVouchers.length})</h3>
          ${availableSection}
        </div>
        <div class="section">
          <h3 class="section-title">Recent Attempts</h3>
          ${attemptsSection}
        </div>
      </div>
    `;
  }
  getRawDataContent() {
    const s = useCartStore.getState();
    return RawDataHelper.generateRawDataContent({
      vouchers: s.vouchers,
      offerDiscounts: s.offerDiscounts,
      voucherDiscounts: s.voucherDiscounts,
      hasDiscounts: s.hasDiscounts,
      totalDiscount: s.totalDiscount.toString(),
      totalDiscountPercentage: s.totalDiscountPercentage.toString(),
      summary: s.summary
    });
  }
}
function escapeHtml$1(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
function escapeAttr(str) {
  return escapeHtml$1(str).replace(/`/g, "&#96;");
}
function formatTime(ts) {
  const d = new Date(ts);
  return d.toLocaleTimeString();
}
function formatBenefit(o) {
  const b = o.benefit;
  if (!b) return "";
  if (b.description) return b.description;
  const labelMap = {
    package_percentage: "Package",
    shipping_percentage: "Shipping",
    order_percentage: "Order"
  };
  const label = labelMap[b.type] ?? b.type;
  return b.value ? `${label} − ${b.value}%` : label;
}
function formatCondition(o) {
  const c = o.condition;
  if (!c) return "";
  if (c.description) return c.description;
  if (c.type === "any") return "Always active";
  if (c.type === "count") return `Requires ≥ ${c.value} items in cart`;
  return c.type;
}
function renderAvailableOffer(o, isApplied) {
  return `
    <div class="cart-item-card">
      <div class="item-info">
        <div class="item-title">
          ${escapeHtml$1(o.name)}
          ${isApplied ? '<span style="color: #4caf50; font-size: 11px; margin-left: 8px;">● applied</span>' : ""}
        </div>
        <div class="item-details">
          <strong>Condition:</strong> ${escapeHtml$1(formatCondition(o))}
        </div>
        <div class="item-details">
          <strong>Benefit:</strong> ${escapeHtml$1(formatBenefit(o))}
        </div>
        <div class="item-details" style="opacity: 0.65; font-size: 11px;">
          ref_id: ${o.ref_id} • ${o.packages.length} package(s) • ${o.shipping_methods.length} shipping method(s)
        </div>
      </div>
    </div>
  `;
}
function resultBadge(result) {
  switch (result) {
    case "applied":
      return '<span style="color: #4caf50;">✅ applied</span>';
    case "failed":
      return '<span style="color: #ff5252;">❌ failed</span>';
    case "removed":
      return '<span style="color: #ffa726;">🗑️ removed</span>';
  }
}
if (typeof window !== "undefined") {
  const w = window;
  w.__nextDebugRemoveCoupon = (code) => {
    void cartOperations.removeCoupon(code);
  };
  w.__nextDebugApplyCoupon = async (code) => {
    const result = await cartOperations.applyCoupon(code);
    if (!result.success) {
      window.alert(`Coupon failed: ${result.message}`);
    }
  };
}
class EnhancedCampaignPanel {
  constructor() {
    this.id = "campaign";
    this.title = "Campaign Data";
    this.icon = lucide("megaphone");
  }
  getContent() {
    const tabs = this.getTabs();
    return tabs[0]?.getContent() || "";
  }
  getTabs() {
    return [
      {
        id: "overview",
        label: "Overview",
        icon: "📊",
        getContent: () => this.getOverviewContent()
      },
      {
        id: "packages",
        label: "Packages",
        icon: "📦",
        getContent: () => this.getPackagesContent()
      },
      {
        id: "shipping",
        label: "Shipping",
        icon: "🚚",
        getContent: () => this.getShippingContent()
      },
      {
        id: "raw",
        label: "Raw Data",
        icon: "🔧",
        getContent: () => this.getRawDataContent()
      }
    ];
  }
  getOverviewContent() {
    const campaignState = useCampaignStore.getState();
    const campaignData = campaignState.data;
    if (!campaignData) {
      return `
        <div class="enhanced-panel">
          <div class="empty-state">
            <div class="empty-icon">📊</div>
            <div class="empty-text">No campaign data loaded</div>
            <button class="empty-action" onclick="window.nextDebug.loadCampaign()">Load Campaign</button>
          </div>
        </div>
      `;
    }
    return `
      <div class="enhanced-panel">
        ${this.getCampaignOverview(campaignData)}
      </div>
    `;
  }
  getPackagesContent() {
    const campaignState = useCampaignStore.getState();
    const cartState = useCartStore.getState();
    const campaignData = campaignState.data;
    if (!campaignData) {
      return `
        <div class="enhanced-panel">
          <div class="empty-state">
            <div class="empty-icon">📦</div>
            <div class="empty-text">No campaign data loaded</div>
          </div>
        </div>
      `;
    }
    return `
      <div class="enhanced-panel">
        ${this.getPackagesSection(campaignData.packages, cartState)}
      </div>
    `;
  }
  getShippingContent() {
    const campaignState = useCampaignStore.getState();
    const campaignData = campaignState.data;
    if (!campaignData) {
      return `
        <div class="enhanced-panel">
          <div class="empty-state">
            <div class="empty-icon">🚚</div>
            <div class="empty-text">No campaign data loaded</div>
          </div>
        </div>
      `;
    }
    return `
      <div class="enhanced-panel">
        ${this.getShippingMethodsSection(campaignData.shipping_methods)}
      </div>
    `;
  }
  getRawDataContent() {
    const campaignState = useCampaignStore.getState();
    const campaignData = campaignState.data;
    if (!campaignData) {
      return `
        <div class="enhanced-panel">
          <div class="empty-state">
            <div class="empty-icon">🔧</div>
            <div class="empty-text">No campaign data loaded</div>
          </div>
        </div>
      `;
    }
    return RawDataHelper.generateRawDataContent(campaignData);
  }
  getCampaignOverview(data) {
    return `
      <div class="campaign-overview">
        <div class="campaign-header">
          <h2 class="campaign-name">${data.name}</h2>
          <div class="campaign-badges">
            <span class="campaign-badge currency">${data.currency}</span>
            <span class="campaign-badge language">${data.language.toUpperCase()}</span>
          </div>
        </div>
        
        <div class="metrics-grid">
          <div class="metric-card">
            <div class="metric-icon">📦</div>
            <div class="metric-content">
              <div class="metric-value">${data.packages.length}</div>
              <div class="metric-label">Total Packages</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🚚</div>
            <div class="metric-content">
              <div class="metric-value">${data.shipping_methods.length}</div>
              <div class="metric-label">Shipping Methods</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">🔄</div>
            <div class="metric-content">
              <div class="metric-value">${data.packages.filter((p) => p.is_recurring).length}</div>
              <div class="metric-label">Recurring Items</div>
            </div>
          </div>
          <div class="metric-card">
            <div class="metric-icon">💰</div>
            <div class="metric-content">
              <div class="metric-value">${this.getPriceRange(data.packages)}</div>
              <div class="metric-label">Price Range</div>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  getPackagesSection(packages, cartState) {
    return `
      <div class="section">
        <div class="section-header">
          <h3 class="section-title">Available Packages</h3>
          <div class="section-controls">
            <button class="sort-btn" onclick="window.nextDebug.sortPackages('price')">Sort by Price</button>
            <button class="sort-btn" onclick="window.nextDebug.sortPackages('name')">Sort by Name</button>
          </div>
        </div>
        
        <div class="packages-grid">
          ${packages.map((pkg) => this.getPackageCard(pkg, cartState)).join("")}
        </div>
      </div>
    `;
  }
  getPackageCard(pkg, cartState) {
    const isInCart = cartState.items.some((item) => item.packageId === pkg.ref_id);
    const cartItem = cartState.items.find((item) => item.packageId === pkg.ref_id);
    const savings = parseFloat(pkg.price_retail_total) - parseFloat(pkg.price_total);
    const savingsPercent = Math.round(savings / parseFloat(pkg.price_retail_total) * 100);
    return `
      <div class="package-card ${isInCart ? "in-cart" : ""}" data-package-id="${pkg.ref_id}">
        <div class="package-image-container">
          <img src="${pkg.image}" alt="${pkg.name}" class="package-image" loading="lazy" />
          ${pkg.is_recurring ? '<div class="recurring-badge">🔄 Recurring</div>' : ""}
          ${isInCart ? `<div class="cart-badge">In Cart (${cartItem?.quantity || 0})</div>` : ""}
        </div>
        
        <div class="package-info">
          <div class="package-header">
            <h4 class="package-name">${pkg.name}</h4>
            <div class="package-id">ID: ${pkg.ref_id}</div>
          </div>
          
          <div class="package-details">
            <div class="package-qty">Quantity: ${pkg.qty}</div>
            <div class="package-external-id">External ID: ${pkg.external_id}</div>
          </div>
          
          <div class="package-pricing">
            <div class="price-row">
              <span class="price-label">Sale Price:</span>
              <span class="price-value sale-price">$${pkg.price_total}</span>
            </div>
            ${pkg.price_retail_total !== pkg.price_total ? `
              <div class="price-row">
                <span class="price-label">Retail Price:</span>
                <span class="price-value retail-price">$${pkg.price_retail_total}</span>
              </div>
              <div class="savings">
                Save $${savings.toFixed(2)} (${savingsPercent}%)
              </div>
            ` : ""}
            
            ${pkg.is_recurring && pkg.price_recurring ? `
              <div class="recurring-pricing">
                <div class="price-row recurring">
                  <span class="price-label">Recurring:</span>
                  <span class="price-value recurring-price">
                    $${pkg.price_recurring_total}/${pkg.interval}
                  </span>
                </div>
              </div>
            ` : ""}
          </div>
          
          <div class="package-actions">
            ${isInCart ? `
              <button class="package-btn remove-btn" onclick="window.nextDebug.removeFromCart(${pkg.ref_id})">
                Remove from Cart
              </button>
              <div class="qty-controls">
                <button onclick="window.nextDebug.updateQuantity(${pkg.ref_id}, ${(cartItem?.quantity || 1) - 1})">-</button>
                <span>${cartItem?.quantity || 0}</span>
                <button onclick="window.nextDebug.updateQuantity(${pkg.ref_id}, ${(cartItem?.quantity || 1) + 1})">+</button>
              </div>
            ` : `
              <button class="package-btn add-btn" onclick="window.nextDebug.addToCart(${pkg.ref_id})">
                Add to Cart - $${pkg.price_total}
              </button>
            `}
            <button class="package-btn inspect-btn" onclick="window.nextDebug.inspectPackage(${pkg.ref_id})">
              Inspect
            </button>
          </div>
        </div>
      </div>
    `;
  }
  getShippingMethodsSection(shippingMethods) {
    return `
      <div class="section">
        <h3 class="section-title">Shipping Methods</h3>
        
        <div class="shipping-methods">
          ${shippingMethods.map((method) => `
            <div class="shipping-method-card">
              <div class="shipping-info">
                <div class="shipping-name">${method.code}</div>
                <div class="shipping-id">ID: ${method.ref_id}</div>
              </div>
              <div class="shipping-price">
                ${parseFloat(method.price) === 0 ? "FREE" : `$${method.price}`}
              </div>
              <button class="shipping-test-btn" onclick="window.nextDebug.testShippingMethod(${method.ref_id})">
                Test
              </button>
            </div>
          `).join("")}
        </div>
      </div>
    `;
  }
  getPriceRange(packages) {
    const prices = packages.map((p) => parseFloat(p.price_total)).filter((p) => p > 0);
    if (prices.length === 0) return "Free";
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    if (min === max) return `$${min}`;
    return `$${min} - $${max}`;
  }
  getActions() {
    return [
      {
        label: "Refresh Campaign",
        action: () => {
          const configStore$1 = configStore.getState();
          const campaignStore = useCampaignStore.getState();
          if (configStore$1.apiKey) {
            campaignStore.loadCampaign(configStore$1.apiKey);
          } else {
            console.error("No API key available to load campaign");
          }
        },
        variant: "primary"
      },
      {
        label: "Export Packages",
        action: () => this.exportPackages(),
        variant: "secondary"
      },
      {
        label: "Test All Packages",
        action: () => this.testAllPackages(),
        variant: "secondary"
      },
      {
        label: "Clear Cart",
        action: () => cartOperations.clear(),
        variant: "danger"
      }
    ];
  }
  exportPackages() {
    const campaignState = useCampaignStore.getState();
    const data = campaignState.data;
    if (!data) return;
    const exportData = {
      campaign: data.name,
      packages: data.packages,
      shipping_methods: data.shipping_methods,
      export_date: (/* @__PURE__ */ new Date()).toISOString()
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `campaign-packages-${data.name.toLowerCase().replace(/\s+/g, "-")}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
  testAllPackages() {
    const campaignState = useCampaignStore.getState();
    const data = campaignState.data;
    if (!data) return;
    data.packages.slice(0, 3).forEach((pkg) => {
      void cartOperations.addItem({
        packageId: pkg.ref_id,
        quantity: 1,
        title: pkg.name,
        isUpsell: false
      });
    });
  }
}
const _DebugOverlay = class _DebugOverlay {
  constructor() {
    this.visible = false;
    this.isExpanded = false;
    this.container = null;
    this.shadowRoot = null;
    this.activePanel = "cart";
    this.updateInterval = null;
    this.analyticsDebugUnsub = null;
    this.providerRefreshTimer = null;
    this.logger = new Logger("DebugOverlay");
    this.eventManager = null;
    this.panels = [];
    this.handleContainerClick = (event) => {
      const target = event.target;
      const action = target.getAttribute("data-action") || target.closest("[data-action]")?.getAttribute("data-action");
      if (action) {
        console.log("[Debug] Action clicked:", action);
        switch (action) {
          case "toggle-expand":
            this.isExpanded = !this.isExpanded;
            localStorage.setItem(_DebugOverlay.EXPANDED_STORAGE_KEY, this.isExpanded.toString());
            this.updateBodyHeight();
            this.updateOverlay();
            document.dispatchEvent(new CustomEvent("debug:panel-toggled", {
              detail: { isExpanded: this.isExpanded }
            }));
            break;
          case "close":
            this.hide();
            break;
          case "clear-cart":
            this.clearCart();
            break;
          case "export-data":
            this.exportAllData();
            break;
          case "toggle-mini-cart":
            this.toggleMiniCart();
            break;
          case "toggle-xray":
            this.toggleXray();
            break;
          case "close-mini-cart":
            this.closeMiniCart();
            break;
          case "toggle-internal-events":
            const eventPanel = this.panels.find((p) => p.id === "event-timeline");
            if (eventPanel && eventPanel.toggleInternalEvents) {
              eventPanel.toggleInternalEvents();
              this.updateContent();
            }
            break;
        }
        return;
      }
      const panelTab = target.closest(".debug-panel-tab");
      if (panelTab) {
        const panelId = panelTab.getAttribute("data-panel");
        console.log("[Debug] Panel switch:", this.activePanel, "->", panelId);
        if (panelId && panelId !== this.activePanel) {
          this.activePanel = panelId;
          this.activePanelTab = void 0;
          localStorage.setItem(_DebugOverlay.ACTIVE_PANEL_KEY, panelId);
          localStorage.removeItem(_DebugOverlay.ACTIVE_TAB_KEY);
          this.updateOverlay();
        }
        return;
      }
      const horizontalTab = target.closest(".horizontal-tab");
      if (horizontalTab) {
        const tabId = horizontalTab.getAttribute("data-panel-tab");
        console.log("[Debug] Horizontal tab switch:", this.activePanelTab, "->", tabId, "in panel:", this.activePanel);
        if (tabId && tabId !== this.activePanelTab) {
          this.activePanelTab = tabId;
          localStorage.setItem(_DebugOverlay.ACTIVE_TAB_KEY, tabId);
          this.updateOverlay();
        }
        return;
      }
      const panelActionBtn = target.closest(".panel-action-btn");
      if (panelActionBtn) {
        const actionLabel = panelActionBtn.getAttribute("data-panel-action");
        const activePanel = this.panels.find((p) => p.id === this.activePanel);
        const panelAction = activePanel?.getActions?.()?.find((a) => a.label === actionLabel);
        if (panelAction) {
          panelAction.action();
          setTimeout(() => this.updateOverlay(), 100);
        }
        return;
      }
    };
    this.handleContainerHover = (event) => {
      const target = event.target;
      const miniCartItem = target.closest(".debug-mini-cart-item");
      if (miniCartItem) {
        const detailsCard = miniCartItem.querySelector(".mini-cart-discount-details-card");
        if (detailsCard) {
          const itemRect = miniCartItem.getBoundingClientRect();
          const cardWidth = 250;
          const gap = 8;
          const left = itemRect.left - cardWidth - gap;
          const top = itemRect.top;
          detailsCard.style.left = `${left}px`;
          detailsCard.style.top = `${top}px`;
        }
      }
      const miniCartTotals = target.closest(".debug-mini-cart-totals.has-cart-discounts");
      if (miniCartTotals) {
        const cartDiscountPopup = miniCartTotals.querySelector(".mini-cart-cart-discount-popup .mini-cart-discount-details-card");
        if (cartDiscountPopup) {
          const totalsRect = miniCartTotals.getBoundingClientRect();
          const cardWidth = 250;
          const gap = 8;
          const left = totalsRect.left - cardWidth - gap;
          const top = totalsRect.top;
          cartDiscountPopup.style.left = `${left}px`;
          cartDiscountPopup.style.top = `${top}px`;
        }
      }
    };
    const urlParams = new URLSearchParams(window.location.search);
    const windowConfig = window.nextConfig;
    const isDebugMode = urlParams.get("debugger") === "true" || urlParams.get("debug") === "true" || windowConfig?.debugger === true || windowConfig?.debug === true;
    if (isDebugMode) {
      this.eventManager = new DebugEventManager();
      this.initializePanels();
      this.setupEventListeners();
      const savedExpandedState = localStorage.getItem(_DebugOverlay.EXPANDED_STORAGE_KEY);
      if (savedExpandedState === "true") {
        this.isExpanded = true;
      }
      const savedPanel = localStorage.getItem(_DebugOverlay.ACTIVE_PANEL_KEY);
      if (savedPanel) {
        this.activePanel = savedPanel;
      }
      const savedTab = localStorage.getItem(_DebugOverlay.ACTIVE_TAB_KEY);
      if (savedTab) {
        this.activePanelTab = savedTab;
      }
    }
  }
  static getInstance() {
    if (!_DebugOverlay.instance) {
      _DebugOverlay.instance = new _DebugOverlay();
    }
    return _DebugOverlay.instance;
  }
  initializePanels() {
    this.panels = [
      new CartPanel(),
      new OffersPanel(),
      new OrderPanel(),
      new ConfigPanel(),
      new EnhancedCampaignPanel(),
      new CheckoutPanel(),
      new EventTimelinePanel(),
      new StoragePanel()
    ];
  }
  setupEventListeners() {
    document.addEventListener("debug:update-content", () => {
      this.updateContent();
    });
    document.addEventListener("debug:event-added", (e) => {
      const customEvent = e;
      const { panelId } = customEvent.detail;
      if (this.activePanel === panelId && this.isExpanded) {
        this.updateContent();
      }
    });
    this.analyticsDebugUnsub?.();
    this.analyticsDebugUnsub = analyticsDebug.subscribe(() => {
      this.scheduleAnalyticsPanelRefresh();
    });
  }
  /**
   * Coalesce a burst of tracker notifications (one per provider per event) into
   * a single re-render on the next tick, and only when the Analytics panel is
   * the active, expanded view.
   */
  scheduleAnalyticsPanelRefresh() {
    if (this.providerRefreshTimer !== null) return;
    this.providerRefreshTimer = window.setTimeout(() => {
      this.providerRefreshTimer = null;
      if (!this.isExpanded) return;
      if (this.activePanel === "event-timeline") {
        this.updateContent();
      }
    }, 80);
  }
  initialize() {
    const urlParams = new URLSearchParams(window.location.search);
    const windowConfig = window.nextConfig;
    const isDebugMode = urlParams.get("debugger") === "true" || windowConfig?.debugger === true;
    if (isDebugMode) {
      this.show();
      this.logger.info("Debug overlay initialized");
      selectorContainer.initialize();
      this.logger.info("Selector container initialized");
      upsellSelector.initialize();
      this.logger.info("Upsell selector initialized");
    }
  }
  async show() {
    if (this.visible) return;
    this.visible = true;
    await this.createOverlay();
    this.startAutoUpdate();
    XrayManager.initialize();
    const savedMiniCartState = localStorage.getItem("debug-mini-cart-visible");
    if (savedMiniCartState === "true") {
      this.toggleMiniCart(true);
    }
    this.updateButtonStates();
  }
  hide() {
    if (!this.visible) return;
    this.visible = false;
    this.stopAutoUpdate();
    document.body.classList.remove("debug-body-expanded");
    document.documentElement.classList.remove("debug-body-expanded");
    selectorContainer.destroy();
    upsellSelector.destroy();
    if (this.container) {
      this.container.remove();
      this.container = null;
      this.shadowRoot = null;
    }
  }
  async toggle() {
    if (this.visible) {
      this.hide();
    } else {
      await this.show();
    }
  }
  isVisible() {
    return this.visible;
  }
  async createOverlay() {
    this.container = document.createElement("div");
    this.container.id = "next-debug-overlay-host";
    this.container.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 2147483647;
      pointer-events: none;
    `;
    this.shadowRoot = this.container.attachShadow({ mode: "open" });
    await this.injectShadowStyles();
    const overlayContainer = document.createElement("div");
    overlayContainer.className = "debug-overlay";
    overlayContainer.style.pointerEvents = "auto";
    this.shadowRoot.appendChild(overlayContainer);
    this.updateOverlay();
    this.addEventListeners();
    document.body.appendChild(this.container);
  }
  async injectShadowStyles() {
    if (!this.shadowRoot) return;
    const { DebugStyleLoader: DebugStyleLoader2 } = await Promise.resolve().then(() => DebugStyleLoader$1);
    const styles = await DebugStyleLoader2.getDebugStyles();
    const styleElement = document.createElement("style");
    styleElement.textContent = styles;
    this.shadowRoot.appendChild(styleElement);
    const resetStyles = document.createElement("style");
    resetStyles.textContent = `
      :host {
        all: initial;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
        font-size: 14px;
        line-height: 1.5;
        color: #e0e0e0;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
      }
      
      * {
        box-sizing: border-box;
      }
      
      /* Ensure debug overlay is always on top */
      .debug-overlay {
        position: fixed;
        z-index: 2147483647;
      }
    `;
    this.shadowRoot.appendChild(resetStyles);
  }
  updateOverlay() {
    if (!this.shadowRoot) return;
    const overlayContainer = this.shadowRoot.querySelector(".debug-overlay");
    if (!overlayContainer) return;
    overlayContainer.innerHTML = EnhancedDebugUI.createOverlayHTML(
      this.panels,
      this.activePanel,
      this.isExpanded,
      this.activePanelTab
    );
    RawDataHelper.bindCopyHandlers(overlayContainer);
    this.addEventListeners();
    this.updateButtonStates();
  }
  updateContent() {
    if (!this.shadowRoot) return;
    const panelContent = this.shadowRoot.querySelector(".panel-content");
    if (!panelContent) return;
    const activePanel = this.panels.find((p) => p.id === this.activePanel);
    if (!activePanel) return;
    const focused = this.shadowRoot.activeElement;
    const search = focused && focused.matches?.("[data-debug-search]") ? { start: focused.selectionStart, end: focused.selectionEnd } : null;
    const tabs = activePanel.getTabs?.() || [];
    if (tabs.length > 0) {
      const activeTabId = this.activePanelTab || tabs[0]?.id;
      const activeTab = tabs.find((tab) => tab.id === activeTabId) || tabs[0];
      if (activeTab) {
        panelContent.innerHTML = activeTab.getContent();
        RawDataHelper.bindCopyHandlers(panelContent);
      }
    } else {
      panelContent.innerHTML = activePanel.getContent();
      RawDataHelper.bindCopyHandlers(panelContent);
    }
    if (search) {
      const input = panelContent.querySelector(
        "[data-debug-search]"
      );
      if (input) {
        input.focus();
        const end = input.value.length;
        try {
          input.setSelectionRange(search.start ?? end, search.end ?? end);
        } catch {
        }
      }
    }
  }
  addEventListeners() {
    if (!this.shadowRoot) return;
    this.shadowRoot.removeEventListener("click", this.handleContainerClick);
    this.shadowRoot.removeEventListener("mouseover", this.handleContainerHover);
    this.shadowRoot.addEventListener("click", this.handleContainerClick);
    this.shadowRoot.addEventListener("mouseover", this.handleContainerHover);
  }
  updateBodyHeight() {
    if (this.isExpanded) {
      document.body.classList.add("debug-body-expanded");
      document.documentElement.classList.add("debug-body-expanded");
    } else {
      document.body.classList.remove("debug-body-expanded");
      document.documentElement.classList.remove("debug-body-expanded");
    }
  }
  startAutoUpdate() {
    this.updateInterval = window.setInterval(() => {
      this.updateQuickStats();
      if ((this.activePanel === "cart" || this.activePanel === "config" || this.activePanel === "campaign") && this.activePanelTab !== "raw") {
        this.updateContent();
      }
    }, 1e3);
  }
  stopAutoUpdate() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
    if (this.providerRefreshTimer !== null) {
      clearTimeout(this.providerRefreshTimer);
      this.providerRefreshTimer = null;
    }
  }
  // Public API for external access
  getEventManager() {
    return this.eventManager || null;
  }
  getPanels() {
    return this.panels || [];
  }
  setActivePanel(panelId) {
    if (this.panels.find((p) => p.id === panelId)) {
      this.activePanel = panelId;
      localStorage.setItem(_DebugOverlay.ACTIVE_PANEL_KEY, panelId);
      this.updateOverlay();
    }
  }
  logEvent(type, data, source = "Manual") {
    if (this.eventManager) {
      this.eventManager.logEvent(type, data, source);
    }
  }
  // Enhanced debug methods for global access
  clearCart() {
    cartOperations.clear();
    this.updateContent();
  }
  exportAllData() {
    const debugData = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      cart: useCartStore.getState(),
      config: configStore.getState(),
      events: this.eventManager ? this.eventManager.getEvents() : [],
      url: window.location.href,
      userAgent: navigator.userAgent
    };
    const data = JSON.stringify(debugData, null, 2);
    const blob = new Blob([data], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `debug-session-${(/* @__PURE__ */ new Date()).toISOString()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }
  closeMiniCart() {
    if (!this.shadowRoot) return;
    const miniCart = this.shadowRoot.querySelector("#debug-mini-cart-display");
    if (miniCart) {
      miniCart.classList.remove("show");
      localStorage.setItem("debug-mini-cart-visible", "false");
      const cartButton = this.shadowRoot.querySelector('[data-action="toggle-mini-cart"]');
      if (cartButton) {
        cartButton.classList.remove("active");
        cartButton.setAttribute("title", "Toggle Mini Cart");
      }
    }
  }
  toggleMiniCart(forceShow) {
    if (!this.shadowRoot) return;
    let miniCart = this.shadowRoot.querySelector("#debug-mini-cart-display");
    if (!miniCart) {
      miniCart = document.createElement("div");
      miniCart.id = "debug-mini-cart-display";
      miniCart.className = "debug-mini-cart-display";
      this.shadowRoot.appendChild(miniCart);
      useCartStore.subscribe(() => {
        const cart = this.shadowRoot?.querySelector("#debug-mini-cart-display");
        if (cart && cart.classList.contains("show")) {
          this.updateMiniCart();
        }
      });
      if (forceShow !== false) {
        miniCart.classList.add("show");
        this.updateMiniCart();
      }
    } else {
      miniCart.classList.toggle("show");
      if (miniCart.classList.contains("show")) {
        this.updateMiniCart();
      }
    }
    localStorage.setItem("debug-mini-cart-visible", miniCart.classList.contains("show").toString());
    const cartButton = this.shadowRoot?.querySelector('[data-action="toggle-mini-cart"]');
    if (cartButton && miniCart) {
      if (miniCart.classList.contains("show")) {
        cartButton.classList.add("active");
        cartButton.setAttribute("title", "Hide Mini Cart");
      } else {
        cartButton.classList.remove("active");
        cartButton.setAttribute("title", "Toggle Mini Cart");
      }
    }
  }
  updateMiniCart() {
    if (!this.shadowRoot) return;
    const miniCart = this.shadowRoot.querySelector("#debug-mini-cart-display");
    if (!miniCart || !miniCart.classList.contains("show")) return;
    const cartState = useCartStore.getState();
    if (!cartState.items || cartState.items.length === 0) {
      miniCart.innerHTML = `
        <div class="debug-mini-cart-header">
          <span>🛒 Debug Cart</span>
          <button class="mini-cart-close" data-action="close-mini-cart">×</button>
        </div>
        <div class="debug-mini-cart-empty">Cart empty</div>
      `;
      return;
    }
    let itemsHtml = "";
    let subtotalBeforeDiscounts = 0;
    cartState.items.forEach((item) => {
      const isUpsell = item.is_upsell;
      const upsellBadge = isUpsell ? '<span class="mini-cart-upsell-badge">UPSELL</span>' : "";
      const packagePriceExcl = item.original_package_price ? parseFloat(item.original_package_price) : 0;
      const packagePriceIncl = item.package_price ? parseFloat(item.package_price) : item.price;
      const itemHasDiscount = packagePriceExcl > 0 && packagePriceIncl < packagePriceExcl;
      const currentUnitPrice = packagePriceIncl;
      const originalUnitPrice = packagePriceExcl > 0 ? packagePriceExcl : packagePriceIncl;
      const currentLineTotal = currentUnitPrice * item.quantity;
      const originalLineTotal = originalUnitPrice * item.quantity;
      subtotalBeforeDiscounts += currentLineTotal;
      const itemLineSavings = itemHasDiscount ? originalLineTotal - currentLineTotal : 0;
      const savingsPercent = itemHasDiscount ? Math.round((originalUnitPrice - currentUnitPrice) / originalUnitPrice * 100) : 0;
      let discountDetailsCard = "";
      if (item.discounts && item.discounts.length > 0) {
        item.discounts.forEach((d) => {
        });
      }
      const hasProperties = item.properties && Object.keys(item.properties).length > 0;
      const propertiesHtml = hasProperties ? `<ul class="discount-card-list">
            ${Object.entries(item.properties).map(([k, v]) => `
            <li class="prop-card-item">
              <span class="discount-card-bullet">•</span>
              <span class="prop-card-body">
                <span class="prop-card-key">${escapeHtml(k)}</span>
                <span class="prop-card-value">${escapeHtml(v)}</span>
              </span>
            </li>`).join("")}
          </ul>` : "";
      if (itemHasDiscount || item.discounts && item.discounts.length > 0 || hasProperties) {
        let discountItemsHtml = "";
        if (item.discounts && item.discounts.length > 0) {
          discountItemsHtml = item.discounts.map((d) => `
            <li class="discount-card-item">
              <span class="discount-card-bullet">•</span>
              <span style="display: flex; justify-content: space-between; width: 100%;">
                <span class="discount-card-text">${d.description}</span>
                <span class="discount-card-text" style="text-align: right;">${formatCurrency(parseFloat(d.amount))}</span>
              </span>
            </li>
          `).join("");
        } else if (itemHasDiscount) {
          discountItemsHtml = `
            <li class="discount-card-item">
              <span class="discount-card-bullet">•</span>
              <span class="discount-card-text">Price discount applied (${savingsPercent}% off)</span>
            </li>
          `;
        }
        const discountSection = discountItemsHtml ? `
          <div class="discount-card-header">
            <span class="discount-card-icon">🎯</span>
            <span class="discount-card-title">Applied Discounts</span>
          </div>
          <ul class="discount-card-list">${discountItemsHtml}</ul>
        ` : "";
        const propertiesSection = propertiesHtml ? `
          <div class="discount-card-header${discountSection ? " discount-card-header--separator" : ""}">
            <span class="discount-card-icon">🏷️</span>
            <span class="discount-card-title">Properties</span>
          </div>
          ${propertiesHtml}
        ` : "";
        discountDetailsCard = `
          <div class="mini-cart-discount-details-card">
            ${discountSection}
            ${propertiesSection}
          </div>
        `;
      }
      if (itemHasDiscount) {
        `
          <div class="mini-cart-price-details">
            <span class="mini-cart-original-price">${formatCurrency(originalUnitPrice)} each</span>
            <span class="mini-cart-unit-price">${formatCurrency(currentUnitPrice)} each</span>
          </div>
          <div class="mini-cart-line-total">${formatCurrency(currentLineTotal)}</div>
        `;
      } else {
        `
          <span class="mini-cart-unit-price">${formatCurrency(currentUnitPrice)} each</span>
          <div class="mini-cart-line-total">${formatCurrency(currentLineTotal)}</div>
        `;
      }
      itemsHtml += `
        <div class="debug-mini-cart-item${itemHasDiscount ? " has-discount" : ""}">
          ${discountDetailsCard}
          <div class="mini-cart-item-header">
            <div class="mini-cart-item-title-row">
              <div class="mini-cart-item-title">${item.title || "Unknown"}</div>
              <div class="mini-cart-line-total">${formatCurrency(currentLineTotal)}</div>
            </div>
            <div class="mini-cart-item-meta">
              <span class="mini-cart-item-id">ID: ${item.packageId}</span>
              ${upsellBadge}
            </div>
          </div>
          ${itemHasDiscount ? `
            <div class="mini-cart-item-price-breakdown">
              <div class="mini-cart-price-row">
                <span class="mini-cart-price-label">Was</span>
                <span class="mini-cart-original-price">${formatCurrency(originalUnitPrice)} each</span>
              </div>
              <div class="mini-cart-price-row mini-cart-sale-row">
                <span class="mini-cart-price-label">Now</span>
                <span class="mini-cart-unit-price">${formatCurrency(currentUnitPrice)} each × ${item.quantity}</span>
              </div>
              <div class="mini-cart-price-row mini-cart-savings-row">
                <span class="mini-cart-price-label">You save</span>
                <span class="mini-cart-savings-amount">${formatCurrency(itemLineSavings)} (${savingsPercent}% off)</span>
              </div>
            </div>
          ` : `
            <div class="mini-cart-item-price-breakdown">
              <div class="mini-cart-price-row">
                <span class="mini-cart-unit-price">${formatCurrency(currentUnitPrice)} each × ${item.quantity}</span>
              </div>
            </div>
          `}
        </div>
      `;
    });
    const totalDiscount = cartState.totalDiscount.toNumber();
    const shipping = cartState.shippingMethod?.price.toNumber() ?? 0;
    const shippingDiscount = cartState.shippingMethod?.discountAmount.toNumber() ?? 0;
    const displayShipping = shippingDiscount > 0 ? shipping + shippingDiscount : shipping;
    const shippingLabel = displayShipping === 0 ? "FREE" : formatCurrency(displayShipping);
    const total = cartState.total.toNumber();
    const itemLevelOfferIds = /* @__PURE__ */ new Set();
    cartState.items.forEach((item) => {
      if (item.discounts) {
        item.discounts.forEach((d) => itemLevelOfferIds.add(d.offer_id));
      }
    });
    let hasCartLevelDiscounts = false;
    let cartLevelDiscountList = [];
    if (cartState.offerDiscounts || cartState.voucherDiscounts) {
      const offerDiscounts = cartState.offerDiscounts ?? [];
      const voucherDiscounts = cartState.voucherDiscounts ?? [];
      if (offerDiscounts.length > 0) {
        offerDiscounts.forEach((discount) => {
          const label = discount.name || discount.description || (discount.offer_id ? `Offer #${discount.offer_id}` : "Offer");
          const amount = parseFloat(discount.amount);
          cartLevelDiscountList.push({ type: "offer", label, amount });
        });
      }
      if (voucherDiscounts.length > 0) {
        hasCartLevelDiscounts = true;
        voucherDiscounts.forEach((discount) => {
          const amount = parseFloat(discount.amount);
          const label = discount.name || discount.description || "Voucher";
          cartLevelDiscountList.push({ type: "voucher", label, amount });
        });
      }
    } else if (totalDiscount > 0) {
      hasCartLevelDiscounts = true;
      cartLevelDiscountList.push({ type: "offer", label: "Discount", amount: totalDiscount });
    }
    console.log(cartLevelDiscountList);
    let cartDiscountPopup = "";
    if (hasCartLevelDiscounts) {
      const discountItemsHtml = cartLevelDiscountList.map((discount) => `
        <li class="discount-card-item">
          <span class="discount-card-bullet">•</span>
          <span style="display: flex; justify-content: space-between; width: 100%; gap: 8px;">
            <span class="discount-card-text">
              <span class="mini-cart-discount-type">${discount.type.toUpperCase()}</span> ${discount.label}
            </span>
            <span class="discount-card-text" style="text-align: right;">-${formatCurrency(discount.amount)}</span>
          </span>
        </li>
      `).join("");
      cartDiscountPopup = `
        <div class="mini-cart-cart-discount-popup">
          <div class="mini-cart-discount-details-card">
            <div class="discount-card-header">
              <span class="discount-card-icon">🎁</span>
              <span class="discount-card-title">Discounts</span>
            </div>
            <ul class="discount-card-list">${discountItemsHtml}</ul>
          </div>
        </div>
      `;
    }
    let shippingRow = "";
    if (shippingDiscount > 0) {
      shippingRow = `
        <div class="mini-cart-total-row mini-cart-shipping-row has-discount">
          <span>Shipping:</span>
          <span class="mini-cart-shipping-prices">
            <span class="mini-cart-original-price">${formatCurrency(displayShipping)}</span>
            <span class="mini-cart-shipping">${formatCurrency(shipping)}</span>
          </span>
        </div>
      `;
    } else {
      shippingRow = `
        <div class="mini-cart-total-row">
          <span>Shipping:</span>
          <span class="mini-cart-shipping">${shippingLabel}</span>
        </div>
      `;
    }
    miniCart.innerHTML = `
      <div class="debug-mini-cart-header">
        <span>🛒 Debug Cart</span>
        <button class="mini-cart-close" data-action="close-mini-cart">×</button>
      </div>
      <div class="debug-mini-cart-items">${itemsHtml}</div>
      <div class="debug-mini-cart-totals${hasCartLevelDiscounts ? " has-cart-discounts" : ""}">
        ${cartDiscountPopup}
        <div class="mini-cart-total-row">
          <span>Subtotal:</span>
          <span>${formatCurrency(subtotalBeforeDiscounts)}</span>
        </div>
        ${shippingRow}
        <div class="mini-cart-total-row mini-cart-final-total">
          <span>Total:</span>
          <span class="mini-cart-total">${formatCurrency(total)}</span>
        </div>
      </div>
      <div class="debug-mini-cart-footer">
        <div class="mini-cart-stat">
          <span>Items:</span>
          <span>${cartState.totalQuantity}</span>
        </div>
      </div>
      <div class="debug-mini-cart-resize-handle" title="Drag to resize"></div>
    `;
    this.bindResizeHandle(miniCart);
  }
  bindResizeHandle(miniCart) {
    const handle = miniCart.querySelector(
      ".debug-mini-cart-resize-handle"
    );
    const items = miniCart.querySelector(
      ".debug-mini-cart-items"
    );
    if (!handle || !items) return;
    const savedHeight = localStorage.getItem("debug-mini-cart-height");
    if (savedHeight) {
      items.style.maxHeight = `${savedHeight}px`;
      items.style.height = `${savedHeight}px`;
    }
    const firstItem = items.querySelector(
      ".debug-mini-cart-item"
    );
    const minHeight = firstItem ? firstItem.offsetHeight + parseInt(getComputedStyle(items).paddingTop) + parseInt(getComputedStyle(items).paddingBottom) : 40;
    let startY = 0;
    let startHeight = 0;
    const clamp = (h) => Math.max(minHeight, Math.min(600, h));
    const onMouseMove = (e) => {
      const newHeight = clamp(startHeight + (e.clientY - startY));
      items.style.maxHeight = `${newHeight}px`;
      items.style.height = `${newHeight}px`;
    };
    const onMouseUp = (e) => {
      const newHeight = clamp(startHeight + (e.clientY - startY));
      localStorage.setItem("debug-mini-cart-height", String(newHeight));
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
      handle.classList.remove("dragging");
    };
    handle.addEventListener("mousedown", (e) => {
      e.preventDefault();
      startY = e.clientY;
      startHeight = items.offsetHeight;
      handle.classList.add("dragging");
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    });
  }
  toggleXray() {
    const isActive = XrayManager.toggle();
    const xrayButton = this.shadowRoot?.querySelector('[data-action="toggle-xray"]');
    if (xrayButton) {
      if (isActive) {
        xrayButton.classList.add("active");
        xrayButton.setAttribute("title", "Disable X-Ray View");
      } else {
        xrayButton.classList.remove("active");
        xrayButton.setAttribute("title", "Toggle X-Ray View");
      }
    }
    if (this.eventManager) {
      this.eventManager.logEvent("debug:xray-toggled", { active: isActive }, "Debug");
    }
  }
  updateButtonStates() {
    if (!this.shadowRoot) return;
    const xrayButton = this.shadowRoot.querySelector('[data-action="toggle-xray"]');
    if (xrayButton) {
      if (XrayManager.isXrayActive()) {
        xrayButton.classList.add("active");
        xrayButton.setAttribute("title", "Disable X-Ray View");
      } else {
        xrayButton.classList.remove("active");
        xrayButton.setAttribute("title", "Toggle X-Ray View");
      }
    }
    const miniCart = this.shadowRoot.querySelector("#debug-mini-cart-display");
    const cartButton = this.shadowRoot.querySelector('[data-action="toggle-mini-cart"]');
    if (cartButton) {
      if (miniCart && miniCart.classList.contains("show")) {
        cartButton.classList.add("active");
        cartButton.setAttribute("title", "Hide Mini Cart");
      } else {
        cartButton.classList.remove("active");
        cartButton.setAttribute("title", "Toggle Mini Cart");
      }
    }
  }
  updateQuickStats() {
    if (!this.shadowRoot) return;
    const cartState = useCartStore.getState();
    const cartItemsEl = this.shadowRoot.querySelector('[data-debug-stat="cart-items"]');
    const cartTotalEl = this.shadowRoot.querySelector('[data-debug-stat="cart-total"]');
    const enhancedElementsEl = this.shadowRoot.querySelector('[data-debug-stat="enhanced-elements"]');
    if (cartItemsEl) cartItemsEl.textContent = cartState.totalQuantity.toString();
    if (cartTotalEl) cartTotalEl.textContent = formatCurrency(cartState.total.toNumber());
    if (enhancedElementsEl) enhancedElementsEl.textContent = document.querySelectorAll("[data-next-]").length.toString();
  }
};
_DebugOverlay.EXPANDED_STORAGE_KEY = "debug-overlay-expanded";
_DebugOverlay.ACTIVE_PANEL_KEY = "debug-overlay-active-panel";
_DebugOverlay.ACTIVE_TAB_KEY = "debug-overlay-active-tab";
let DebugOverlay = _DebugOverlay;
function escapeHtml(str) {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}
const debugOverlay = DebugOverlay.getInstance();
if (typeof window !== "undefined") {
  document.addEventListener("DOMContentLoaded", () => {
    debugOverlay.initialize();
  });
}
const DebugOverlay$1 = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  DebugOverlay,
  debugOverlay
});
const baseCSS = ".enhanced-debug-overlay{position:fixed;bottom:0;left:0;right:0;z-index:999999;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,SF Pro Display,sans-serif;font-size:13px;line-height:1.4;color:#fff;transition:all .3s cubic-bezier(.4,0,.2,1);box-shadow:0 -4px 32px #0000004d}.enhanced-debug-overlay.collapsed{height:60px}.enhanced-debug-overlay.expanded{height:40vh;min-height:450px;max-height:calc(100vh - 120px)}body:has(.enhanced-debug-overlay.expanded){padding-bottom:40vh}.debug-body-expanded{padding-bottom:40vh!important;box-sizing:border-box}html.debug-body-expanded{overflow-x:hidden}.debug-bottom-bar{display:flex;align-items:center;justify-content:space-between;height:60px;background:linear-gradient(135deg,#1a1a1a,#2d2d2d);border-top:1px solid #3C7DFF;padding:0 20px;backdrop-filter:blur(20px)}.debug-logo-section{display:flex;align-items:center;gap:12px}.debug-logo{color:#3c7dff;filter:drop-shadow(0 0 8px rgba(60,125,255,.3))}.debug-title{font-weight:600;font-size:16px;color:#fff;letter-spacing:-.2px}.debug-status{display:flex;align-items:center;gap:6px;margin-left:12px;padding:4px 8px;background:#3c7dff1a;border-radius:12px;border:1px solid rgba(60,125,255,.2)}.status-indicator{width:6px;height:6px;border-radius:50%;background:#0f8;box-shadow:0 0 6px #0f8;animation:pulse 2s infinite}@keyframes pulse{0%,to{opacity:1}50%{opacity:.5}}.status-text{font-size:11px;color:#3c7dff;font-weight:500}.debug-quick-stats{display:flex;align-items:center;gap:24px}.stat-item{display:flex;flex-direction:column;align-items:center;gap:2px}.stat-value{font-size:16px;font-weight:700;color:#3c7dff;min-width:40px;text-align:center}.stat-label{font-size:10px;color:#888;text-transform:uppercase;font-weight:500;letter-spacing:.5px}.debug-controls{display:flex;align-items:center;gap:8px}.debug-control-btn,.debug-expand-btn{width:36px;height:36px;border:none;border-radius:8px;background:#ffffff1a;color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .2s ease;position:relative;overflow:hidden}.debug-control-btn:hover,.debug-expand-btn:hover{background:#3c7dff33;transform:translateY(-1px);box-shadow:0 4px 12px #3c7dff4d}.debug-control-btn.active{background:#3c7dff4d;color:#87b4ff;box-shadow:inset 0 0 0 1px #3c7dff80}.debug-control-btn.active:hover{background:#3c7dff66}.debug-expand-btn{background:#3c7dff;color:#fff}.debug-expand-btn:hover{background:#2563eb;transform:translateY(-1px) scale(1.05)}.expand-icon{transition:transform .3s ease}.expand-icon.rotated{transform:rotate(180deg)}.close-btn:hover{background:#ff475733!important;color:#ff4757}.debug-expanded-content{display:flex;height:calc(100% - 60px);background:#1a1a1a}.debug-highlight{outline:2px solid #3C7DFF!important;outline-offset:2px!important;background:#3c7dff1a!important;position:relative!important;z-index:999998!important}.debug-highlight:after{content:attr(data-debug-label);position:absolute;top:-30px;left:0;background:#3c7dff;color:#fff;padding:4px 8px;border-radius:4px;font-size:11px;font-weight:500;white-space:nowrap;z-index:999999}@media (max-width: 768px){.debug-quick-stats{display:none}.debug-bottom-bar{padding:0 12px}}@media (max-width: 640px){.debug-title{display:none}}";
const sidebarCSS = '.debug-sidebar{width:240px;background:linear-gradient(180deg,#222,#1a1a1a);border-right:1px solid #333;display:flex;flex-direction:column}.debug-panel-tabs{flex:1;padding:16px 0}.debug-panel-tab{width:100%;display:flex;align-items:center;gap:12px;padding:12px 20px;border:none;background:none;color:#888;cursor:pointer;transition:all .2s ease;position:relative;font-size:14px}.debug-panel-tab:hover{background:#3c7dff1a;color:#fff}.debug-panel-tab.active{background:#3c7dff26;color:#3c7dff;border-right:3px solid #3C7DFF}.debug-panel-tab.active:before{content:"";position:absolute;left:0;top:0;bottom:0;width:3px;background:#3c7dff}.tab-icon{font-size:16px;width:20px;text-align:center}.tab-label{font-weight:500;flex:1}.tab-badge{background:#3c7dff;color:#fff;font-size:10px;font-weight:600;padding:2px 6px;border-radius:10px;min-width:16px;text-align:center}.debug-sidebar-footer{padding:16px;border-top:1px solid #333;display:flex;flex-direction:column;gap:8px}.sidebar-btn{display:flex;align-items:center;gap:8px;padding:8px 12px;border:1px solid #333;border-radius:6px;background:#ffffff0d;color:#888;cursor:pointer;font-size:12px;transition:all .2s ease}.sidebar-btn:hover{background:#3c7dff1a;border-color:#3c7dff;color:#3c7dff}@media (max-width: 768px){.debug-sidebar{width:200px}}@media (max-width: 640px){.debug-sidebar{width:180px}}';
const panelsCSS = ".debug-main-content{flex:1;background:#1a1a1a;overflow:hidden;display:flex;flex-direction:column}.debug-panel-container{flex:1;display:flex;flex-direction:column;height:100%}.panel-header{display:flex;align-items:center;justify-content:space-between;padding:6px 12px;border-bottom:1px solid #333;background:linear-gradient(135deg,#222,#1a1a1a)}.panel-title{display:flex;align-items:center;gap:12px}.panel-icon{font-size:20px}.panel-title h2{margin:0;font-size:18px;font-weight:600;color:#fff}.panel-actions{display:flex;gap:8px}.panel-action-btn{padding:8px 16px;border:none;border-radius:6px;font-size:12px;font-weight:500;cursor:pointer;transition:all .2s ease}.panel-action-btn.primary{background:#3c7dff;color:#fff}.panel-action-btn.secondary{background:#ffffff1a;color:#fff;border:1px solid #333}.panel-action-btn.danger{background:#ff47571a;color:#ff4757;border:1px solid rgba(255,71,87,.3)}.panel-action-btn:hover{transform:translateY(-1px);box-shadow:0 4px 12px #0000004d}.panel-action-btn.primary:hover{background:#2563eb}.panel-action-btn.secondary:hover{background:#ffffff26}.panel-action-btn.danger:hover{background:#ff475733}.panel-horizontal-tabs{display:flex;background:#1a1a1a;border-bottom:1px solid #333;overflow-x:auto}.horizontal-tab{display:flex;align-items:center;gap:8px;padding:12px 20px;background:none;border:none;color:#888;font-size:13px;font-weight:500;cursor:pointer;transition:all .2s ease;white-space:nowrap;border-bottom:2px solid transparent}.horizontal-tab:hover{background:#ffffff0d;color:#ccc}.horizontal-tab.active{color:#3c7dff;border-bottom-color:#3c7dff;background:#3c7dff0d}.horizontal-tab .tab-icon{font-size:14px}.horizontal-tab .tab-label{font-weight:500}.panel-content{flex:1;padding:24px;overflow-y:auto;color:#ccc}.panel-content.no-padding{padding:0}.panel-content::-webkit-scrollbar{width:8px}.panel-content::-webkit-scrollbar-track{background:#ffffff05;border-radius:4px}.panel-content::-webkit-scrollbar-thumb{background:#ffffff1a;border-radius:4px;transition:background .2s ease}.panel-content::-webkit-scrollbar-thumb:hover{background:#fff3}.panel-content::-webkit-scrollbar-thumb:active{background:#ffffff4d}.panel-content{scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.1) rgba(255,255,255,.02)}.panel-content>.enhanced-panel{margin-top:0}.panel-content>.enhanced-panel>*:first-child{margin-top:0}.panel-content .section:first-child,.panel-content .section:first-child .section-title,.panel-content h3:first-child,.panel-content .section-title:first-child,.panel-content h1,.panel-content h2,.panel-content h3,.panel-content h4,.panel-content h5,.panel-content h6{margin-top:0}.enhanced-panel{display:flex;flex-direction:column;gap:24px}.metrics-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:16px}.metric-card{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;padding:16px;display:flex;align-items:center;gap:12px;transition:all .2s ease}.metric-card:hover{border-color:#3c7dff;box-shadow:0 4px 12px #3c7dff1a}.metric-icon{font-size:20px;width:32px;text-align:center}.metric-content{flex:1}.metric-value{font-size:18px;font-weight:700;color:#3c7dff;line-height:1}.metric-label{font-size:11px;color:#888;text-transform:uppercase;font-weight:500;letter-spacing:.5px;margin-top:2px}.section{display:flex;flex-direction:column;gap:16px}.section-title{font-size:16px;font-weight:600;color:#fff;margin:0;padding-bottom:8px;border-bottom:1px solid #333}.section-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}.section-controls{display:flex;gap:8px}.sort-btn{background:#ffffff1a;border:1px solid #333;color:#ccc;padding:6px 12px;border-radius:6px;font-size:12px;cursor:pointer;transition:all .2s ease}.sort-btn:hover{background:#3c7dff1a;border-color:#3c7dff;color:#3c7dff}.empty-state{display:flex;flex-direction:column;align-items:center;gap:12px;padding:40px 20px;color:#888;text-align:center}.empty-icon{font-size:32px;opacity:.5}.empty-text{font-size:14px}.empty-action{background:#3c7dff;color:#fff;border:none;padding:8px 16px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:500}.json-viewer{background:#0f0f0f;border:1px solid #333;border-radius:8px;overflow:hidden}.json-viewer pre{margin:0;padding:16px;overflow-x:auto;font-family:SF Mono,monospace;font-size:12px;line-height:1.6;color:#e6e6e6}.debug-metric{display:flex;justify-content:space-between;align-items:center;padding:12px 0;border-bottom:1px solid #2a2a2a}.debug-metric:last-child{border-bottom:none}.metric-label{color:#888;font-weight:500}.metric-value{color:#3c7dff;font-family:SF Mono,monospace;font-weight:600}@media (max-width: 768px){.panel-header,.panel-content{padding:16px}.metrics-grid{grid-template-columns:repeat(auto-fit,minmax(120px,1fr))}}";
const componentsCSS = '.cart-items-list{display:flex;flex-direction:column;gap:8px}.cart-item-card{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;padding:16px;display:flex;align-items:center;gap:16px}.item-info{flex:1}.item-title{font-weight:600;color:#fff;margin-bottom:4px}.item-details{font-size:12px;color:#888}.item-quantity{display:flex;align-items:center;gap:8px}.qty-btn{width:24px;height:24px;border:1px solid #333;background:#ffffff0d;color:#fff;border-radius:4px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-weight:600}.qty-btn:hover{background:#3c7dff1a;border-color:#3c7dff}.qty-value{font-weight:600;color:#3c7dff;min-width:20px;text-align:center}.item-total{font-weight:600;color:#3c7dff}.remove-btn{width:24px;height:24px;border:1px solid rgba(255,71,87,.3);background:#ff47571a;color:#ff4757;border-radius:4px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-weight:600}.remove-btn:hover{background:#ff475733}.elements-list{display:flex;flex-direction:column;gap:8px}.element-card{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;padding:16px;cursor:pointer;transition:all .2s ease}.element-card:hover{border-color:#3c7dff;box-shadow:0 4px 12px #3c7dff1a}.element-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}.element-tag{background:#3c7dff;color:#fff;padding:2px 6px;border-radius:4px;font-size:10px;font-weight:600;text-transform:uppercase}.element-index{color:#888;font-size:12px}.element-attributes,.element-enhancers{display:flex;flex-wrap:wrap;gap:4px;margin-top:8px}.attribute-tag{background:#ffffff1a;color:#ccc;padding:2px 6px;border-radius:3px;font-size:10px;font-family:SF Mono,monospace}.enhancer-tag{background:#3c7dff33;color:#3c7dff;padding:2px 6px;border-radius:3px;font-size:10px;font-weight:500}.requests-list{display:flex;flex-direction:column;gap:8px}.request-card{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;padding:16px}.request-card.error{border-color:#ff47574d}.request-card.success{border-color:#00ff884d}.request-header{display:flex;align-items:center;gap:12px;margin-bottom:8px}.request-method{padding:2px 6px;border-radius:3px;font-size:10px;font-weight:600;text-transform:uppercase}.request-method.get{background:#0f83;color:#0f8}.request-method.post{background:#3c7dff33;color:#3c7dff}.request-method.put{background:#ffc10733;color:#ffc107}.request-method.delete{background:#ff475733;color:#ff4757}.request-url{flex:1;color:#ccc;font-family:SF Mono,monospace;font-size:12px}.request-status{padding:2px 6px;border-radius:3px;font-size:10px;font-weight:600}.request-status.status-2xx{background:#0f83;color:#0f8}.request-status.status-4xx,.request-status.status-5xx{background:#ff475733;color:#ff4757}.request-time{color:#888;font-size:11px;font-family:SF Mono,monospace}.request-timestamp{color:#666;font-size:11px;margin-bottom:8px}.request-details summary{cursor:pointer;color:#3c7dff;font-size:12px;margin-top:8px}.request-data,.response-data{margin-top:12px}.request-data h4,.response-data h4{margin:0 0 8px;color:#fff;font-size:12px}.event-types{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px}.event-type-card{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:6px;padding:12px;text-align:center;cursor:pointer;transition:all .2s ease}.event-type-card:hover{border-color:#3c7dff;box-shadow:0 2px 8px #3c7dff1a}.event-type-name{font-size:12px;color:#fff;font-weight:500}.event-type-count{font-size:16px;color:#3c7dff;font-weight:700;margin-top:4px}.events-timeline{display:flex;flex-direction:column;gap:12px}.timeline-event{display:flex;gap:16px;background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;padding:16px}.event-time{color:#888;font-size:11px;font-family:SF Mono,monospace;white-space:nowrap;width:80px}.event-content{flex:1}.event-header{display:flex;align-items:center;gap:8px;margin-bottom:4px}.event-type-badge{background:#3c7dff;color:#fff;padding:2px 6px;border-radius:3px;font-size:10px;font-weight:600;text-transform:uppercase}.event-source{color:#888;font-size:10px;text-transform:uppercase;font-weight:500}.event-data-preview{color:#ccc;font-size:12px;font-family:SF Mono,monospace}.event-item{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;padding:16px;margin-bottom:12px;transition:all .2s ease}.event-item:hover{border-color:#3c7dff;box-shadow:0 4px 12px #3c7dff1a}.event-item .event-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}.event-type{background:#3c7dff;color:#fff;padding:4px 8px;border-radius:4px;font-size:10px;font-weight:600;text-transform:uppercase}.event-data{background:#0f0f0f;border-radius:4px;padding:12px;font-family:SF Mono,monospace;font-size:11px;color:#ccc;max-height:120px;overflow-y:auto}.debug-mini-cart-display{position:fixed;top:20px;right:20px;background:#000000f2;border:1px solid #333;border-radius:8px;padding:0;min-width:300px;max-width:350px;box-shadow:0 8px 32px #00000080;font-family:SF Mono,monospace;font-size:12px;color:#ccc;z-index:10000;display:none;overflow:hidden}.debug-mini-cart-display.show{display:block;pointer-events:auto}.debug-mini-cart-header{background:linear-gradient(135deg,#1a1a1a,#111);padding:12px 16px;border-bottom:1px solid #333;display:flex;justify-content:space-between;align-items:center;font-weight:600;color:#3c7dff}.debug-mini-cart-header span{display:flex;align-items:center;gap:8px}.mini-cart-close{background:transparent;border:none;color:#888;font-size:20px;cursor:pointer;padding:0;width:24px;height:24px;display:flex;align-items:center;justify-content:center;border-radius:4px;transition:all .2s ease}.mini-cart-close:hover{background:#ff475733;color:#ff4757}.debug-mini-cart-empty{padding:40px 20px;text-align:center;color:#666;font-style:italic}.debug-mini-cart-items{max-height:280px;overflow-y:auto;padding:8px;position:relative}.debug-mini-cart-resize-handle{height:8px;cursor:ns-resize;display:flex;align-items:center;justify-content:center;border-top:1px solid rgba(255,255,255,.06);border-radius:0 0 8px 8px;flex-shrink:0;user-select:none;transition:background .15s}.debug-mini-cart-resize-handle:hover,.debug-mini-cart-resize-handle.dragging{background:#ffffff0d}.debug-mini-cart-resize-handle:after{content:"";width:28px;height:3px;background:#ffffff26;border-radius:2px;transition:background .15s}.debug-mini-cart-resize-handle:hover:after,.debug-mini-cart-resize-handle.dragging:after{background:#ffffff59}.debug-mini-cart-item{background:#ffffff08;border:1px solid rgba(255,255,255,.05);border-radius:6px;padding:12px;margin-bottom:8px;transition:all .2s ease;position:relative}.debug-mini-cart-item:hover{background:#3c7dff0d;border-color:#3c7dff33;cursor:pointer}.debug-mini-cart-item.has-discount:hover:before{opacity:1}.debug-mini-cart-item:last-child{margin-bottom:0}.mini-cart-item-header{margin-bottom:8px}.mini-cart-item-title-row{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:6px}.mini-cart-item-meta{display:flex;align-items:center;gap:6px;flex-wrap:wrap}.mini-cart-item-info{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;flex-wrap:wrap;gap:4px}.mini-cart-item-id{color:#666;font-weight:400;font-size:9px;text-transform:uppercase;letter-spacing:.5px;opacity:.7}.mini-cart-item-qty{color:#fff;font-weight:600;font-size:11px;background:#ffffff1a;padding:2px 8px;border-radius:4px}.mini-cart-upsell-badge{background:#ff4757;color:#fff;padding:1px 4px;border-radius:3px;font-size:9px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;margin:0 4px}.mini-cart-item-properties{display:flex;flex-direction:column;gap:3px;margin-top:6px}.mini-cart-property-tag{display:flex;align-items:center;gap:0;border-radius:3px;overflow:hidden;font-size:9px;line-height:1}.mini-cart-property-key{background:#2d4a7a;color:#90b8f8;padding:2px 5px;font-weight:600;text-transform:uppercase;letter-spacing:.4px}.mini-cart-property-value{background:#ffffff14;color:#e0e0e0;padding:2px 5px}.mini-cart-item-discount-badge{background:#0f83;color:#0f8;padding:2px 6px;border-radius:3px;font-size:9px;font-weight:600;letter-spacing:.3px;margin:0 4px;border:1px solid rgba(0,255,136,.3);white-space:nowrap}.debug-mini-cart-item.has-discount{border-color:#0f83;background:#00ff8805}.mini-cart-item-title{color:#fff;font-size:14px;font-weight:600;flex:1;line-height:1.4}.mini-cart-item-price-breakdown{display:flex;flex-direction:column;gap:6px;margin-top:12px;padding-top:12px;border-top:1px solid rgba(255,255,255,.08)}.mini-cart-price-row{display:flex;justify-content:space-between;align-items:baseline;gap:12px}.mini-cart-sale-row{font-size:15px}.mini-cart-savings-row{padding-top:4px;border-top:1px solid rgba(0,255,136,.15);margin-top:4px}.mini-cart-price-label{color:#aaa;font-size:11px;font-weight:400;text-transform:capitalize;letter-spacing:0}.mini-cart-item-pricing{display:flex;justify-content:space-between;align-items:flex-end;gap:12px;margin-top:4px}.mini-cart-price-details{display:flex;flex-direction:column;gap:4px;flex:1}.mini-cart-original-price{text-decoration:line-through;color:#888;font-size:12px;font-weight:400}.mini-cart-unit-price{color:#fff;font-weight:700;font-size:13px}.mini-cart-item-discount-list{display:none}.mini-cart-discount-details-card{position:fixed;width:240px;background:#000000fa;border:1px solid rgba(0,255,136,.3);border-radius:8px;padding:16px;box-shadow:0 8px 32px #0009,0 0 0 1px #00ff881a;z-index:10001;opacity:0;visibility:hidden;transition:opacity .25s ease,visibility 0s linear .25s;pointer-events:none;white-space:normal}.debug-mini-cart-item:hover .mini-cart-discount-details-card{opacity:1;visibility:visible;transition:opacity .25s ease,visibility 0s}.discount-card-header{display:flex;align-items:center;gap:8px;margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid rgba(0,255,136,.2)}.discount-card-header--separator{margin-top:14px;padding-top:14px;border-top:1px solid rgba(255,255,255,.08)}.discount-card-icon{font-size:16px}.discount-card-title{color:#0f8;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.5px}.discount-card-list{display:flex;flex-direction:column;gap:10px;list-style:none;padding:0;margin:0}.discount-card-item{display:flex;align-items:flex-start;gap:8px;padding:8px;background:#00ff880d;border-radius:6px;border:1px solid rgba(0,255,136,.15)}.discount-card-bullet{color:#0f8;font-weight:700;font-size:10px;margin-top:2px;flex-shrink:0}.discount-card-text{color:#ccc;font-size:11px;line-height:1.5}.discount-card-empty{color:#666;font-size:11px;font-style:italic;text-align:center;padding:12px 0}.mini-cart-savings-amount{color:#0f8;font-weight:700;font-size:12px}.prop-card-item{display:flex;flex-direction:row;align-items:flex-start;gap:8px;padding:6px 8px;background:#90b8f80d;border-radius:5px;border:1px solid rgba(144,184,248,.15)}.prop-card-body{display:flex;flex-direction:column;gap:2px;min-width:0}.prop-card-key{font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:#888}.prop-card-value{font-size:11px;color:#90b8f8;word-break:break-word;line-height:1.4}.mini-cart-line-total{color:#fff;font-weight:700;font-size:18px;white-space:nowrap;align-self:flex-start;line-height:1.4}.debug-mini-cart-totals{background:#ffffff05;border-top:1px solid #333;border-bottom:1px solid #333;padding:14px 16px;display:flex;flex-direction:column;gap:6px}.mini-cart-total-row{display:flex;justify-content:space-between;align-items:center;font-size:13px;color:#ccc}.mini-cart-total-row span:first-child{color:#aaa;font-weight:400}.mini-cart-total-row span:last-child{font-weight:600;color:#fff;font-size:14px}.mini-cart-discount-row{color:#0f8;font-size:12px}.mini-cart-discount-row span:first-child{color:#0f8;font-weight:400}.mini-cart-discount-row span:last-child{color:#0f8;font-weight:700;font-size:13px}.mini-cart-discount-label{display:flex;align-items:center;gap:6px;flex:1}.mini-cart-discount-type{background:#0f83;color:#0f8;padding:2px 5px;border-radius:3px;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.5px;flex-shrink:0}.mini-cart-discount-separator{color:#666;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.5px;padding:8px 0 4px;margin-top:4px;border-top:1px solid rgba(0,255,136,.15)}.mini-cart-cart-discount-popup{position:relative}.debug-mini-cart-totals.has-cart-discounts{position:relative;cursor:pointer}.debug-mini-cart-totals.has-cart-discounts:hover .mini-cart-discount-details-card{opacity:1;visibility:visible;transition:opacity .25s ease,visibility 0s}.mini-cart-shipping-prices{display:flex;align-items:center;gap:8px}.mini-cart-shipping-prices .mini-cart-original-price{color:#666;text-decoration:line-through;font-size:13px;font-weight:400}.mini-cart-shipping-prices .mini-cart-shipping{color:#3c7dff!important;font-size:14px;font-weight:700}.mini-cart-shipping{color:#3c7dff!important}.mini-cart-final-total{margin-top:6px;padding-top:10px;border-top:2px solid rgba(255,255,255,.15);font-size:14px}.mini-cart-final-total span:first-child{color:#fff;font-weight:700;font-size:15px}.mini-cart-final-total .mini-cart-total{color:#0f8!important;font-size:18px;font-weight:700}.debug-mini-cart-footer{background:linear-gradient(135deg,#1a1a1a,#111);padding:10px 16px;display:flex;justify-content:center;align-items:center}.mini-cart-stat{display:flex;align-items:center;gap:6px}.mini-cart-stat span:first-child{color:#888;font-size:11px}.mini-cart-stat span:last-child{color:#fff;font-weight:600}.debug-mini-cart-items::-webkit-scrollbar{width:6px}.debug-mini-cart-items::-webkit-scrollbar-track{background:#ffffff05;border-radius:3px}.debug-mini-cart-items::-webkit-scrollbar-thumb{background:#3c7dff4d;border-radius:3px}.debug-mini-cart-items::-webkit-scrollbar-thumb:hover{background:#3c7dff80}';
const campaignCSS = ".campaign-overview{background:linear-gradient(135deg,#2a2a2a,#1a1a1a);border:1px solid #333;border-radius:12px;padding:24px;margin-bottom:24px}.campaign-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:20px}.campaign-name{margin:0;font-size:24px;font-weight:700;color:#fff;background:linear-gradient(135deg,#3c7dff,#00d4ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}.campaign-badges{display:flex;gap:8px}.campaign-badge{padding:4px 8px;border-radius:6px;font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.5px}.campaign-badge.currency{background:#3c7dff33;color:#3c7dff}.campaign-badge.language{background:#0f83;color:#0f8}.packages-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:20px;margin-bottom:32px}.package-card{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:12px;overflow:hidden;transition:all .3s ease;position:relative}.package-card:hover{border-color:#3c7dff;box-shadow:0 8px 32px #3c7dff1a;transform:translateY(-2px)}.package-card.in-cart{border-color:#0f8;background:linear-gradient(135deg,#00ff881a,#1a1a1a)}.package-image-container{position:relative;height:140px;background:#f8f9fa;display:flex;align-items:center;justify-content:center;overflow:hidden}.package-image{max-width:100%;max-height:100%;object-fit:contain}.recurring-badge,.cart-badge{position:absolute;top:8px;right:8px;background:#3c7dff;color:#fff;padding:4px 8px;border-radius:12px;font-size:10px;font-weight:600}.cart-badge{background:#0f8;color:#000;top:8px;left:8px}.package-info{padding:16px}.package-header{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px}.package-name{margin:0;font-size:16px;font-weight:600;color:#fff;line-height:1.3}.package-id{font-size:11px;color:#888;font-family:SF Mono,monospace}.package-details{display:flex;gap:16px;margin-bottom:12px;font-size:12px;color:#888}.package-pricing{margin-bottom:16px}.price-row{display:flex;justify-content:space-between;align-items:center;margin-bottom:4px}.price-label{font-size:12px;color:#888}.price-value{font-weight:600;font-family:SF Mono,monospace}.sale-price{color:#3c7dff;font-size:16px}.retail-price{color:#888;text-decoration:line-through}.recurring-price{color:#ff6b6b}.savings{background:#00ff881a;color:#0f8;padding:4px 8px;border-radius:6px;font-size:11px;font-weight:600;text-align:center;margin-top:8px}.recurring-pricing{border-top:1px solid #333;padding-top:8px;margin-top:8px}.package-actions{display:flex;gap:8px;align-items:center}.package-btn{padding:8px 12px;border:none;border-radius:6px;font-size:12px;font-weight:500;cursor:pointer;transition:all .2s ease;flex:1}.add-btn{background:#3c7dff;color:#fff}.add-btn:hover{background:#2563eb}.remove-btn{background:#ff47571a;color:#ff4757;border:1px solid rgba(255,71,87,.3)}.remove-btn:hover{background:#ff475733}.inspect-btn{background:#ffffff1a;color:#ccc;border:1px solid #333;flex:0 0 auto}.inspect-btn:hover{background:#ffffff26;color:#fff}.qty-controls{display:flex;align-items:center;gap:8px;flex:0 0 auto}.qty-controls button{width:24px;height:24px;border:1px solid #333;background:#ffffff0d;color:#fff;border-radius:4px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-weight:600}.qty-controls span{font-weight:600;color:#3c7dff;min-width:20px;text-align:center}.shipping-methods{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:16px;margin-bottom:24px}.shipping-method-card{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;padding:16px;display:flex;align-items:center;gap:16px;transition:all .2s ease}.shipping-method-card:hover{border-color:#3c7dff;box-shadow:0 4px 12px #3c7dff1a}.shipping-info{flex:1}.shipping-name{font-size:16px;font-weight:600;color:#fff;margin-bottom:4px}.shipping-id{font-size:11px;color:#888;font-family:SF Mono,monospace}.shipping-price{font-size:18px;font-weight:700;color:#3c7dff;font-family:SF Mono,monospace}.shipping-test-btn{background:#3c7dff1a;border:1px solid #3C7DFF;color:#3c7dff;padding:8px 16px;border-radius:6px;font-size:12px;font-weight:500;cursor:pointer;transition:all .2s ease}.shipping-test-btn:hover{background:#3c7dff33}.raw-data-section{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;overflow:hidden}.raw-data-summary{padding:16px;cursor:pointer;display:flex;align-items:center;justify-content:space-between;user-select:none}.raw-data-summary:hover{background:#ffffff0d}.toggle-icon{color:#888;transition:transform .2s ease}.raw-data-section[open] .toggle-icon{transform:rotate(180deg)}.raw-data-section .json-viewer{border-top:1px solid #333;margin:0}@media (max-width: 768px){.packages-grid,.shipping-methods{grid-template-columns:1fr}.campaign-header{flex-direction:column;align-items:flex-start;gap:12px}.package-card{margin-bottom:16px}.package-actions{flex-direction:column;gap:8px}.package-btn{width:100%}}";
const panelComponentsCSS = ".enhanced-panel{display:flex;flex-direction:column;gap:24px}.metrics-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:16px}.metric-card{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;padding:16px;display:flex;align-items:center;gap:12px;transition:all .2s ease}.metric-card:hover{border-color:#3c7dff;box-shadow:0 4px 12px #3c7dff1a}.metric-icon{font-size:20px;width:32px;text-align:center}.metric-content{flex:1}.metric-value{font-size:18px;font-weight:700;color:#3c7dff;line-height:1}.metric-label{font-size:11px;color:#888;text-transform:uppercase;font-weight:500;letter-spacing:.5px;margin-top:2px}.section{display:flex;flex-direction:column;gap:16px}.section-title{font-size:16px;font-weight:600;color:#fff;margin:0;padding-bottom:8px;border-bottom:1px solid #333}.empty-state{display:flex;flex-direction:column;align-items:center;gap:12px;padding:40px 20px;color:#888;text-align:center}.empty-icon{font-size:32px;opacity:.5}.empty-text{font-size:14px}.empty-action{background:#3c7dff;color:#fff;border:none;padding:8px 16px;border-radius:6px;cursor:pointer;font-size:12px;font-weight:500}.config-groups{display:flex;flex-direction:column;gap:24px}.config-group{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;padding:20px}.config-group-title{font-size:14px;font-weight:600;color:#fff;margin:0 0 16px;padding-bottom:8px;border-bottom:1px solid #333}.config-items{display:flex;flex-direction:column;gap:12px}.config-item{display:flex;justify-content:space-between;align-items:center;padding:8px 0}.config-key{font-size:12px;color:#ccc;font-weight:500}.config-value{font-size:12px;color:#fff;font-family:SF Mono,monospace}.config-value.enabled{color:#0f8}.config-value.disabled{color:#888}.form-fields-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:12px}.field-status-card{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:6px;padding:12px;text-align:center;transition:all .2s ease}.field-status-card.filled{border-color:#00ff884d;background:linear-gradient(135deg,#00ff881a,#1a1a1a)}.field-status-card.error{border-color:#ff47574d;background:linear-gradient(135deg,#ff47571a,#1a1a1a)}.field-name{font-size:11px;color:#ccc;font-weight:500;margin-bottom:4px}.field-status{font-size:14px}.customer-info{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px}.info-card{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;padding:16px}.info-card h4{margin:0 0 12px;font-size:14px;color:#fff;font-weight:600}.info-row{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px}.info-label{font-size:12px;color:#888}.info-value{font-size:12px;color:#fff;font-family:SF Mono,monospace}.info-empty{color:#666;font-style:italic;font-size:12px}.address-info,.validation-errors{display:flex;flex-direction:column;gap:8px}.error-item{background:linear-gradient(135deg,#ff47571a,#1a1a1a);border:1px solid rgba(255,71,87,.3);border-radius:6px;padding:12px;display:flex;gap:8px}.error-field{font-weight:600;color:#ff4757;font-size:12px}.error-message{color:#ccc;font-size:12px}.storage-items{display:flex;flex-direction:column;gap:12px}.storage-item-card{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;padding:16px;transition:all .2s ease}.storage-item-card.next-item{border-color:#3c7dff4d;background:linear-gradient(135deg,#3c7dff0d,#1a1a1a)}.storage-item-header{display:flex;align-items:center;gap:12px;margin-bottom:8px}.storage-key{flex:1;font-family:SF Mono,monospace;font-size:12px;color:#fff;font-weight:500}.storage-type{padding:2px 6px;border-radius:3px;font-size:10px;font-weight:600;text-transform:uppercase}.storage-type.local{background:#0f83;color:#0f8}.storage-type.session{background:#ffc10733;color:#ffc107}.storage-delete-btn{width:20px;height:20px;border:1px solid rgba(255,71,87,.3);background:#ff47571a;color:#ff4757;border-radius:3px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-weight:600;font-size:12px}.storage-delete-btn:hover{background:#ff475733}.storage-item-size{font-size:10px;color:#666;margin-bottom:8px}.storage-item-value{background:#0f0f0f;border:1px solid #333;border-radius:4px;overflow:hidden}.storage-item-value pre{margin:0;padding:12px;overflow-x:auto;font-family:SF Mono,monospace;font-size:11px;line-height:1.4;color:#e6e6e6;max-height:200px;overflow-y:auto}.json-viewer{background:#0f0f0f;border:1px solid #333;border-radius:8px;overflow:hidden}.json-viewer pre{margin:0;padding:16px;overflow-x:auto;font-family:SF Mono,monospace;font-size:12px;line-height:1.6;color:#e6e6e6;max-height:400px;overflow-y:auto}.analytics-charts{display:flex;flex-direction:column;gap:12px}.analytics-bar{display:flex;flex-direction:column;gap:4px}.bar-label{font-size:12px;color:#ccc;font-weight:500}.bar-container{position:relative;background:#0f0f0f;border:1px solid #333;border-radius:4px;height:24px;overflow:hidden}.bar-fill{background:linear-gradient(90deg,#3c7dff,#2563eb);height:100%;transition:width .3s ease}.bar-value{position:absolute;right:8px;top:50%;transform:translateY(-50%);font-size:11px;color:#fff;font-weight:500}.source-stats{display:flex;flex-direction:column;gap:8px}.source-stat-item{display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:6px}.source-name{font-size:12px;color:#ccc}.source-count{font-size:12px;color:#3c7dff;font-weight:600}.method-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px}.method-stat-card{background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:8px;padding:16px}.method-name{font-size:14px;font-weight:600;color:#fff;margin-bottom:8px}.method-metrics{display:flex;flex-direction:column;gap:4px}.method-metrics .metric{font-size:11px;color:#888}.performance-chart{display:flex;flex-direction:column;gap:8px}.performance-bar{display:flex;flex-direction:column;gap:4px}.enhancer-distribution{display:flex;flex-direction:column;gap:8px}.enhancer-dist-item{display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:6px}.enhancer-type{font-size:12px;color:#ccc}.enhancer-count{font-size:12px;color:#3c7dff;font-weight:600}.performance-metrics{display:flex;flex-direction:column;gap:12px}.performance-metric{display:flex;justify-content:space-between;align-items:center;padding:12px;background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:6px}.enhancement-timeline{display:flex;flex-direction:column;gap:8px}.timeline-item{display:flex;gap:16px;padding:8px 12px;background:linear-gradient(135deg,#222,#1a1a1a);border:1px solid #333;border-radius:6px}.timeline-time{font-size:11px;color:#888;font-family:SF Mono,monospace;min-width:60px}.timeline-event{font-size:12px;color:#ccc}@media (max-width: 768px){.metrics-grid,.form-fields-grid{grid-template-columns:repeat(2,1fr)}.customer-info{grid-template-columns:1fr}.config-groups{gap:16px}.storage-items{gap:8px}.method-stats{grid-template-columns:1fr}}";
const eventTimelineCSS = ".timeline-header{display:flex;justify-content:space-between;align-items:center;padding:12px 16px;background:#f8f9fa;border-bottom:1px solid #e9ecef;border-radius:4px 4px 0 0;margin-bottom:12px}.timeline-stats{display:flex;gap:16px}.timeline-stat{display:flex;flex-direction:column;align-items:center;font-size:11px}.timeline-stat-label{color:#6c757d;margin-bottom:2px}.timeline-stat-value{font-weight:600;color:#495057}.timeline-stat-value.recording{color:#28a745}.timeline-stat-value.paused{color:#dc3545}.timeline-controls{display:flex;gap:8px}.timeline-control-btn{padding:6px 12px;border:1px solid #dee2e6;border-radius:3px;background:#fff;font-size:11px;cursor:pointer;transition:all .2s}.timeline-control-btn:hover{background:#f8f9fa;transform:translateY(-1px)}.timeline-control-btn.record{background:#28a745;color:#fff;border-color:#28a745}.timeline-control-btn.pause{background:#ffc107;color:#212529;border-color:#ffc107}.timeline-control-btn.clear{background:#dc3545;color:#fff;border-color:#dc3545}.timeline-control-btn.export{background:#007bff;color:#fff;border-color:#007bff}.timeline-events{max-height:500px;overflow-y:auto;padding:0 4px}.timeline-event{background:#fff;border:1px solid #e9ecef;border-radius:4px;margin-bottom:8px;transition:all .2s;position:relative}.timeline-event:hover{box-shadow:0 2px 8px #0000001a;transform:translateY(-1px)}.timeline-event-header{padding:8px 12px;border-bottom:1px solid #f8f9fa;display:flex;justify-content:space-between;align-items:center}.timeline-event-meta{display:flex;align-items:center;gap:8px;font-size:11px}.timeline-event-icon{font-size:14px}.timeline-event-type{font-weight:600;text-transform:uppercase;letter-spacing:.5px}.timeline-event-time{color:#6c757d;font-style:italic}.timeline-event-name{font-weight:600;color:#495057;font-size:13px}.timeline-event-details{padding:8px 12px;font-size:11px}.timeline-event-source{color:#6c757d;margin-bottom:8px}.timeline-event-data-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:4px}.timeline-toggle-data{background:none;border:1px solid #dee2e6;border-radius:2px;padding:2px 6px;font-size:10px;cursor:pointer;color:#007bff}.timeline-toggle-data:hover{background:#f8f9fa}.timeline-event-data-content{background:#f8f9fa;border:1px solid #e9ecef;border-radius:3px;padding:8px;margin:4px 0;font-family:Monaco,Consolas,monospace;font-size:10px;line-height:1.4;max-height:200px;overflow-y:auto}.timeline-event-data-preview{background:#f8f9fa;border:1px solid #e9ecef;border-radius:3px;padding:6px;font-family:Monaco,Consolas,monospace;font-size:10px;color:#6c757d;white-space:pre-wrap;word-break:break-all}.timeline-empty{text-align:center;padding:40px 20px;color:#6c757d}.timeline-empty-icon{font-size:48px;margin-bottom:16px}.timeline-empty-title{font-size:16px;font-weight:600;margin-bottom:8px;color:#495057}.timeline-empty-subtitle{font-size:13px}.analytics-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:12px}.analytics-card{background:#fff;border:1px solid #e9ecef;border-radius:4px;padding:12px}.analytics-card-full{grid-column:1 / -1}.analytics-card-title{font-weight:600;margin-bottom:12px;color:#495057;font-size:13px;border-bottom:1px solid #f8f9fa;padding-bottom:6px}.analytics-stats{display:flex;flex-direction:column;gap:8px}.analytics-stat{display:flex;justify-content:space-between;font-size:11px}.analytics-stat-label{color:#6c757d}.analytics-stat-value{font-weight:600;color:#495057}.analytics-distribution{display:flex;flex-direction:column;gap:6px}.analytics-distribution-item{display:flex;align-items:center;gap:8px;font-size:11px}.analytics-distribution-bar{flex:1;height:16px;background:#f8f9fa;border-radius:8px;overflow:hidden;position:relative}.analytics-distribution-fill{height:100%;border-radius:8px;transition:width .3s ease}.analytics-distribution-label{min-width:80px;color:#495057;font-weight:500}.analytics-sources{display:flex;flex-direction:column;gap:4px;max-height:200px;overflow-y:auto}.analytics-source-item{display:flex;justify-content:space-between;padding:4px 8px;background:#f8f9fa;border-radius:3px;font-size:11px}.analytics-source-name{color:#495057;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.analytics-source-count{color:#6c757d;font-weight:600;min-width:20px;text-align:right}.timeline-chart{display:flex;align-items:end;gap:4px;height:100px;padding:8px;background:#f8f9fa;border-radius:4px}.timeline-chart-bar{flex:1;background:linear-gradient(to top,#007bff,#66b3ff);border-radius:2px 2px 0 0;min-height:2px;position:relative;cursor:pointer;transition:all .2s}.timeline-chart-bar:hover{opacity:.8;transform:scaleY(1.1)}.timeline-chart-value{position:absolute;top:-16px;left:50%;transform:translate(-50%);font-size:9px;color:#495057;font-weight:600;opacity:0;transition:opacity .2s}.timeline-chart-bar:hover .timeline-chart-value{opacity:1}.filters-container{padding:12px;display:flex;flex-direction:column;gap:16px}.filter-group{border:1px solid #e9ecef;border-radius:4px;padding:12px;background:#fff}.filter-group-title{font-weight:600;margin-bottom:8px;color:#495057;font-size:12px}.filter-search-input{width:100%;padding:6px 8px;border:1px solid #dee2e6;border-radius:3px;font-size:11px}.filter-search-input:focus{outline:none;border-color:#007bff;box-shadow:0 0 0 2px #007bff40}.filter-checkboxes{display:flex;flex-direction:column;gap:6px}.filter-checkbox{display:flex;align-items:center;gap:6px;font-size:11px;cursor:pointer;padding:4px;border-radius:3px;transition:background .2s}.filter-checkbox:hover{background:#f8f9fa}.filter-checkbox input[type=checkbox]{margin:0}.filter-checkbox-icon{font-size:14px}.filter-checkbox-label{color:#495057}.filter-sources-list{max-height:150px;overflow-y:auto;border:1px solid #e9ecef;border-radius:3px;padding:4px}.filter-empty{color:#6c757d;font-style:italic;text-align:center;padding:12px;font-size:11px}.filter-time-range{width:100%;padding:6px 8px;border:1px solid #dee2e6;border-radius:3px;font-size:11px;background:#fff}.filter-controls{display:flex;gap:8px}.filter-control-btn{flex:1;padding:8px 12px;border:1px solid #dee2e6;border-radius:3px;background:#fff;font-size:11px;cursor:pointer;transition:all .2s}.filter-control-btn:hover{background:#f8f9fa;transform:translateY(-1px)}@media (max-width: 768px){.timeline-header{flex-direction:column;gap:12px;align-items:stretch}.timeline-stats{justify-content:space-around}.analytics-grid{grid-template-columns:1fr}.filter-controls{flex-direction:column}}@keyframes eventAdded{0%{opacity:0;transform:translate(-20px)}to{opacity:1;transform:translate(0)}}.timeline-event.new{animation:eventAdded .3s ease-out}.timeline-events::-webkit-scrollbar,.analytics-sources::-webkit-scrollbar,.filter-sources-list::-webkit-scrollbar{width:6px}.timeline-events::-webkit-scrollbar-track,.analytics-sources::-webkit-scrollbar-track,.filter-sources-list::-webkit-scrollbar-track{background:#f8f9fa;border-radius:3px}.timeline-events::-webkit-scrollbar-thumb,.analytics-sources::-webkit-scrollbar-thumb,.filter-sources-list::-webkit-scrollbar-thumb{background:#dee2e6;border-radius:3px}.timeline-events::-webkit-scrollbar-thumb:hover,.analytics-sources::-webkit-scrollbar-thumb:hover,.filter-sources-list::-webkit-scrollbar-thumb:hover{background:#adb5bd}";
const _DebugStyleLoader = class _DebugStyleLoader {
  static async loadDebugStyles() {
    if (this.isLoading || this.styleElement) return;
    this.isLoading = true;
    try {
      const combinedCSS = await this.getDebugStyles();
      this.styleElement = document.createElement("style");
      this.styleElement.id = "debug-overlay-styles";
      this.styleElement.textContent = combinedCSS;
      document.head.appendChild(this.styleElement);
      console.log("🎨 Debug styles injected");
    } catch (error) {
      console.error("Failed to load debug styles:", error);
    } finally {
      this.isLoading = false;
    }
  }
  static async getDebugStyles() {
    return [
      baseCSS,
      sidebarCSS,
      panelsCSS,
      componentsCSS,
      campaignCSS,
      panelComponentsCSS,
      eventTimelineCSS
    ].join("\n");
  }
  static removeDebugStyles() {
    if (this.styleElement) {
      this.styleElement.remove();
      this.styleElement = null;
    }
    const existingStyle = document.getElementById("debug-overlay-styles");
    if (existingStyle) {
      existingStyle.remove();
    }
  }
};
_DebugStyleLoader.styleElement = null;
_DebugStyleLoader.isLoading = false;
let DebugStyleLoader = _DebugStyleLoader;
const DebugStyleLoader$1 = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  DebugStyleLoader
});
export {
  CountryService as C,
  DebugOverlay$1 as D,
  analyticsDebug as a,
  formatPercentage as b,
  formatDiscountPercentage as c,
  formatNumber as d,
  CurrencyFormatter as e,
  formatCurrency as f
};
