import { B as BaseEnhancer } from "./index-BJv5I91y.js";
import { c as configStore, u as useCampaignStore, a as useCartStore } from "./analytics-CkSoSSCD.js";
import { u as useCheckoutStore } from "./debug-UN6FtqbN.js";
import { ApiClient } from "./api-q-kVSjlU.js";
import { O as OrderManager, E as ExpressCheckoutProcessor } from "./OrderManager-DJBbORDe.js";
import { L as LoadingOverlay } from "./LoadingOverlay-DOjYiQnB.js";
import { m as getPaymentCapabilities, n as isApplePayAvailable, o as isGooglePayAvailable, p as isPayPalAvailable } from "./utils-Be4BSRfm.js";
const PAYPAL_SVG = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="86px" height="22px" viewBox="0 0 86 22" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <title>paypal</title>
  <g id="-Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
    <g id="express-checkout-cta" transform="translate(-204.000000, -15.000000)" fill-rule="nonzero">
      <g id="paypal" transform="translate(204.000000, 15.000000)">
        <path d="M66.4793651,5.73913043 L61.8380952,5.73913043 C61.5650794,5.73913043 61.2920635,6.01242236 61.1555556,6.28571429 L59.2444444,18.310559 C59.2444444,18.5838509 59.3809524,18.7204969 59.6539683,18.7204969 L62.1111111,18.7204969 C62.384127,18.7204969 62.5206349,18.5838509 62.5206349,18.310559 L63.0666667,14.8944099 C63.0666667,14.621118 63.3396825,14.3478261 63.7492063,14.3478261 L65.2507937,14.3478261 C68.3904762,14.3478261 70.1650794,12.8447205 70.5746032,9.83850932 C70.847619,8.60869565 70.5746032,7.51552795 70.0285714,6.83229814 C69.2095238,6.14906832 67.9809524,5.73913043 66.4793651,5.73913043 M67.0253968,10.2484472 C66.752381,11.8881988 65.5238095,11.8881988 64.2952381,11.8881988 L63.4761905,11.8881988 L64.0222222,8.74534161 C64.0222222,8.60869565 64.1587302,8.47204969 64.431746,8.47204969 L64.7047619,8.47204969 C65.5238095,8.47204969 66.3428571,8.47204969 66.752381,9.01863354 C67.0253968,9.1552795 67.0253968,9.56521739 67.0253968,10.2484472" id="Shape" fill="#139AD6"></path>
        <g id="Group" transform="translate(25.800000, 5.739130)" fill="#263B80">
          <path d="M7.23492063,0 L2.59365079,0 C2.32063492,0 2.04761905,0.273291925 1.91111111,0.546583851 L0,12.5714286 C0,12.8447205 0.136507937,12.9813665 0.40952381,12.9813665 L2.59365079,12.9813665 C2.86666667,12.9813665 3.13968254,12.7080745 3.27619048,12.4347826 L3.82222222,9.1552795 C3.82222222,8.88198758 4.0952381,8.60869565 4.5047619,8.60869565 L6.00634921,8.60869565 C9.14603175,8.60869565 10.9206349,7.10559006 11.3301587,4.09937888 C11.6031746,2.86956522 11.3301587,1.77639752 10.784127,1.0931677 C9.96507937,0.409937888 8.87301587,0 7.23492063,0 M7.78095238,4.50931677 C7.50793651,6.14906832 6.27936508,6.14906832 5.05079365,6.14906832 L4.36825397,6.14906832 L4.91428571,3.00621118 C4.91428571,2.86956522 5.05079365,2.73291925 5.32380952,2.73291925 L5.5968254,2.73291925 C6.41587302,2.73291925 7.23492063,2.73291925 7.64444444,3.27950311 C7.78095238,3.41614907 7.91746032,3.82608696 7.78095238,4.50931677" id="Shape"></path>
          <path d="M21.2952381,4.37267081 L19.1111111,4.37267081 C18.9746032,4.37267081 18.7015873,4.50931677 18.7015873,4.64596273 L18.5650794,5.32919255 L18.4285714,5.05590062 C17.8825397,4.37267081 16.9269841,4.09937888 15.8349206,4.09937888 C13.3777778,4.09937888 11.1936508,6.01242236 10.784127,8.60869565 C10.5111111,9.97515528 10.9206349,11.2049689 11.6031746,12.0248447 C12.2857143,12.8447205 13.2412698,13.1180124 14.4698413,13.1180124 C16.5174603,13.1180124 17.6095238,11.8881988 17.6095238,11.8881988 L17.4730159,12.5714286 C17.4730159,12.8447205 17.6095238,12.9813665 17.8825397,12.9813665 L19.9301587,12.9813665 C20.2031746,12.9813665 20.4761905,12.7080745 20.6126984,12.4347826 L21.8412698,4.7826087 C21.7047619,4.64596273 21.431746,4.37267081 21.2952381,4.37267081 M18.1555556,8.74534161 C17.8825397,9.97515528 16.9269841,10.931677 15.5619048,10.931677 C14.8793651,10.931677 14.3333333,10.6583851 14.0603175,10.3850932 C13.7873016,9.97515528 13.6507937,9.42857143 13.6507937,8.74534161 C13.7873016,7.51552795 14.8793651,6.55900621 16.1079365,6.55900621 C16.7904762,6.55900621 17.2,6.83229814 17.6095238,7.10559006 C18.0190476,7.51552795 18.1555556,8.19875776 18.1555556,8.74534161" id="Shape"></path>
        </g>
        <path d="M80.4031746,10.1118012 L78.2190476,10.1118012 C78.0825397,10.1118012 77.8095238,10.2484472 77.8095238,10.3850932 L77.6730159,11.068323 L77.5365079,10.7950311 C76.9904762,10.1118012 76.0349206,9.83850932 74.9428571,9.83850932 C72.4857143,9.83850932 70.3015873,11.7515528 69.8920635,14.3478261 C69.6190476,15.7142857 70.0285714,16.9440994 70.7111111,17.7639752 C71.3936508,18.5838509 72.3492063,18.8571429 73.5777778,18.8571429 C75.6253968,18.8571429 76.7174603,17.6273292 76.7174603,17.6273292 L76.5809524,18.310559 C76.5809524,18.5838509 76.7174603,18.7204969 76.9904762,18.7204969 L79.0380952,18.7204969 C79.3111111,18.7204969 79.584127,18.447205 79.7206349,18.173913 L80.9492063,10.5217391 C80.8126984,10.3850932 80.6761905,10.1118012 80.4031746,10.1118012 M77.2634921,14.484472 C76.9904762,15.7142857 76.0349206,16.6708075 74.6698413,16.6708075 C73.9873016,16.6708075 73.4412698,16.3975155 73.168254,16.1242236 C72.8952381,15.7142857 72.7587302,15.1677019 72.7587302,14.484472 C72.8952381,13.2546584 73.9873016,12.2981366 75.215873,12.2981366 C75.8984127,12.2981366 76.3079365,12.5714286 76.7174603,12.8447205 C77.2634921,13.2546584 77.4,13.9378882 77.2634921,14.484472" id="Shape" fill="#139AD6"></path>
        <path d="M58.9714286,10.1118012 L56.6507937,10.1118012 C56.3777778,10.1118012 56.2412698,10.2484472 56.1047619,10.3850932 L53.1015873,15.0310559 L51.7365079,10.6583851 C51.6,10.3850932 51.4634921,10.2484472 51.0539683,10.2484472 L48.8698413,10.2484472 C48.5968254,10.2484472 48.4603175,10.5217391 48.4603175,10.7950311 L50.9174603,18.0372671 L48.5968254,21.3167702 C48.4603175,21.5900621 48.5968254,22 48.8698413,22 L51.0539683,22 C51.3269841,22 51.4634921,21.863354 51.6,21.7267081 L59.1079365,10.931677 C59.5174603,10.5217391 59.2444444,10.1118012 58.9714286,10.1118012" id="Path" fill="#263B80"></path>
        <path d="M82.9968254,6.14906832 L81.0857143,18.447205 C81.0857143,18.7204969 81.2222222,18.8571429 81.4952381,18.8571429 L83.4063492,18.8571429 C83.6793651,18.8571429 83.952381,18.5838509 84.0888889,18.310559 L86,6.28571429 C86,6.01242236 85.8634921,5.8757764 85.5904762,5.8757764 L83.4063492,5.8757764 C83.2698413,5.73913043 83.1333333,5.8757764 82.9968254,6.14906832" id="Path" fill="#139AD6"></path>
        <path d="M15.6984127,1.63975155 C14.7428571,0.546583851 12.968254,4.85463981e-15 10.5111111,4.85463981e-15 L3.68571429,4.85463981e-15 C3.27619048,4.85463981e-15 2.86666667,0.409937888 2.73015873,0.819875776 L0,18.7204969 C0,19.1304348 0.273015873,19.4037267 0.546031746,19.4037267 L4.77777778,19.4037267 L5.86984127,12.7080745 L5.86984127,12.9813665 C6.00634921,12.5714286 6.41587302,12.1614907 6.82539683,12.1614907 L8.87301587,12.1614907 C12.831746,12.1614907 15.8349206,10.5217391 16.7904762,6.01242236 C16.7904762,5.8757764 16.7904762,5.73913043 16.7904762,5.60248447 C16.6539683,5.60248447 16.6539683,5.60248447 16.7904762,5.60248447 C16.9269841,3.82608696 16.6539683,2.73291925 15.6984127,1.63975155" id="Path" fill="#263B80"></path>
        <path d="M16.6539683,5.60248447 L16.6539683,5.60248447 C16.6539683,5.73913043 16.6539683,5.8757764 16.6539683,6.01242236 C15.6984127,10.6583851 12.6952381,12.1614907 8.73650794,12.1614907 L6.68888889,12.1614907 C6.27936508,12.1614907 5.86984127,12.5714286 5.73333333,12.9813665 L4.36825397,21.3167702 C4.36825397,21.5900621 4.5047619,21.863354 4.91428571,21.863354 L8.46349206,21.863354 C8.87301587,21.863354 9.28253968,21.5900621 9.28253968,21.1801242 L9.28253968,21.0434783 L9.96507937,16.8074534 L9.96507937,16.5341615 C9.96507937,16.1242236 10.3746032,15.8509317 10.784127,15.8509317 L11.3301587,15.8509317 C14.7428571,15.8509317 17.4730159,14.484472 18.1555556,10.3850932 C18.4285714,8.74534161 18.2920635,7.24223602 17.4730159,6.28571429 C17.3365079,6.01242236 17.0634921,5.73913043 16.6539683,5.60248447" id="Path" fill="#139AD6"></path>
        <path d="M15.6984127,5.19254658 C15.5619048,5.19254658 15.4253968,5.05590062 15.2888889,5.05590062 C15.152381,5.05590062 15.015873,5.05590062 14.8793651,4.91925466 C14.3333333,4.7826087 13.7873016,4.7826087 13.1047619,4.7826087 L7.78095238,4.7826087 C7.64444444,4.7826087 7.50793651,4.7826087 7.37142857,4.91925466 C7.0984127,5.05590062 6.96190476,5.32919255 6.96190476,5.60248447 L5.86984127,12.7080745 L5.86984127,12.9813665 C6.00634921,12.5714286 6.41587302,12.1614907 6.82539683,12.1614907 L8.87301587,12.1614907 C12.831746,12.1614907 15.8349206,10.5217391 16.7904762,6.01242236 C16.7904762,5.8757764 16.7904762,5.73913043 16.9269841,5.60248447 C16.6539683,5.46583851 16.5174603,5.32919255 16.2444444,5.32919255 C15.8349206,5.19254658 15.8349206,5.19254658 15.6984127,5.19254658" id="Path" fill="#232C65"></path>
      </g>
    </g>
  </g>
</svg>`;
const APPLE_PAY_SVG = `<?xml version="1.0" encoding="UTF-8"?>
<svg id="Layer_1" xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="100%" height="100%" viewBox="0 0 512 252.2">
  <defs></defs>
  <path class="st0" fill="white" d="M93.6,69.1c-6,7.1-15.6,12.7-25.2,11.9-1.2-9.6,3.5-19.8,9-26.1,6-7.3,16.5-12.5,25-12.9,1,10-2.9,19.8-8.8,27.1M102.3,82.9c-13.9-.8-25.8,7.9-32.4,7.9s-16.8-7.5-27.8-7.3c-14.3.2-27.6,8.3-34.9,21.2-15,25.8-3.9,64,10.6,85,7.1,10.4,15.6,21.8,26.8,21.4,10.6-.4,14.8-6.9,27.6-6.9s16.6,6.9,27.8,6.7c11.6-.2,18.9-10.4,26-20.8,8.1-11.8,11.4-23.3,11.6-23.9-.2-.2-22.4-8.7-22.6-34.3-.2-21.4,17.5-31.6,18.3-32.2-10-14.8-25.6-16.4-31-16.8M182.6,53.9v155.9h24.2v-53.3h33.5c30.6,0,52.1-21,52.1-51.4s-21.1-51.2-51.3-51.2h-58.5ZM206.8,74.3h27.9c21,0,33,11.2,33,30.9s-12,31-33.1,31h-27.8v-61.9ZM336.6,211c15.2,0,29.3-7.7,35.7-19.9h.5v18.7h22.4v-77.6c0-22.5-18-37-45.7-37s-44.7,14.7-45.4,34.9h21.8c1.8-9.6,10.7-15.9,22.9-15.9s23.1,6.9,23.1,19.6v8.6l-30.2,1.8c-28.1,1.7-43.3,13.2-43.3,33.2s15.7,33.6,38.2,33.6ZM343.1,192.5c-12.9,0-21.1-6.2-21.1-15.7s7.9-15.5,23-16.4l26.9-1.7v8.8c0,14.6-12.4,25-28.8,25ZM425.1,252.2c23.6,0,34.7-9,44.4-36.3l42.5-119.2h-24.6l-28.5,92.1h-.5l-28.5-92.1h-25.3l41,113.5-2.2,6.9c-3.7,11.7-9.7,16.2-20.4,16.2s-5.6-.2-7.1-.4v18.7c1.4.4,7.4.6,9.2.6Z" />
</svg>`;
const GOOGLE_PAY_SVG = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 41 20.3" width="100%" height="100%">
  <path fill="#ffffff" fill-rule="evenodd" d="M19.5,5.9v4.1h2.5c.6,0,1.1-.2,1.5-.6.4-.4.6-.9.6-1.4s-.2-1-.6-1.4c-.4-.4-.9-.6-1.5-.6h-2.5ZM19.5,11.5v4.7h-1.5V4.5h4c1,0,1.9.3,2.6,1,.7.7,1.1,1.5,1.1,2.5s-.4,1.8-1.1,2.5c-.7.7-1.6,1-2.6,1h-2.5s0,0,0,0ZM27.2,13.7c0,.4.2.7.5,1,.3.3.7.4,1.2.4.6,0,1.2-.2,1.7-.7.5-.5.7-1,.7-1.6-.5-.4-1.1-.6-2-.6s-1.1.1-1.5.4c-.4.3-.6.7-.6,1.1M29.1,7.9c1.1,0,2,.3,2.6.9.6.6,1,1.4,1,2.4v4.9h-1.4v-1.1h0c-.6.9-1.5,1.4-2.5,1.4s-1.6-.3-2.2-.8c-.6-.5-.9-1.2-.9-2s.3-1.5.9-2,1.5-.7,2.5-.7,1.6.2,2.2.5v-.3c0-.5-.2-1-.6-1.3-.4-.4-.9-.6-1.5-.5-.8,0-1.5.4-2,1.1l-1.3-.8c.7-1,1.8-1.6,3.2-1.6M41,8.2l-5,11.5h-1.6l1.9-4-3.3-7.5h1.6l2.4,5.7h0l2.3-5.8h1.6Z" />
  <path fill="#4285f4" fill-rule="evenodd" d="M13.4,10.4c0-.5,0-.9-.1-1.4h-6.3v2.6h3.6c-.2.8-.6,1.6-1.3,2v1.7h2.2c1.3-1.2,2-2.9,2-4.9" />
  <path fill="#34a853" fill-rule="evenodd" d="M7,17c1.8,0,3.3-.6,4.5-1.6l-2.2-1.7c-.6.4-1.4.6-2.3.6-1.8,0-3.2-1.2-3.8-2.8H1v1.7c1.1,2.3,3.5,3.7,6,3.7" />
  <path fill="#fabb05" fill-rule="evenodd" d="M3.2,11.6c-.3-.8-.3-1.7,0-2.6v-1.7H1c-.5.9-.7,2-.7,3,0,1.1.3,2.1.7,3l2.2-1.7h0Z" />
  <path fill="#e94235" fill-rule="evenodd" d="M7,6.2c1,0,1.9.3,2.6,1h0s1.9-1.9,1.9-1.9c-1.2-1.1-2.7-1.7-4.5-1.7-2.5,0-4.9,1.4-6,3.7l2.2,1.7c.5-1.6,2-2.8,3.8-2.8" />
</svg>`;
class ExpressCheckoutContainerEnhancer extends BaseEnhancer {
  constructor(element) {
    super(element);
    this.buttonInstances = /* @__PURE__ */ new Map();
    this.buttonClickHandlers = /* @__PURE__ */ new Map();
    this.loadingOverlay = new LoadingOverlay();
  }
  async initialize() {
    this.validateElement();
    const containerType = this.getAttribute("data-next-express-checkout");
    if (containerType !== "container") {
      throw new Error("ExpressCheckoutContainerEnhancer can only be used on container elements");
    }
    const capabilities = getPaymentCapabilities();
    this.logger.info("Payment capabilities detected:", capabilities);
    this.buttonsContainer = this.element.querySelector('[data-next-express-checkout="buttons"]');
    if (!this.buttonsContainer) {
      this.logger.warn('No buttons container found with data-next-express-checkout="buttons"');
      return;
    }
    this.errorElement = document.querySelector('[data-next-component="express-error"]');
    this.errorTextElement = document.querySelector('[data-next-component="express-error-text"]');
    if (this.errorElement) {
      this.errorElement.style.display = "none";
    }
    const config = configStore.getState();
    const apiClient = new ApiClient(config.apiKey);
    this.orderManager = new OrderManager(
      apiClient,
      this.logger,
      (event, data) => this.emit(event, data)
    );
    this.expressProcessor = new ExpressCheckoutProcessor(
      this.logger,
      () => this.loadingOverlay.show(),
      (immediate) => this.loadingOverlay.hide(immediate),
      (event, data) => this.emit(event, data),
      this.orderManager
    );
    this.subscribe(configStore, this.handleConfigUpdate.bind(this));
    this.subscribe(useCampaignStore, this.handleCampaignUpdate.bind(this));
    this.subscribe(useCartStore, this.handleCartUpdate.bind(this));
    this.handleConfigUpdate(configStore.getState());
    this.handleCampaignUpdate(useCampaignStore.getState());
    this.logger.debug("ExpressCheckoutContainerEnhancer initialized");
  }
  handleConfigUpdate(state) {
    const prevPaymentConfig = this.paymentConfig;
    this.paymentConfig = state.paymentConfig;
    if (JSON.stringify(prevPaymentConfig) !== JSON.stringify(state.paymentConfig)) {
      this.updateExpressCheckoutButtons();
    }
  }
  handleCampaignUpdate(state) {
    const newExpressMethods = state.data?.available_express_payment_methods;
    const methodsChanged = JSON.stringify(this.availableExpressMethods) !== JSON.stringify(newExpressMethods);
    if (methodsChanged) {
      this.availableExpressMethods = newExpressMethods;
      this.updateExpressCheckoutButtons();
    }
  }
  async updateExpressCheckoutButtons() {
    if (!this.buttonsContainer) {
      this.hideContainer();
      return;
    }
    if (this.availableExpressMethods && this.availableExpressMethods.length > 0) {
      this.showContainer();
      this.clearButtons();
      const methodOrder = this.paymentConfig?.expressCheckout?.methodOrder;
      const availableMethodsMap = new Map(
        this.availableExpressMethods.map((m) => [m.code, m])
      );
      const orderedMethods = methodOrder ? methodOrder.filter((code) => availableMethodsMap.has(code)).map((code) => availableMethodsMap.get(code)) : this.availableExpressMethods;
      for (const method of orderedMethods) {
        switch (method.code) {
          case "paypal":
            {
              this.createPayPalButton();
            }
            break;
          case "apple_pay":
            if (isApplePayAvailable()) {
              this.createApplePayButton();
            } else {
              this.logger.debug("Apple Pay not available on this device/browser");
            }
            break;
          case "google_pay":
            {
              this.createGooglePayButton();
            }
            break;
          default:
            this.logger.warn(`Unknown express payment method: ${method.code}`);
        }
      }
      const actuallyAvailable = this.buttonInstances.size > 0;
      this.logger.debug("Express checkout buttons updated from campaign data", {
        requestedMethods: this.availableExpressMethods.map((m) => m.code),
        methodOrder: methodOrder || "campaign order",
        actuallyShown: Array.from(this.buttonInstances.keys()),
        hasVisibleButtons: actuallyAvailable
      });
      if (!actuallyAvailable) {
        this.hideContainer();
      }
    } else if (this.paymentConfig?.expressCheckout) {
      const { enabled, methods, methodOrder } = this.paymentConfig.expressCheckout;
      if (!enabled) {
        this.hideContainer();
        return;
      }
      const hasEnabledMethods = Object.values(methods || {}).some((enabled2) => enabled2);
      if (!hasEnabledMethods) {
        this.hideContainer();
        return;
      }
      this.showContainer();
      this.clearButtons();
      const order = methodOrder || ["paypal", "apple_pay", "google_pay"];
      for (const method of order) {
        switch (method) {
          case "paypal":
            if (methods.paypal && isPayPalAvailable()) {
              this.createPayPalButton();
            } else if (methods.paypal) {
              this.logger.debug("PayPal enabled in config but not available on device");
            }
            break;
          case "apple_pay":
            if (methods.applePay && isApplePayAvailable()) {
              this.createApplePayButton();
            } else if (methods.applePay) {
              this.logger.debug("Apple Pay enabled in config but not available on device/browser");
            }
            break;
          case "google_pay":
            if (methods.googlePay && isGooglePayAvailable()) {
              this.createGooglePayButton();
            } else if (methods.googlePay) {
              this.logger.debug("Google Pay enabled in config but not available on device/browser");
            }
            break;
          default:
            this.logger.warn(`Unknown payment method in methodOrder: ${method}`);
        }
      }
      const actuallyAvailable = this.buttonInstances.size > 0;
      this.logger.debug("Express checkout buttons updated from config", {
        requestedMethods: {
          paypal: methods.paypal,
          applePay: methods.applePay,
          googlePay: methods.googlePay
        },
        methodOrder: order,
        actuallyShown: Array.from(this.buttonInstances.keys()),
        hasVisibleButtons: actuallyAvailable
      });
      if (!actuallyAvailable) {
        this.hideContainer();
      }
    } else {
      this.hideContainer();
    }
  }
  hideContainer() {
    this.element.style.display = "none";
    this.logger.debug("Express checkout container hidden - no methods enabled");
  }
  showContainer() {
    this.element.style.display = "";
    this.logger.debug("Express checkout container shown");
  }
  clearButtons() {
    for (const [method, handler] of this.buttonClickHandlers) {
      const button = this.buttonInstances.get(method);
      if (button) {
        button.removeEventListener("click", handler);
      }
    }
    this.buttonClickHandlers.clear();
    if (this.buttonsContainer) {
      while (this.buttonsContainer.firstChild) {
        this.buttonsContainer.removeChild(this.buttonsContainer.firstChild);
      }
    }
    this.buttonInstances.clear();
  }
  async handleButtonClick(method, event) {
    event.preventDefault();
    const button = event.currentTarget;
    if (button.disabled) return;
    if (this.errorElement) {
      this.errorElement.style.display = "none";
    }
    for (const [, btn] of this.buttonInstances) {
      btn.setAttribute("disabled", "true");
    }
    const cartStore = useCartStore.getState();
    const checkoutStore = useCheckoutStore.getState();
    try {
      checkoutStore.setProcessing(true);
      checkoutStore.setPaymentMethod(method);
      await this.expressProcessor.handleExpressCheckout(
        method,
        cartStore.items,
        cartStore.isEmpty,
        () => cartStore.reset()
      );
      setTimeout(() => {
        for (const [, btn] of this.buttonInstances) {
          if (!cartStore.isEmpty) {
            btn.removeAttribute("disabled");
          }
        }
      }, 3e3);
    } catch (error) {
      this.handleError(error, "handleButtonClick");
      checkoutStore.setError("payment", "Express checkout failed. Please try again.");
      if (this.errorElement && this.errorTextElement) {
        const errorMessage = error instanceof Error ? error.message : "Express checkout failed";
        this.errorTextElement.textContent = `${errorMessage}. Please try a different payment method.`;
        this.errorElement.style.display = "flex";
        this.errorElement.style.position = "relative";
        this.errorElement.style.zIndex = "10000";
      }
      for (const [, btn] of this.buttonInstances) {
        if (!cartStore.isEmpty) {
          btn.removeAttribute("disabled");
        }
      }
    } finally {
      checkoutStore.setProcessing(false);
    }
  }
  handleCartUpdate(cartState) {
    for (const [, button] of this.buttonInstances) {
      if (cartState.isEmpty) {
        button.setAttribute("disabled", "true");
        button.classList.add("next-cart-empty");
      } else {
        button.removeAttribute("disabled");
        button.classList.remove("next-cart-empty");
      }
    }
  }
  async createPayPalButton() {
    const button = this.createButton("paypal", "cc-paypal", "paypal-btn", PAYPAL_SVG);
    this.buttonInstances.set("paypal", button);
    this.buttonsContainer.appendChild(button);
    const handler = (event) => this.handleButtonClick("paypal", event);
    this.buttonClickHandlers.set("paypal", handler);
    button.addEventListener("click", handler);
    this.emit("express-checkout:initialized", {
      method: "paypal",
      element: button
    });
    this.logger.debug("PayPal express checkout button created");
  }
  async createApplePayButton() {
    const button = this.createButton("apple_pay", "cc-apple-pay", "payment-btn__logo", APPLE_PAY_SVG);
    this.buttonInstances.set("apple_pay", button);
    this.buttonsContainer.appendChild(button);
    const handler = (event) => this.handleButtonClick("apple_pay", event);
    this.buttonClickHandlers.set("apple_pay", handler);
    button.addEventListener("click", handler);
    this.emit("express-checkout:initialized", {
      method: "apple_pay",
      element: button
    });
    this.logger.debug("Apple Pay express checkout button created");
  }
  async createGooglePayButton() {
    const button = this.createButton("google_pay", "cc-google-pay", "payment-btn__logo", GOOGLE_PAY_SVG);
    this.buttonInstances.set("google_pay", button);
    this.buttonsContainer.appendChild(button);
    const handler = (event) => this.handleButtonClick("google_pay", event);
    this.buttonClickHandlers.set("google_pay", handler);
    button.addEventListener("click", handler);
    this.emit("express-checkout:initialized", {
      method: "google_pay",
      element: button
    });
    this.logger.debug("Google Pay express checkout button created");
  }
  createButton(method, className, logoClass, svgContent) {
    const button = document.createElement("button");
    button.setAttribute("data-next-express-checkout", method);
    button.setAttribute("data-action", "submit");
    button.className = `payment-btn ${className}`;
    const logoDiv = document.createElement("div");
    logoDiv.className = logoClass;
    logoDiv.innerHTML = svgContent;
    button.appendChild(logoDiv);
    const spinnerDiv = document.createElement("div");
    spinnerDiv.setAttribute("next-slot", "spinner");
    spinnerDiv.className = "payment-btn-spinner";
    spinnerDiv.innerHTML = '<div class="spinner"></div>';
    button.appendChild(spinnerDiv);
    return button;
  }
  update() {
    this.handleConfigUpdate(configStore.getState());
  }
  destroy() {
    this.clearButtons();
    super.destroy();
  }
}
export {
  ExpressCheckoutContainerEnhancer
};
